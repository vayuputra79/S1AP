#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <execinfo.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <semaphore.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>
#include <unistd.h>
#include <signal.h>
#include <limits.h>
#include <poll.h>
#include <sys/epoll.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <error.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/sysinfo.h>
#include <sched.h>
#include <net/if.h> 
#include <sys/resource.h>
#include <ctype.h> 
#include <dirent.h> 
#include <ifaddrs.h>

#include "sirik_core.h"
#include "sirik_lic.h"


#define GetHiByte(w) (((unsigned short)(w) >> 8) & 0xff)
#define GetLoByte(w) ((unsigned short)(w) & 0xff)
#define GetHiWord(l) (((unsigned long)(l) >> 16) & 0xffffL)
#define GetLoWord(l) ((unsigned long)(l) & 0xffffL)

#define PutHiByte(w,b) (unsigned short) (((unsigned short)(b) << 8) | ((unsigned short)(w) & 0x00ff))
#define PutLoByte(w,b) (unsigned short) (((unsigned short)(b) & 0xff) | ((unsigned short)(w) & 0xff00))
#define PutHiWord(l,w) (unsigned long) (((unsigned long)(w) << 16) | ((unsigned long)(l) & (unsigned long)0x0000ffff))
#define PutLoWord(l,w) (unsigned long) (((unsigned long)(w) & 0xffff) | ((unsigned long)(l) & (unsigned long)0xffff0000))


static long __si_globalMxAllocatedMem = 0;
static long __si_globalMxCurrPos = 0;
static uint8_t * __si_globalMxMemory = NULL;
static uint8_t * __si_globalMxMemoryLastByteAddress = NULL;

//#pragma pack(4)
typedef struct __si_log_cat
{
	uint8_t iCat;
	int iEnabled;
	char sCatName[50];
} SI_LogCat;

//#pragma pack(4)
typedef struct __si_log_config
{
	int iHandle;	
	char Prefix[10];
	char Path[500];	
	int iLoggingThreshold;
	int PrintTimeStamp;
	int iFileIndex;
	int Enabled;
	int initalized;
	int LineCount;
	int initnotified;
	SI_LogCat LogCat[30];
	pthread_mutex_t Lock;
} SI_LogConfig;

//#pragma pack(4)
typedef struct __si_memory_head
{
	uint32_t isReleased;
	uint32_t index;
	uint32_t block_size;
	uint32_t alloc_size;
	uint8_t * parentPtr;
	uint8_t * memory;
	
	struct __si_memory_head * PoolNext;
} SI_MemoryHead;

//#pragma pack(4)
typedef struct __si_memory_pool
{
	uint32_t InitialPoolSize;				//initial pool size at app start-up
	uint32_t IncrementPoolSize;				//increment pool size on demand
	uint32_t size;							//block size
	uint32_t TotalPoolSize;					//pool size/count
	uint32_t Available;						//available blocks
	uint64_t Used;							//used blocks	
	uint32_t MemoryReservedCount;
	uint64_t Returned;
	//uint32_t allocForSize;
	
	SI_MemoryHead * Head;
	SI_MemoryHead * Current;
	pthread_mutex_t Lock;
} SI_MemoryPool;


void __si_allocate_Memory( SI_MemoryPool * memoryPool, int count, int inLockMode);
void __si_addToMemoryPool( SI_MemoryPool * memoryPool, SI_MemoryHead * itemPtr, int inLockMode);



//#pragma pack(4)
typedef struct __si_event
{
	uint16_t   eventType;
	uint8_t  * eventDataPtr;
	uint8_t  isReleased;
	
	struct __si_event * PoolNext;
} SI_Event;

//#pragma pack(4)
typedef struct __si_event_set
{
	SI_Event 				* EventHead;
	SI_Event 				* EventCurrent;
	sem_t 	  				sem_lock;
	pthread_mutex_t 		Lock;
	
	__si_event_callaback 	CallBack;
} SI_EventSet;




//#pragma pack(4)
typedef struct __si_timer_tick
{
	SI_Timer * Head;
	SI_Timer * Current;
	pthread_mutex_t Lock;
	
} SI_Timer_Tick;


//#pragma pack(4)
typedef struct __si_core_queue_record
{
	void * Data;
	void (*executor)( void *);
	struct __si_core_queue_record * Next;
	int isReleased;
} SI_CoreQueueRecord;

//#pragma pack(4)
typedef struct __si_app_event_info
{
	struct __si_app_event_info * Next;
	app_event_handler handler;
} SI_AppEventInfo;

//#define			MAX_TIMER_TICKS			3600
#define			MAX_TIMER_TICKS			21600			//6 HRS
//#define			MAX_TIMER_TICKS			60


//#pragma pack(4)
typedef struct __si_core
{
	SI_CoreDataRecord  * DataRecordHead;
	SI_CoreDataRecord  * DataRecordCurrent;
	int 				DataRecordAvailableCount;
	int 				DataRecordCount;
	pthread_mutex_t 	DataRecordLock;	
	
	SI_CoreQueueRecord  * QueueRecordHead;
	SI_CoreQueueRecord  * QueueRecordCurrent;
	int 				QueueRecordAvailableCount;
	int 				QueueRecordCount;
	pthread_mutex_t 	QueueRecordLock;	
	
	pthread_mutex_t 	StreamLock;	
	SI_Stream 			* StreamHead;
	SI_Stream 			* StreamCurrent;
	int 				StreamPoolAvailableCount;
	int 				StreamPoolCount;
	
	pthread_mutex_t 	EventLock;	
	SI_Event 			* EventHead;
	SI_Event 			* EventCurrent;
	int 				EventPoolAvailableCount;
	int 				EventPoolCount;
	
	int 				LocalTimeValue;
	uint64_t 			UUID4SerialNumber;
	
	char 				LogRootPath[249];
	SI_LogConfig		LogConfig[6];
	SI_MemoryPool		MemoryPool[41];
	pthread_mutex_t 	MemoryFreeLock;
	
	SI_EventSet			* eventSet;
	
	pthread_mutex_t 	TaskLock;	
	SI_Task 			* TaskHead;
	SI_Task 			* TaskCurrent;
	int 				TaskPoolAvailableCount;
	int 				TaskPoolCount;	
	
	SI_EventHandler		EventHandler[30];
	int 				EventHandlerCount;
	
	SI_Queue			* QueueLineHead;
	SI_Queue			* QueueLineCurrent;
	int					QueueLineCount;
	long int 			QueueLineLastProcessedCount;
	long int 			QueueLineTotalProcessedCount;
	long int 			QueueLineLastQueuedCount;	
	long int 			QueueLineTotalQueuedCount;
	int					QueueBacklog;
	int					QueueBacklogTotal;
	int 				LastAvgQueueBacklog;
	int					QueueLineThreadCount;
	long int 			QueueUsedTimes;
	pthread_mutex_t 	QueueLineLock;
	struct timeval 		QueueLineThreadIncreasedTime;
	
	SI_Queue			* QueueHead;
	SI_Queue			* QueueCurrent;
	pthread_mutex_t 	QueueLock;
	sem_t 	  			queue_sem_lock;
	int 				TotalQueuePoolCount;
	int 				AvailableQueuePoolCount;
	
	SI_Timer			* TimerHead;
	SI_Timer			* TimerCurrent;
	pthread_mutex_t 	TimerLock;
	int 				TotalTimerPoolCount;
	long 				UsedTimerPoolCount;
	int 				AvailableTimerPoolCount;	
	
	//Support for 1 hour
	SI_Timer_Tick		Timers[MAX_TIMER_TICKS];
	int 				TimerTickIndex;
	long int 			SeverTimerTick;
	
	SI_LinkedList		* LinkedListPoolHead;
	SI_LinkedList		* LinkedListPoolCurrent;
	pthread_mutex_t 	LinkedListPoolLock;
	int 				TotalLinkedListPoolCount;
	int 				AvailableLinkedListPoolCount;
	
	SI_Thread * ThreadHead;
	SI_Thread * ThreadCurrent;
	
	SI_AppEventInfo		* AppEventInfoHead;
	SI_AppEventInfo		* AppEventInfoCurrent;
	pthread_mutex_t 	AppEventInfoLock;
	
	SI_ServiceRequest * ServiceRequestHead;
	SI_ServiceRequest * ServiceRequestCurrent;
	pthread_mutex_t 	ServiceRequestLock;
	int 				ServiceRequestTotalPoolCount;
	int 				ServiceRequestAvailablePoolCount;

	SI_Activity * 		ActivityHead;
	SI_Activity * 		ActivityCurrent;
	pthread_mutex_t 	ActivityLock;
	int 				ActivityTotalPoolCount;
	int 				ActivityAvailablePoolCount;

	si_sirik_pool_t *	si_buffPool;	//Dynamic buffer Pool for __si_buff_t
	time_t				startTime;
	
	uint32_t 			enableStackPerLog;	
	SI_License license;
} SI_Core;


SI_Core * __siCore;

void __si_core_enable_perf_log()
{
	__siCore->enableStackPerLog = 1;
}	

void __si_core_disable_perf_log()
{
	__siCore->enableStackPerLog = 0;
}

int __si_core_get_timer_tick()
{
	return __siCore->TimerTickIndex;
}

long int __si_core_get_server_timer_tick()
{
	return __siCore->SeverTimerTick;
}

uint8_t __si_core_getU8RAND()
{
	return (rand() % 255);
}

uint16_t __si_core_getU16RAND()
{
	return (rand() % 65535);
}

uint32_t __si_core_getU32RAND()
{
	return (rand() % 4294967295);
}

uint64_t __si_core_getU64RAND()
{
	return (rand() % 9223372036854775807);
}

uint8_t __si_core_getU8RANDRange( uint8_t min, uint8_t max)
{
	return (rand() % (max - min + 1 ) ) + min;
}

uint16_t __si_core_getU16RANDRange( uint16_t min, uint16_t max)
{
	return (rand() % (max - min + 1 ) ) + min;
}

uint32_t __si_core_getU32RANDRange( uint32_t min, uint32_t max)
{
	return (rand() % (max - min + 1 ) ) + min;
}

uint64_t __si_core_getU64RANDRange( uint64_t min, uint64_t max)
{
	if( 18446744073709551615U == max)
	{
		if( min == 0)
			min = 100000000;
		
		return (rand() % (max - min + 1 ) ) + min;
	}
	return (rand() % (max - min + 1 ) ) + min;
}

void __si_core_fill_dummy_data( unsigned char * data, int len)
{
	int i = 0;
	for( i = 0; i < len; i++)
	{
		data[i] = __si_core_getU8RANDRange(65,100);
	}
}

void __si_core_str_fill_rand_hex_string( unsigned char * data, int len)
{
	int i = 0;
	for( i = 0; i < len; i++)
	{
		sprintf( &data[i], "%X", __si_core_getU8RANDRange(1,16));
	}
}

/*Base 64 Begin*/

/* aaaack but it's fast and const should make it shared text page. */
static const unsigned char pr2six[256] =
{
    /* ASCII table */
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 62, 64, 64, 64, 63,
    52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 64, 64, 64, 64, 64, 64,
    64,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14,
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 64, 64, 64, 64, 64,
    64, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64
};

int Base64decode_len(const char *bufcoded)
{
    int nbytesdecoded;
    register const unsigned char *bufin;
    register int nprbytes;

    bufin = (const unsigned char *) bufcoded;
    while (pr2six[*(bufin++)] <= 63);

    nprbytes = (bufin - (const unsigned char *) bufcoded) - 1;
    nbytesdecoded = ((nprbytes + 3) / 4) * 3;

    return nbytesdecoded + 1;
}

int Base64decode(char *bufplain, const char *bufcoded)
{
    int nbytesdecoded;
    register const unsigned char *bufin;
    register unsigned char *bufout;
    register int nprbytes;

    bufin = (const unsigned char *) bufcoded;
    while (pr2six[*(bufin++)] <= 63);
    nprbytes = (bufin - (const unsigned char *) bufcoded) - 1;
    nbytesdecoded = ((nprbytes + 3) / 4) * 3;

    bufout = (unsigned char *) bufplain;
    bufin = (const unsigned char *) bufcoded;

    while (nprbytes > 4) {
    *(bufout++) =
        (unsigned char) (pr2six[*bufin] << 2 | pr2six[bufin[1]] >> 4);
    *(bufout++) =
        (unsigned char) (pr2six[bufin[1]] << 4 | pr2six[bufin[2]] >> 2);
    *(bufout++) =
        (unsigned char) (pr2six[bufin[2]] << 6 | pr2six[bufin[3]]);
    bufin += 4;
    nprbytes -= 4;
    }

    /* Note: (nprbytes == 1) would be an error, so just ingore that case */
    if (nprbytes > 1) {
    *(bufout++) =
        (unsigned char) (pr2six[*bufin] << 2 | pr2six[bufin[1]] >> 4);
    }
    if (nprbytes > 2) {
    *(bufout++) =
        (unsigned char) (pr2six[bufin[1]] << 4 | pr2six[bufin[2]] >> 2);
    }
    if (nprbytes > 3) {
    *(bufout++) =
        (unsigned char) (pr2six[bufin[2]] << 6 | pr2six[bufin[3]]);
    }

    *(bufout++) = '\0';
    nbytesdecoded -= (4 - nprbytes) & 3;
    return nbytesdecoded;
}

static const char basis_64[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

int Base64encode_len(int len)
{
    return ((len + 2) / 3 * 4) + 1;
}

int Base64encode(char *encoded, const char *string, int len)
{
    int i;
    char *p;

    p = encoded;
    for (i = 0; i < len - 2; i += 3) {
    *p++ = basis_64[(string[i] >> 2) & 0x3F];
    *p++ = basis_64[((string[i] & 0x3) << 4) |
                    ((int) (string[i + 1] & 0xF0) >> 4)];
    *p++ = basis_64[((string[i + 1] & 0xF) << 2) |
                    ((int) (string[i + 2] & 0xC0) >> 6)];
    *p++ = basis_64[string[i + 2] & 0x3F];
    }
    if (i < len) {
    *p++ = basis_64[(string[i] >> 2) & 0x3F];
    if (i == (len - 1)) {
        *p++ = basis_64[((string[i] & 0x3) << 4)];
        *p++ = '=';
    }
    else {
        *p++ = basis_64[((string[i] & 0x3) << 4) |
                        ((int) (string[i + 1] & 0xF0) >> 4)];
        *p++ = basis_64[((string[i + 1] & 0xF) << 2)];
    }
    *p++ = '=';
    }

    *p++ = '\0';
    return p - encoded;
}

/*Base 64 End*/

void __si_getCPUId( char * PSN)
{
    int varEAX, varEBX, varECX, varEDX;
    char str[9];
	memset( str, 0, sizeof(str));

    __asm__ __volatile__ ("cpuid"   : "=a" (varEAX), "=b" (varEBX), "=c" (varECX), "=d" (varEDX) : "a" (1));
	sprintf( str, "%08X", varEAX);
	
	strcpy( PSN, str);
}

int __si_getBase64CPUId( char * sEncodedStr)
{
	char PSN[30];
	memset( PSN, 0, sizeof(PSN));
	__si_getCPUId( PSN);
	
	return Base64encode( sEncodedStr, PSN, strlen(PSN));
}


int __si_getReverseBase64CPUId( char * sREncodedStr)
{
	char sEncodedStr[2000];
	memset( sEncodedStr, 0, sizeof(sEncodedStr));

	int slen = __si_getBase64CPUId( sEncodedStr);
	slen = strlen( sEncodedStr);
	
	int i = 0;
	for( i = 0; i < slen; i++)
	{
		sREncodedStr[i] = sEncodedStr[ (slen-i) - 1 ];
	}

	return slen;
}


void __si_logDeviceInfo()
{
	char sEncodedStr[2000];
	memset( sEncodedStr, 0, sizeof(sEncodedStr));
	
	int sts = __si_getReverseBase64CPUId( sEncodedStr);
	__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "device-info:[%s|%d] <core|%d>", sEncodedStr, sts, __LINE__);
}


long __si_getMB( long l)
{
	if( l > 0)
	{
		return ((l/1024)/1024);
	}
	return 0;
}

void __si_printMallocStats()
{
	long leftMemory = __si_globalMxAllocatedMem - __si_globalMxCurrPos;
	
	/*
	printf("0, Allocated: %ld MB, Used: %ld MB, Remaining: %ld MB \n",
		__si_getMB( __si_globalMxAllocatedMem ), __si_getMB(__si_globalMxCurrPos), __si_getMB( leftMemory) );
	*/
	
	/*
	if( leftMemory > 0)
	{
		printf(" [(%ld MB) Left]", ((leftMemory/1024)/1024));
	}
	*/
	
	//printf("\n");
}

pthread_mutex_t __si_MallocLock;

int iCoreMemRequest = 0;

void __si_CoreDumpOnMemoryRequest() {
	iCoreMemRequest = 1;
}

int __si_CoreDumpOnMemoryRequest_isEnabled(){
	return iCoreMemRequest;
}


void __si_malloc2( size_t size, uint8_t ** dataPtr)
{
	pthread_mutex_lock( &__si_MallocLock);

	//printf( "__si_globalMxAllocatedMem=%lu  cp=%lu  %s|%d\n", __si_globalMxAllocatedMem, (__si_globalMxCurrPos + size), __FILE__, __LINE__);

	if( iCoreMemRequest == 1) 
	{
		printf("generating core 1.0\n");
		raise(0);
		printf("generating core 2.0\n");
		int j = 100/(iCoreMemRequest-1);
	}
	
	if( __si_globalMxAllocatedMem > (__si_globalMxCurrPos + size))
	{	
		uint8_t * p = __si_globalMxMemory;
	
		__si_globalMxMemory += size;
		__si_globalMxCurrPos += size;
		
		*dataPtr = p;
	}		
	else
	{
		//int oneKB = 1024; //bytes
		//int oneMB = oneKB * 1024;
		//int oneGB = oneMB * 1024;
		//int reqGBMem = (16 * 1024 * 1024); //16 MB
		int reqGBMem = (24 * 1024 * 1024); //24 MB
		
		if( size > reqGBMem)
			reqGBMem = size * 2;
		
		
		__si_globalMxAllocatedMem += reqGBMem;
		//__si_globalMxMemory = (uint8_t *)calloc( 1, reqGBMem);	
		__si_globalMxMemory = (uint8_t *) malloc( reqGBMem);
		
		if(!__si_globalMxMemory)
		{
			printf("memory allocation failed of size=%d %s|%d\n", reqGBMem, __FILE__, __LINE__);
		}
		else
		{	
			//printf( "reserved memory = %d [%s,%d]\n", reqGBMem, __FUNCTION__, __LINE__);
		}

		__si_globalMxMemoryLastByteAddress = ((__si_globalMxMemory) + reqGBMem)-1;
		
		/* 
		printf( "__si_globalMxMemory=%p __si_globalMxMemoryLastByteAddress=%p mem=%lu  %s|%d\n", __si_globalMxMemory, 
		__si_globalMxMemoryLastByteAddress, (__si_globalMxMemoryLastByteAddress-__si_globalMxMemory), __FUNCTION__, __LINE__);
		*/
		
		uint8_t * p = __si_globalMxMemory;
	
		__si_globalMxMemory += size;
		__si_globalMxCurrPos += size;

		*dataPtr = p;
	}
	
	pthread_mutex_unlock( &__si_MallocLock);
}

uint8_t * __si_malloc( size_t size)
{
	pthread_mutex_lock( &__si_MallocLock);
	
	if( iCoreMemRequest == 1) 
	{
		printf("generating core 1.1\n");
		raise(0);
		printf("generating core 2.1\n");
		int j = 100/(iCoreMemRequest-1);
	}

	
	if( __si_globalMxAllocatedMem > (__si_globalMxCurrPos + size))
	//if( __si_globalMxMemoryLastByteAddress > (__si_globalMxMemory + size))
	{	
		uint8_t * p = __si_globalMxMemory;
	
		__si_globalMxMemory += size;
		__si_globalMxCurrPos += size;
		
		pthread_mutex_unlock( &__si_MallocLock);
		return p;
	}
	else
	{
		//int oneKB = 1024; //bytes
		//int oneMB = oneKB * 1024;
		//int oneGB = oneMB * 1024;
		//int reqGBMem = (16 * 1024 * 1024); //16 MB
		int reqGBMem = (24 * 1024 * 1024); //16 MB
		//printf( "reqGBMem=%d  %s|%d\n", reqGBMem, __FILE__, __LINE__);
		
		if( size > reqGBMem)
			reqGBMem = size * 2;
		
		//printf( "size=%ld reqGBMem=%d %s|%d\n", size, reqGBMem, __FILE__, __LINE__);
		
		__si_globalMxAllocatedMem += reqGBMem;
		//__si_globalMxMemory = (uint8_t *) calloc( 1, reqGBMem);
		__si_globalMxMemory = (uint8_t *) malloc( reqGBMem);	
		
		printf( "__si_globalMxAllocatedMem=%lu  cp=%lu  %s|%d\n", __si_globalMxAllocatedMem, (__si_globalMxCurrPos + size), __FILE__, __LINE__);
		
		if(!__si_globalMxMemory)
		{
			printf("memory allocation failed of size=%d %s|%d\n", reqGBMem, __FILE__, __LINE__);
			abort();
		}
		else 
		{
			//printf( "reserved memory = %d [%s,%d]\n", reqGBMem, __FUNCTION__, __LINE__);
		}
		
		__si_globalMxMemoryLastByteAddress = ((__si_globalMxMemory) + reqGBMem)-1;
		
		/*
		printf( "__si_globalMxMemory=%p __si_globalMxMemoryLastByteAddress=%p mem=%lu  %s|%d\n", __si_globalMxMemory, 
		__si_globalMxMemoryLastByteAddress, (__si_globalMxMemoryLastByteAddress-__si_globalMxMemory), __FUNCTION__, __LINE__);
		*/
		
		uint8_t * p = __si_globalMxMemory;
	
		__si_globalMxMemory += size;
		__si_globalMxCurrPos += size;
		
		//printf("extending memory with %d\n", reqGBMem);
		pthread_mutex_unlock( &__si_MallocLock);
		return p;
	}
	
	usleep(999999);
	return NULL;
}


void __si_http2__malloc2( size_t size, uint8_t ** dataPtr)
{
	pthread_mutex_lock( &__si_MallocLock);
	
	
	
	
	if( __si_globalMxAllocatedMem > (__si_globalMxCurrPos + size))
	{	
		*dataPtr = __si_globalMxMemory;
	
		__si_globalMxMemory += size;
		__si_globalMxCurrPos += size;

		pthread_mutex_unlock( &__si_MallocLock);		
		return;
	}
	else
	{
		//int oneKB = 1024; //bytes
		//int oneMB = oneKB * 1024;
		//int oneGB = oneMB * 1024;
		//int reqGBMem = (16 * 1024 * 1024); //16 MB
		int reqGBMem = (24 * 1024 * 1024); //16 MB
	
		if( size > reqGBMem)
			reqGBMem = size * 2;
	
		__si_globalMxAllocatedMem += reqGBMem;
		//__si_globalMxMemory = (uint8_t *)calloc( 1, reqGBMem);	
		__si_globalMxMemory = (uint8_t *) malloc( reqGBMem);	
		
		printf( "__si_globalMxAllocatedMem=%lu  cp=%lu  %s|%d\n", __si_globalMxAllocatedMem, (__si_globalMxCurrPos + size), __FILE__, __LINE__);
		
		*dataPtr = __si_globalMxMemory;
		
		//printf( "reserved memory = %d [%s,%d]\n", reqGBMem, __FUNCTION__, __LINE__);
		
		__si_globalMxAllocatedMem += size;
		__si_globalMxCurrPos += size;

		pthread_mutex_unlock( &__si_MallocLock);
		return;
	}
	
	*dataPtr = NULL;
	usleep(999999);
}


int __si_init_malloc_mb_size = 96;
//int __si_init_malloc_mb_size = 192;

void __si_initial_malloc_mb( int imb)
{
	__si_init_malloc_mb_size = imb;
}

static int __si_init_initial_malloc_allocated = 0;

void __si_initial_malloc()
{
	pthread_mutex_lock( &__si_MallocLock);
	
	if( __si_init_initial_malloc_allocated == 0)
	{	
		__si_init_initial_malloc_allocated = 1;
		
		int reqGBMem = ( __si_init_malloc_mb_size * 1024 * 1024);
		
		__si_globalMxAllocatedMem += reqGBMem;
		__si_globalMxMemory = (uint8_t *)calloc( 1, reqGBMem);
		__si_globalMxMemoryLastByteAddress = ((__si_globalMxMemory) + reqGBMem)-1;
		
		__si_printMallocStats();
		
		/*
		printf( "__si_globalMxMemory=%p __si_globalMxMemoryLastByteAddress=%p mem=%lu %s|%d\n", __si_globalMxMemory, 
		__si_globalMxMemoryLastByteAddress, (__si_globalMxMemoryLastByteAddress-__si_globalMxMemory), __FUNCTION__, __LINE__);
		printf( "reserved memory = %d bytes, %d MB[%s,%d]\n", reqGBMem, ( ((reqGBMem/1024)/1024)), __FUNCTION__, __LINE__);
		*/
		
	}
	pthread_mutex_unlock( &__si_MallocLock);
}


void __si_malloc_register( size_t size)
{
}


int logMallocBlock = 0;

void __si_LogMallocBlock() 
{
	logMallocBlock = 1;
}

uint8_t * __si_malloc_block( size_t size, char * file, int line)
{
	if( logMallocBlock == 1)
	{
		printf( "requesting memory with size=%ld requestor=[%s|%d]  %s|%d\n", size, file, line, __FILE__, __LINE__);
	}
	
	return malloc( size);
}


void __si_decodeBitVal( uint8_t * bVal, char* _nwByte, int iFromIndex, int bitNumber)
{
	*bVal =  (_nwByte[iFromIndex + 0] & (1 << bitNumber)) ? 1 : 0;
}


void __si_encodeIntTo3Bytes( unsigned int * val, char * data)
{
	unsigned char * bytePtr = (unsigned char*)val;
	int arrayLength = 4;
	
	int i;
	for( i = 1; i < arrayLength; i++) {
		data[i-1] = bytePtr[ (arrayLength) - (i+1)];
	}
}


/*
void gtpEncodeIntTo2Bytes( unsigned int val, char * data, int iFrom)
{
	data[iFrom + 0] = (val >> 8) & 0xFF;
	data[iFrom + 1] = val & 0xFF;
}

int getIELength( char *cBuffer)
{
	char vLBuff[sizeof(uint16_t)];
	vLBuff[0] = cBuffer[1];
	vLBuff[1] = cBuffer[2];
	uint16_t *iIELength2 = (uint16_t*) vLBuff;
	return ntohs(*iIELength2);
}

void setLengthToBuffer( uint16_t iIELength2, char* cBuff)
{
	char vLBuff[sizeof(uint16_t)];
	memcpy( &vLBuff, &iIELength2, 2);
	cBuff[0] = vLBuff[1];
	cBuff[1] = vLBuff[0];
}
*/


uint16_t __si_http2_getInt16( char *cBuffer)
{
	char vLBuff[sizeof(uint16_t)];
	vLBuff[0] = cBuffer[1];
	vLBuff[1] = cBuffer[2];
	uint16_t *iIELength2 = (uint16_t*) vLBuff;
	return (*iIELength2);
}


void __si_encodeIntTo2Bytes( uint16_t * val, char * data)
{
	unsigned char * bytePtr = (unsigned char*)val;
	int arrayLength = 2;
	
	int i;
	for( i = 0; i < arrayLength; i++) 
	{
		data[i] = bytePtr[ (arrayLength) - (i+1)];
	}
	
	//0 = (2-1)=1
	//1 = (2-2)=0
}


void __si_encodeIntTo4Bytes( uint32_t * val, char * data)
{
	unsigned char * bytePtr = (unsigned char*)val;
	int arrayLength = 4;
	
	int i;
	for( i = 0; i < arrayLength; i++) 
	{
		data[i] = bytePtr[ (arrayLength) - (i+1)];
	}
	
	//0 = (4-1)=3
	//1 = (4-2)=2
	//2 = (4-3)=1
	//3 = (4-4)=0
}


void __si_decodeIntValueFrom3Bytes( unsigned int * iInt, char* nwByte, int iFromIndex)
{
	unsigned short nwWord[2];
	unsigned int tmpU32;

	tmpU32 = 0;
	nwWord[0] = 0;
	nwWord[1] = 0;

	nwWord[0] = ((unsigned short)nwByte[ iFromIndex + 0] & 0x00FF);
	nwWord[1] = ((unsigned short)nwByte[ iFromIndex + 1] & 0x00FF);
	nwWord[1] <<= 8;
	nwWord[1] |= ((unsigned short)nwByte[ iFromIndex + 2] & 0x00FF);


	nwWord[1] = (nwWord[1]);
	tmpU32 = ((unsigned long)nwWord[0] & 0x0000FFFF);
	tmpU32 <<= 16; 
	tmpU32 |= ((unsigned long)nwWord[1] & 0x0000FFFF);

	*iInt = tmpU32;
}


void __si_decodeIntValueFrom4Bytes(unsigned int * iInt, char* _nwByte, int iFromIndex)
{
	unsigned short nwWord[2];
	unsigned short hoWord[2];
	unsigned int tmpU32;

	tmpU32 = 0;
	nwWord[0] = nwWord[1] = 0;
	hoWord[0] = hoWord[1] = 0;
	nwWord[0] = (unsigned short)PutHiByte(nwWord[0], _nwByte[iFromIndex + 0]);
	nwWord[0] = (unsigned short)PutLoByte(nwWord[0], _nwByte[iFromIndex + 1]);
	hoWord[0] = (unsigned short)((nwWord[0]));
	nwWord[1] = (unsigned short)PutHiByte(nwWord[1], _nwByte[iFromIndex + 2]);
	nwWord[1] = (unsigned short)PutLoByte(nwWord[1], _nwByte[iFromIndex + 3]);
	hoWord[1] = (unsigned short)((nwWord[1]));
	tmpU32 = (unsigned long)PutHiWord(tmpU32, nwWord[0]);
	tmpU32 = (unsigned long)PutLoWord(tmpU32, nwWord[1]);

	*iInt = (unsigned long)((tmpU32));
}

void __si_encode_uint64( uint8_t * data, uint64_t value)
{
	data[0] = (value >> 56) & 0xFF;	
	data[1] = (value >> 48) & 0xFF;	
	data[2] = (value >> 40) & 0xFF;		
	data[3] = (value >> 32) & 0xFF;	
	data[4] = (value >> 24) & 0xFF;
	data[5] = (value >> 16) & 0xFF;
	data[6] = (value >> 8) & 0xFF;
	data[7] = (value) & 0xFF;	
}

void __si_encode_uint64_to5bytes( uint8_t * data, uint64_t value)
{
	data[0] = (value >> 32) & 0xFF;	
	data[1] = (value >> 24) & 0xFF;
	data[2] = (value >> 16) & 0xFF;
	data[3] = (value >> 8) & 0xFF;
	data[4] = (value) & 0xFF;	
}


void __si_encode_uint32_to45bytes( uint8_t * data, uint32_t value)
{
	data[0] = (value >> 28) & 0xFF;
	data[1] = (value >> 20) & 0xFF;
	data[2] = (value >> 12) & 0xFF;
	data[3] = (value >> 4) & 0xFF;
	//data[4] = (value) & 0xF0;	
	data[4] = (value << 4) & 0xF0;	
}

void __si_encode_uint32_to4bytes( uint8_t * data, uint32_t value)
{
	data[0] = (value >> 24) & 0xFF;
	data[1] = (value >> 16) & 0xFF;
	data[2] = (value >> 8) & 0xFF;
	data[3] = (value) & 0xFF;	
}


void __si_encode_uint32_to35bytes( uint8_t * data, uint32_t value)
{
	// data[0] = (value >> 24) & 0x0F;
	// data[1] = (value >> 16) & 0xFF;
	// data[2] = (value >> 8) & 0xFF;
	// data[3] = (value) & 0xFF;

	data[0] = (value >> 20) & 0x0F;
	data[1] = (value >> 12) & 0xFF;
	data[2] = (value >> 4) & 0xFF;
	data[3] = (value << 4) & 0xF0;
	
	//__si_print_buffer( data, 4);
	//printf("%u\n", value);
}

void __si_encode_uint32_to3bytes( uint8_t * data, uint32_t value)
{
	data[0] = (value >> 16) & 0xFF;
	data[1] = (value >> 8) & 0xFF;
	data[2] = (value) & 0xFF;	
}

void __si_encode_int32_to4bytes( uint8_t * data, int32_t value)
{
	data[0] = (value >> 24) & 0xFF;
	data[1] = (value >> 16) & 0xFF;
	data[2] = (value >> 8) & 0xFF;
	data[3] = (value) & 0xFF;	
}

void __si_encode_uint16_to2bytes( uint8_t * data, uint16_t value)
{
	data[0] = (value >> 8) & 0xFF;
	data[1] = (value) & 0xFF;	
}

void __si_encode_int16_to2bytes( uint8_t * data, int16_t value)
{
	data[0] = (value >> 8) & 0xFF;
	data[1] = (value) & 0xFF;	
}

void __si_bit__U8_setbit( uint8_t * u8, uint8_t bitIndex)
{
	(*u8) |= 1 << bitIndex;	
}

void __si_bit__U16_setbit( uint16_t * u16, uint8_t bitIndex)
{
	(*u16) |= 1 << bitIndex;	
}

void __si_bit__U32_setbit( uint32_t * u32, uint8_t bitIndex)
{
	(*u32) |= 1 << bitIndex;	
}

uint8_t __si_bit__U8_isbitset( uint8_t u8, uint8_t bitIndex)
{
	return ( u8 & ( 1 << bitIndex)) ? 1 : 0;
}

uint8_t __si_bit__U16_isbitset( uint16_t u16, uint8_t bitIndex)
{
	return ( u16 & ( 1 << bitIndex)) ? 1 : 0;
}

uint8_t __si_bit__U32_isbitset( uint32_t u32, uint8_t bitIndex)
{
	return ( u32 & ( 1 << bitIndex)) ? 1 : 0;
}



void __si_checkexpiry()
{
	struct timeval tv;
	struct timezone tzone;
	gettimeofday( &tv, &tzone);
	
	tv.tv_sec += __siCore->LocalTimeValue;	// 19800;
	
	struct tm *timeinfo = gmtime( &tv.tv_sec);
	
	/*
	if( ((timeinfo->tm_mday)) > 19)
	{
		printf("expired by day \n");
		exit(0);
	}
	*/
	
	if( ((timeinfo->tm_year) + 1900) > 2020)
	{
		printf("year expired\n");
		exit(0);
	}
}

//tv.tv_sec += __siCore->LocalTimeValue;	// 19800;


void __si_makeDBTimeStamp( char * datestring)
{
	struct timeval tv;
	struct timezone tzone;
	gettimeofday( &tv, &tzone);

	if( __siCore) {	
		tv.tv_sec += __siCore->LocalTimeValue;	// 19800;
	}
	
	struct tm * timeinfo = gmtime( &tv.tv_sec);
	
	sprintf( datestring, 
		"%d-%02d-%02d %02d:%02d:%02d", 
		(timeinfo->tm_year) + 1900, 
		(timeinfo->tm_mon) + 1,
		timeinfo->tm_mday, 
		timeinfo->tm_hour, 
		timeinfo->tm_min, 
		timeinfo->tm_sec);

	datestring[27] = 0;
}

void __si_makeElapsedHMS( uint32_t ticks, uint32_t * h , uint32_t * m, uint32_t * s)
{
	(*h) = (*m) = (*s) =0;
	
	*s = ticks % 60;
	if( ticks >= 60) {
		*m = ticks/60;
	}
	if( (*m) >= 60) {
		*h = (*m)/60;
	}	
}


void __si_print_timestamp_for_debug( char * prefix)
{
	char date[30];
	memset( date, 0, sizeof(date));
	__si_makeTimeStamp( date);
	printf("%s[%s]\n", prefix,date);	
}

void __si_makeTimeStamp2( struct timeval * tv, char * datestring, int convertToLocal)
{
	struct tm * timeinfo = NULL;
	uint64_t tv_sec = tv->tv_sec;
	
	if( __siCore && convertToLocal) {	
		tv_sec += __siCore->LocalTimeValue;
	}
	
	timeinfo = gmtime( &tv_sec);
	
	sprintf( datestring, "%02d-%02d-%02d %02d:%02d:%02d.%06ld", 
		(timeinfo->tm_mon) + 1, 
		timeinfo->tm_mday, 
		(timeinfo->tm_year) + 1900, 
		timeinfo->tm_hour, 
		timeinfo->tm_min, 
		timeinfo->tm_sec, tv->tv_usec);
	
	datestring[27] = 0;	
}

void __si_TimeStameForFileName( char * datestring, int format)
{
	struct timeval tv;
	struct timezone tzone;
	gettimeofday( &tv, &tzone);
	
	if( __siCore) {	
		tv.tv_sec += __siCore->LocalTimeValue;	// 19800;
	}
	
	struct tm *timeinfo = gmtime( &tv.tv_sec);
	
	if( format == 1)
	{
		sprintf( datestring, 
			"%02d%02d%d_%02d%02d%02d", 
			timeinfo->tm_mday, 
			(timeinfo->tm_mon) + 1, 
			(timeinfo->tm_year) + 1900, 
			timeinfo->tm_hour, 
			timeinfo->tm_min, 
			timeinfo->tm_sec );		
	}
	else
	{
		sprintf( datestring, 
			"%02d_%02d_%d_%02d_%02d_%02d_%06lu", 
			timeinfo->tm_mday, 
			(timeinfo->tm_mon) + 1, 
			(timeinfo->tm_year) + 1900, 
			timeinfo->tm_hour, 
			timeinfo->tm_min, 
			timeinfo->tm_sec, 
			tv.tv_usec);
	}	
	datestring[27] = 0;	
}

void __si_makeTimeStamp( char * datestring)
{
	struct timeval tv;
	struct timezone tzone;
	gettimeofday( &tv, &tzone);
	
	if( __siCore) {	
		tv.tv_sec += __siCore->LocalTimeValue;	// 19800;
	}
	
	struct tm *timeinfo = gmtime( &tv.tv_sec);
	
	sprintf( datestring, 
		"%02d-%02d-%d:%02d:%02d:%02d:%06lu", 
		timeinfo->tm_mday, 
		(timeinfo->tm_mon) + 1, 
		(timeinfo->tm_year) + 1900, 
		timeinfo->tm_hour, 
		timeinfo->tm_min, 
		timeinfo->tm_sec, 
		tv.tv_usec);
		
	datestring[27] = 0;	
}

int __si_split( __si_split_data_t * sdata, char * splitter)
{
	char * part = NULL, * savePtr = NULL;
	char srcdata[ sdata->srclen + 1];
	memcpy( srcdata, sdata->src, sdata->srclen);
	srcdata[ sdata->srclen] = 0;
	
	part = strtok_r( srcdata, splitter, &savePtr);
	
	while( part && sdata->count < 10)
	{
		strcpy( sdata->tokens[sdata->count], part);
		sdata->count++;
		
		if(!savePtr) break;
		
		part = strtok_r( savePtr, splitter, &savePtr);
	}
}

void __si_StringToDate( char * cDate, struct tm * st_datetime)
{
	memset( st_datetime, 0, sizeof(struct tm));
	
	char data[30];
	memset( data, 0, sizeof(data));
	memcpy( data, cDate, strlen(cDate));
	
	//printf("data=%s  %s|%d\n", data, __FILE__, __LINE__);
	
	int dt_date = 0, dt_month = 0, dt_year = 0;
	
	char * part = NULL, * savePtr = NULL;
	
	part = strtok_r( data, "-", &savePtr);
	
	//printf("savePtr=%s  %s|%d\n", savePtr, __FILE__, __LINE__);
	
	if( part)
	{
		dt_date = atoi( part);
	}
	
	part = strtok_r( savePtr, "-", &savePtr);
	//printf("part=%s savePtr=%s  %s|%d\n", part, savePtr, __FILE__, __LINE__);
	
	if( part)
	{
		dt_month = atoi( part);
	}
	
	//printf( "%s\n", savePtr);
	
	dt_year = atoi( savePtr);
	
	//printf("dt_year=%d dt_month=%d dt_date=%d  %s|%d\n", dt_year, dt_month, dt_date, __FILE__, __LINE__);
	
	st_datetime->tm_year 	= dt_year-1900;
	st_datetime->tm_mon 	= (dt_month-1);	// 0 - jan, 11 - dec
	st_datetime->tm_mday 	= dt_date;	//expiry date 
	st_datetime->tm_hour	= 0;
 	st_datetime->tm_min		= 0;
	st_datetime->tm_sec		= 0;	
	
	time_t st_time = mktime( st_datetime);
	
	/*
	printf("dt_year=%d[%d] dt_month=%d[%d] dt_date=%d[%d] st_time=%ld  %s|%d\n", 
		dt_year, st_datetime->tm_year, 
		dt_month, st_datetime->tm_mon, 
		dt_date, st_datetime->tm_mday, 
		st_time, __FILE__, __LINE__);
	/**/	
}

// dd-mm-yyyy
int __si_dateInRange( char * cStartDate, char * cEndDate)
{
	//printf("cStartDate=%s cEndDate=%s\n", cStartDate, cEndDate);
	
	struct tm st_datetime;
	struct tm end_datetime;

	__si_StringToDate( cStartDate, &st_datetime);
	__si_StringToDate( cEndDate, &end_datetime);	
	
	//end_datetime.tm_hour = 24;
	
	time_t st_time = mktime( &st_datetime);
	time_t ed_time = mktime( &end_datetime);
	
	struct timezone tzone;
	struct timeval ctimeval;
	
	memset( &tzone, 0, sizeof(struct timezone));
	memset( &ctimeval, 0, sizeof(struct timeval));
	
	gettimeofday( &ctimeval, &tzone);
	
	//if( st_time  )
	
	/*
	current-time=1626399729 
	     st_time=1626287400
		 ed_time=1627583400
	*/

	/*
	printf( "current-time=%ld st_time=%ld  ed_time=%ld diff-time=%ld (ed_time - current-time) \n", 
		ctimeval.tv_sec, st_time, ed_time, (ed_time - ctimeval.tv_sec));
	*/
	
	if( st_time < ctimeval.tv_sec && ed_time > ctimeval.tv_sec)
		return 1;

	return 0;
}	

uint64_t __si_uniqueno( uint64_t yeild)
{
	
	struct timeval tv;
	struct timezone tzone;
	gettimeofday( &tv, &tzone);

	//struct timespec ts;
	//ts.tv_sec = 0;
	//ts.tv_nsec = 0;	//The value of the nanoseconds field must be in the range 0 to 999999999.
	//int nanosleep(const struct timespec *req, struct timespec *rem);
	
	return ((uint64_t) tv.tv_sec) + tv.tv_usec + yeild;
	//return ((uint64_t) tv.tv_sec) + yeild;
}

void __si_makeFileName( char * mFileNameBuffer, char * mPath, char * mFileName, uint64_t numb, char * ext)
{
	sprintf( mFileNameBuffer, "%s/%s_%lu.%s", mPath, mFileName, numb, ext);	
}

void __si_makeDateTimeFileName( char * mFileNameBuffer, char * mPath, char * mFilePrefix, char * ext)
{
	struct timeval tv;
	struct timezone tzone;
	gettimeofday( &tv, &tzone);	
	
	struct tm *timeinfo = gmtime( &tv.tv_sec);
	
	sprintf( mFileNameBuffer, 
		"%s/%s_%02d_%02d_%d_%02d_%02d_%02d_%06lu.%s",
		mPath, mFilePrefix, 
		timeinfo->tm_mday, 
		(timeinfo->tm_mon) + 1, 
		(timeinfo->tm_year) + 1900, 
		timeinfo->tm_hour, 
		timeinfo->tm_min, 
		timeinfo->tm_sec, 
		tv.tv_usec, ext);
}

void __si_makeIntFileName( char *mFileNameBuffer, char * mPath, char * mFilePrefix, int * iFileIndex)
{
	struct timeval tv;
	struct timezone tzone;
	gettimeofday( &tv, &tzone);
	
	if( __siCore)
	{	
		tv.tv_sec += __siCore->LocalTimeValue;	// 19800; 19800 is 5.30 hours
	}
	
	struct tm *timeinfo = gmtime( &tv.tv_sec);
	
	sprintf( mFileNameBuffer, 
		"%s/%s_%02d_%02d_%d_%02d_%02d_%02d_%06lu.log",
		mPath, mFilePrefix, 
		timeinfo->tm_mday, 
		(timeinfo->tm_mon) + 1, 
		(timeinfo->tm_year) + 1900, 
		timeinfo->tm_hour, 
		timeinfo->tm_min, 
		timeinfo->tm_sec, 
		tv.tv_usec);
}


void __si_StartExecTime( SI_ExecTime * oExecTime)
{
	struct timezone tzone;	
	gettimeofday( &oExecTime->before, &tzone);
	
	oExecTime->after.tv_usec = 0;
	oExecTime->after.tv_sec = 0;
	
	oExecTime->lapsed.tv_usec = 0;
	oExecTime->lapsed.tv_sec = 0;
}


void __si_EndExecTime( SI_ExecTime * oExecTime)
{
	struct timezone tzone;	
	gettimeofday( &oExecTime->after, &tzone);
	
	if ( oExecTime->before.tv_usec > oExecTime->after.tv_usec)
	{
		oExecTime->after.tv_usec += 1000000;
		oExecTime->after.tv_sec--;
	}
	
	oExecTime->lapsed.tv_usec = oExecTime->after.tv_usec - oExecTime->before.tv_usec;
	oExecTime->lapsed.tv_sec  = oExecTime->after.tv_sec  - oExecTime->before.tv_sec;	
}

int __si_fileExists( char * fileName)
{
	if( access( fileName, F_OK ) != -1 ) 
	{
		// file exists
		return 1;
	} 
	else 
	{
		// file doesn't exist
		return -1;
	}
}

/*
SI_IntLeaf * __si_createRootIntLeaf()
{
	SI_IntLeaf * intLeaf 	= (SI_IntLeaf *) __si_malloc( sizeof(SI_IntLeaf));
	intLeaf->Nodes 			= (SI_IntLeaf *) __si_malloc( sizeof(SI_IntLeaf) * 10);
	intLeaf->Value 			= -1;
	intLeaf->GenId			= -1;
	intLeaf->DataPtr 		= NULL;
	
	int i = 0;
	for( i = 0; i < 10; i++)
	{
		intLeaf->Nodes[i].Value 	= i;
		intLeaf->Nodes[i].Nodes 	= NULL;
		intLeaf->Nodes[i].DataPtr 	= NULL;
		intLeaf->Nodes[i].GenId		= 0;		
	}
	
	return intLeaf;
}
*/

void __si_allocateIntLeafNodes( SI_IntLeaf * intLeaf)
{
	//intLeaf->Nodes 			= (SI_IntLeaf *) __si_malloc( sizeof(SI_IntLeaf) * 10);
	__si_malloc2( ( sizeof(SI_IntLeaf) * 10), (uint8_t **) &intLeaf->Nodes);

	int i = 0;
	for( i = 0; i < 10; i++)
	{
		intLeaf->Nodes[i].Value 		= i;
		intLeaf->Nodes[i].Nodes 		= NULL;
		intLeaf->Nodes[i].DataPtr 		= NULL;
		intLeaf->Nodes[i].GenId 		= (intLeaf->GenId + 1);
	}	
}

void __si_initalizeRootIntLeaf( SI_IntLeafRoot * intRootLeaf)
{
	memset( intRootLeaf, 0, sizeof(SI_IntLeafRoot));
	pthread_mutex_init( &intRootLeaf->Lock, NULL);
	
	//intRootLeaf->LeafRoot = (SI_IntLeaf *) __si_malloc( sizeof(SI_IntLeaf));
	__si_malloc2( sizeof(SI_IntLeaf), (uint8_t **) &intRootLeaf->LeafRoot);
	
	intRootLeaf->LeafRoot->Value 			= 0;
	intRootLeaf->LeafRoot->GenId			= 0;
	intRootLeaf->LeafRoot->DataPtr 			= NULL;	
}


void __si_setLeafPath( SI_LeafPath * oLeafPath, int intVal)
{
	memset( oLeafPath, 0, sizeof(SI_LeafPath));
	oLeafPath->iTotalLeafes = 0;
	int n = intVal;

	while ( n >= 10)
	{
		oLeafPath->leafValues[ oLeafPath->iTotalLeafes ] = (n % 10);
		n /= 10;
		oLeafPath->iTotalLeafes++;
	}
	
	oLeafPath->leafValues[ oLeafPath->iTotalLeafes ] = n;
	oLeafPath->iTotalLeafes++;
}

void __si_setIntLeafValue( SI_IntLeaf * leaf, SI_LeafPath * oLeafPath, int iLeafIndex, uint8_t * dataPtr)
{
	//printf( "iLeafIndex=%d   GenId=%d   TotalLeafes=%d   lV=%d\n", iLeafIndex, leaf->GenId, oLeafPath->iTotalLeafes, oLeafPath->leafValues[ iLeafIndex ]);
	
	if( iLeafIndex < (oLeafPath->iTotalLeafes - 1))
	{
		if( ! leaf->Nodes)
		{
			__si_allocateIntLeafNodes( leaf);
		}
		
		__si_setIntLeafValue( &leaf->Nodes[ oLeafPath->leafValues[ iLeafIndex ] ], oLeafPath, (iLeafIndex + 1), dataPtr);
	}
	else
	{
		//printf("setting value dataPtr=%p\n", dataPtr);		
		leaf->DataPtr = dataPtr;
	}
}

void __si_getIntLeafValue( SI_IntLeaf * leaf, SI_LeafPath * oLeafPath, int iLeafIndex, uint8_t ** dataPtr)
{
	//printf( "get iLeafIndex=%d   GenId=%d   TotalLeafes=%d   lV=%d\n", iLeafIndex, leaf->GenId, oLeafPath->iTotalLeafes, oLeafPath->leafValues[ iLeafIndex ]);
	
	if( iLeafIndex < (oLeafPath->iTotalLeafes - 1))
	{
		if( ! leaf->Nodes)
		{
			//Never come to this place for get
			__si_allocateIntLeafNodes( leaf);
		}
		
		__si_getIntLeafValue( &leaf->Nodes[ oLeafPath->leafValues[ iLeafIndex ] ], oLeafPath, (iLeafIndex + 1), dataPtr);
	}
	else
	{
		//printf("get setting value dataPtr=%p\n", dataPtr);		
		*dataPtr = leaf->DataPtr;
	}	
}

void __si_getIntValueToIntLeafRoot( SI_IntLeafRoot * rootIntLeaf, int iIntValue, uint8_t ** dataPtr)
{
	SI_LeafPath oLeafPath;
	__si_setLeafPath( &oLeafPath, iIntValue);

	if( oLeafPath.iTotalLeafes > 0)
	{
		__si_getIntLeafValue( rootIntLeaf->LeafRoot, &oLeafPath, 0, dataPtr);
	}		
}

void __si_setIntValueToIntLeafRoot( SI_IntLeafRoot * rootIntLeaf, int iIntValue, uint8_t * dataPtr)
{
	SI_LeafPath oLeafPath;
	__si_setLeafPath( &oLeafPath, iIntValue);
	
	if( oLeafPath.iTotalLeafes > 0)
	{	
		pthread_mutex_lock( &rootIntLeaf->Lock);
		
		__si_setIntLeafValue( rootIntLeaf->LeafRoot, &oLeafPath, 0, dataPtr);
		
		pthread_mutex_unlock( &rootIntLeaf->Lock);
	}
}

void __si_initalize_LeafLL( SI_IntLeafLL * oIntLeafLL, __si_addLL _addFunc, __si_findByIntLL _findByIntFunc, __si_findByIntAndRemoveLL _findByIntAndRemoveFunc)
{
	memset( oIntLeafLL, 0, sizeof(SI_IntLeafLL));
	//oIntLeafLL->Nodes 			= (SI_IntLeafLL *) __si_malloc( sizeof(SI_IntLeafLL) * 100);
	__si_malloc2( ( sizeof(SI_IntLeafLL) * 100), (uint8_t **) &oIntLeafLL->Nodes);
	
	oIntLeafLL->index = -1;
	pthread_mutex_init( &oIntLeafLL->Lock, NULL);
	
	int i = 0;
	for( i = 0; i < 100; i++)
	{
		oIntLeafLL->Nodes[i].addFunc = _addFunc;
		oIntLeafLL->Nodes[i].findByIntFunc = _findByIntFunc;
		oIntLeafLL->Nodes[i].findByIntAndRemoveFunc = _findByIntAndRemoveFunc;
		oIntLeafLL->Nodes[i].Count = 0;
		oIntLeafLL->Nodes[i].Head = oIntLeafLL->Nodes[i].Current = NULL;
		oIntLeafLL->Nodes[i].index = i;
		pthread_mutex_init( &oIntLeafLL->Nodes[i].Lock, NULL);
	}
}

void __si_addItemToLeafLL( SI_IntLeafLL * oIntLeafLL, uint8_t * item, uint32_t iVal)
{
	int index = (iVal % 100);
	
	if( oIntLeafLL->Nodes[index].addFunc)
	{
		oIntLeafLL->Nodes[index].addFunc( (void *) &oIntLeafLL->Nodes[index], item, iVal);
		
		pthread_mutex_lock( &oIntLeafLL->Lock);
		oIntLeafLL->Count++;
		pthread_mutex_unlock( &oIntLeafLL->Lock);
	}
}

void __si_findByIntAndRemoveLeafLL( SI_IntLeafLL * oIntLeafLL, uint8_t ** item, uint32_t iVal)
{
	int index = (iVal % 100);
	
	if( oIntLeafLL->Nodes[index].findByIntAndRemoveFunc)
	{
		oIntLeafLL->Nodes[index].findByIntAndRemoveFunc( (void *) &oIntLeafLL->Nodes[index], item, iVal);
		
		pthread_mutex_lock( &oIntLeafLL->Lock);
		oIntLeafLL->Count--;
		pthread_mutex_unlock( &oIntLeafLL->Lock);		
	}
}

int __si_do_mkdir( const char * path, mode_t mode)
{
    struct stat     st;
    int             status = 0;

    if (stat(path, &st) != 0)
    {
        if (mkdir(path, mode) != 0 && errno != EEXIST)
            status = -1;
    }
    else if (!S_ISDIR(st.st_mode))
    {
        errno = ENOTDIR;
        status = -1;
    }

    return(status);
}


int __si_mkpath( const char * path, mode_t mode)
{
    char	*pp;
    char    *sp;
    int     status;
    char    copypath[500];
	memset( copypath, 0, sizeof( copypath));
	strcpy( copypath, path);
	
    status = 0;
    pp = &copypath[0];
	
    while (status == 0 && (sp = strchr(pp, '/')) != 0)
    {
        if (sp != pp)
        {
            /* Neither root nor double slash in path */
            *sp = '\0';
            status = __si_do_mkdir( copypath, mode);
            *sp = '/';
        }
        pp = sp + 1;
    }
    
	if (status == 0)
        status = __si_do_mkdir( path, mode);
	
	return 0;
}


	
void __si_setall_log_prefix( char * logPrefix)
{
	char lp[4];
	
	if( strlen( logPrefix) > 3)
	{	
		memcpy( lp, logPrefix, 3);
		lp[3] = 0;
	}
	else
	{
		memcpy( lp, logPrefix, strlen( logPrefix));
		lp[3] = 0;		
	}
	__si_set_log_prefix( 0, lp);
	__si_set_log_prefix( 1, lp);
	__si_set_log_prefix( 2, lp);
	__si_set_log_prefix( 3, lp);
}

void __si_set_log_prefix( uint32_t mLogType, char * logPrefix)
{
	memset( __siCore->LogConfig[mLogType].Prefix, 0, sizeof(__siCore->LogConfig[mLogType].Prefix));
	
	switch( mLogType)
	{
		case 0:
			sprintf( __siCore->LogConfig[mLogType].Prefix, "%s_%s", logPrefix, "STK");
			break;
		case 1:
			sprintf( __siCore->LogConfig[mLogType].Prefix, "%s_%s", logPrefix, "PER");
			break;
		case 2:
			sprintf( __siCore->LogConfig[mLogType].Prefix, "%s_%s", logPrefix, "APP");
			break;
		case 3:
			sprintf( __siCore->LogConfig[mLogType].Prefix, "%s_%s", logPrefix, "BUF");
			break;			
		default:
			break;
	}
}

void __si_configure_log( uint32_t mLogType,  uint32_t mLogLevel, char * logPrefix, char * logPath, int iPrintTimeStamp)
{
	if( mLogType >= SI_STK_LOG && mLogType <= SI_CUS_LOG3)
	{
		if( mLogLevel >= SI_LOG_LOWER_LIMIT && mLogLevel <= SI_LOG_UPPER_LIMIT)
		{
			__siCore->LogConfig[mLogType].iLoggingThreshold 	= mLogLevel;
			__siCore->LogConfig[mLogType].PrintTimeStamp 		= iPrintTimeStamp;
			__siCore->LogConfig[mLogType].LineCount 			= 0;
			
			
			strcpy( __siCore->LogConfig[mLogType].Prefix, 	logPrefix);
			strcpy( __siCore->LogConfig[mLogType].Path, 	logPath);
			
			if( __siCore->LogConfig[mLogType].initalized == 0)
			{
				__siCore->LogConfig[mLogType].initalized 	= 1;
				__siCore->LogConfig[mLogType].iHandle 		= -1;
				pthread_mutex_init( &__siCore->LogConfig[mLogType].Lock, NULL);
			}
			
			struct stat st = {0};
			
			if ( stat( logPath, &st) == -1) {
				__si_mkpath( logPath, 0700);
			}
			
			//printf("done log init logPath=%s core.c|%d\n", logPath, __LINE__);
		}
		/*
		else
		{
			printf("else core.c|%d\n", __LINE__);
		}
		*/
	}
	else
	{
		printf("else core.c|%d\n", __LINE__);
	}	
}


void __si_set_log_level( uint32_t mLogType,  uint32_t mLogLevel)
{
	if( mLogType >= SI_STK_LOG && mLogType <= SI_CUS_LOG3)
	{
		if( mLogLevel >= SI_LOG_LOWER_LIMIT && mLogLevel <= SI_LOG_UPPER_LIMIT)
		{
			__siCore->LogConfig[mLogType].iLoggingThreshold = mLogLevel;
		}
	}
}


void __si_set_log_enable_disable( uint32_t mLogType,  int isEnabled)
{
	if( mLogType >= SI_STK_LOG && mLogType <= SI_CUS_LOG3)
	{
		__siCore->LogConfig[mLogType].Enabled = isEnabled;
	}
}


void __si_log_cat_enable_disable( uint32_t mLogType, uint32_t icat, int isEnabled)
{
	__siCore->LogConfig[mLogType].LogCat[icat].iEnabled = isEnabled;
}


void __si_log_cat_setName( uint32_t mLogType, uint32_t icat, char * catName)
{
	strcpy( __siCore->LogConfig[ mLogType ].LogCat[ icat ].sCatName, catName);
}


void __si_log_cat_enable_all( uint32_t mLogType)
{
	int i = 0;
	for( i = 0; i < 30; i++) {
		__si_log_cat_enable_disable( mLogType, i, 1);
	}
}


void __si_log_cat_disable_all( uint32_t mLogType)
{
	int i = 0;
	for( i = 0; i < 30; i++) {
		__si_log_cat_enable_disable( mLogType, i, 0);
	}
}

void __si_set_logger_rootpath( char * rootPath)
{
	memcpy( __siCore->LogRootPath, rootPath, strlen( rootPath));	
}

void __si_init_logger( char * rootPath)
{
	char stkPath[400];
	memset( stkPath, 0, sizeof( stkPath));

	char perPath[400];
	memset( perPath, 0, sizeof( perPath));

	char appPath[400];
	memset( appPath, 0, sizeof( appPath));

	char cmnPath[400];
	memset( cmnPath, 0, sizeof( cmnPath));

	memcpy( __siCore->LogRootPath, rootPath, strlen( rootPath));

	sprintf( stkPath, "%s/stk", rootPath);
	sprintf( perPath, "%s/per", rootPath);
	sprintf( appPath, "%s/app", rootPath);
	sprintf( cmnPath, "%s/cmn", rootPath);
	
	
	int i = 0;
	for( i = 0; i < 6; i++)
	{
		switch(i) 
		{
			case 0:
				//__si_configure_log( i, 5, (char *)"STK", (char *)"./logs/stk/", 1);
				__si_configure_log( i, 5, (char *)"STK", stkPath, 1);
				break;
			case 1:
				//__si_configure_log( i, 5, (char *)"PER", (char *)"./logs/per/", 1);
				__si_configure_log( i, 5, (char *)"PER", perPath, 0);
				break;
			case 2:
				//__si_configure_log( i, 5, (char *)"APP", (char *)"./logs/app/", 1);
				__si_configure_log( i, 5, (char *)"APP", appPath, 1);
				break;
			case 3:
				//__si_configure_log( i, 5, (char *)"APP", (char *)"./logs/app/", 1);
				__si_configure_log( i, 5, (char *)"CMN", cmnPath, 1);
				break;
			default:
				//__si_configure_log( i, 5, (char *)"CMN", (char *)"./logs/cmn/", 1);
				__si_configure_log( i, 5, (char *)"CMN", cmnPath, 1);
				break;
		}
		__si_set_log_enable_disable(i, 1);
		__si_log_cat_enable_all(i);
	}
}

void __si_init_logger2( char * rootPath)
{
	char stkPath[400];
	memset( stkPath, 0, sizeof( stkPath));

	char perPath[400];
	memset( perPath, 0, sizeof( perPath));

	char appPath[400];
	memset( appPath, 0, sizeof( appPath));

	char cmnPath[400];
	memset( cmnPath, 0, sizeof( cmnPath));

	memcpy( __siCore->LogRootPath, rootPath, strlen( rootPath));

	sprintf( stkPath, "%s", rootPath);
	sprintf( perPath, "%s/peg", rootPath);
	sprintf( appPath, "%s/app", rootPath);
	sprintf( cmnPath, "%s/cmn", rootPath);
	
	__si_configure_log( 0, 5, (char *)"SS7", stkPath, 1);
	__si_set_log_enable_disable(0, 1);
	__si_log_cat_enable_all(0);
	
	/*
	int i = 0;
	for( i = 0; i < 6; i++)
	{
		switch(i) 
		{
			case 0:
				//__si_configure_log( i, 5, (char *)"STK", (char *)"./logs/stk/", 1);
				__si_configure_log( i, 5, (char *)"CORE", stkPath, 1);
				break;
			case 1:
				//__si_configure_log( i, 5, (char *)"PER", (char *)"./logs/per/", 1);
				__si_configure_log( i, 5, (char *)"PEG", perPath, 1);
				break;
			case 2:
				//__si_configure_log( i, 5, (char *)"APP", (char *)"./logs/app/", 1);
				__si_configure_log( i, 5, (char *)"APP", appPath, 1);
				break;
			case 3:
				//__si_configure_log( i, 5, (char *)"APP", (char *)"./logs/app/", 1);
				__si_configure_log( i, 5, (char *)"BUF", cmnPath, 0);
				break;
			default:
				//__si_configure_log( i, 5, (char *)"CMN", (char *)"./logs/cmn/", 1);
				__si_configure_log( i, 5, (char *)"CMN", cmnPath, 0);
				break;
		}
		__si_set_log_enable_disable(i, 1);
		__si_log_cat_enable_all(i);
	}
	*/
	
}



void __si_configure_log2( uint32_t mLogType, uint32_t mLogLevel)
{
	if( mLogType >= SI_STK_LOG && mLogType <= SI_CUS_LOG3)
	{
		if( mLogLevel >= SI_LOG_LOWER_LIMIT && mLogLevel <= SI_LOG_UPPER_LIMIT)
		{	
			char stkPath[400];
			memset( stkPath, 0, sizeof( stkPath));

			char perPath[400];
			memset( perPath, 0, sizeof( perPath));

			char appPath[400];
			memset( appPath, 0, sizeof( appPath));

			char cmnPath[400];
			memset( cmnPath, 0, sizeof( cmnPath));

			sprintf( stkPath, "%s/stk", __siCore->LogRootPath);
			sprintf( perPath, "%s/per", __siCore->LogRootPath);
			sprintf( appPath, "%s/app", __siCore->LogRootPath);
			sprintf( cmnPath, "%s/cmn", __siCore->LogRootPath);	
			
			switch( mLogType) 
			{
				case 0:
					__si_configure_log( mLogType, 5, (char *)"STK", stkPath, 1);
					break;
				case 1:
					__si_configure_log( mLogType, 5, (char *)"PER", perPath, 1);
					break;
				case 2:
					__si_configure_log( mLogType, 5, (char *)"APP", appPath, 1);
					break;
				case 3:
					__si_configure_log( mLogType, 5, (char *)"BUF", cmnPath, 1);
					break;
				default:
					__si_configure_log( mLogType, 5, (char *)"CMN", cmnPath, 1);
					break;
			}
			
			__si_set_log_enable_disable( mLogType, 1);
			__si_log_cat_enable_all( mLogType);
		}
	}
}
//static int inotified_logger_init = 0;




SI_LinkedList * __si_readdir( char * dir)
{
	SI_LinkedList * ll = __si_linked_list_allocate();
	
	DIR * directory = opendir( dir);
	
	if( directory)
	{
		struct dirent * entry = readdir( directory);
	
		while( entry)
		{
			if( entry->d_type == DT_REG && entry->d_name[0] != '.' && strlen(entry->d_name) > 0)
			{
				__si_linked_list_add( ll, (uint8_t*)__si_strdup( entry->d_name));
			}
			
			entry = readdir( directory);
		}
		closedir( directory);
	} 
	
	return ll;
}


int __si_stringv_init( __si_stringv_t * str, int maxlen)
{
	u_char * val = (u_char *)__si_allocM7( maxlen + 1, __FILE__, __LINE__, 0);
	
	if( val)
	{	
		__si_stringv_setr( str, val, maxlen);
		return 1;
	}
	
	return 0;
}

void __si_stringv_memset( __si_stringv_t * str)
{
	if( str->pos > 0)
	{
		memset( str->val, 0, str->pos);
		str->pos = 0;
	}
}

void __si_stringv_append( __si_stringv_t * str, char * mLine, int len)
{
	if( str->val && (str->pos + len) < str->len)
	{
		memcpy( &str->val[str->pos], mLine, len);
		str->pos += len;
	}
}

void __si_stringv_appendline( __si_stringv_t * str, char * mLine, ...)
{
    char f_buffer[LOGGER_BUFFER_SIZE];
	memset( f_buffer, '\0', sizeof(f_buffer));

    va_list args;// = 0;
    va_start( args, mLine);
    vsnprintf( f_buffer, LOG_MESSAGE_MAX_SIZE, mLine, args);
	va_end( args);
	
	__si_stringv_append( str, f_buffer, strlen(f_buffer));
}

void __si_stringv_printf( __si_stringv_t * str)
{
	//putc
	int i = 0;
	while( i < str->pos)
	{
		putchar( str->val[i]);
		i++;
	}
}

void __si_log( uint32_t mLogType, uint32_t mLogCat, uint32_t mLogLevel, char* mLogMessage, ...)
{
	//printf("mLogType=%u mLogCat=%u mLogLevel=%u\n", mLogType, mLogCat, mLogLevel);
	
	//return;
	if(!(mLogType >= SI_STK_LOG && mLogType <= SI_CUS_LOG3))
	{
		printf("invalid log cat, should be between 0 and 6<%s|%s|%d>\n", __FILE__, __FUNCTION__, __LINE__ );
		return;
	}
	
	if(__siCore->LogConfig[mLogType].initalized == 0)
	{
		if( __siCore->LogConfig[mLogType].initnotified == 0) 
		{
			__siCore->LogConfig[mLogType].initnotified = 1;
			//printf("Logger Not initalized <%s|%s|%d>\n", __FILE__, __FUNCTION__, __LINE__ );		
			printf("Logger Not initalized LogType=%u LogLevel=%u <core.c|%d>\n", mLogType, mLogLevel, __LINE__ );
			__si_configure_log2( mLogType, mLogLevel);
		}
		
		return;
	}
	
	if( __siCore->LogConfig[mLogType].Enabled != 1)
	{
		//printf("<%s|%s|%d>\n", __FILE__, __FUNCTION__, __LINE__ );
		return;
	}

	if( __siCore->LogConfig[mLogType].LogCat[mLogCat].iEnabled != 1 && mLogLevel != SI_LOG_CRITICAL)
	{
		printf("mLogType=%d mLogCat=%d <%s|%s|%d>\n", mLogType, mLogCat, __FILE__, __FUNCTION__, __LINE__ );
		return;
	}
	
	if( ! (mLogCat >= 0 && mLogCat < 30))
	{
		printf("invalid log cat, should be between 0 and 30 <%s|%s|%d>\n", __FILE__, __FUNCTION__, __LINE__ );
		return;
	}

	SI_LogConfig * iLog = &__siCore->LogConfig[mLogType];
	
	if( ( mLogLevel < SI_LOG_LOWER_LIMIT) || ( mLogLevel > SI_LOG_UPPER_LIMIT) || ( mLogLevel > iLog->iLoggingThreshold))
    {
		//printf("<%s|%s|%d>\n", __FILE__, __FUNCTION__, __LINE__ );
		return;
    }
	
    if( !mLogMessage || (LOG_MESSAGE_MAX_SIZE < (int)strlen(mLogMessage)) )	
	{	
		//printf("<%s|%s|%d>\n", __FILE__, __FUNCTION__, __LINE__ );
		return;
	}

	pthread_mutex_lock ( &iLog->Lock);
	
    char* debugTag;
    unsigned long ulThreadID = pthread_self();
    
    char m_buffer[LOGGER_BUFFER_SIZE];
    char f_buffer[LOGGER_BUFFER_SIZE + 100];
	
    char dateString[28];

    memset( &dateString, '\0', sizeof( dateString));
    __si_makeTimeStamp( &dateString[0]);

	memset( m_buffer, '\0', sizeof(m_buffer));
	memset( f_buffer, '\0', sizeof(f_buffer));

    va_list args;// = 0;
    va_start( args, mLogMessage);
    vsnprintf( m_buffer, LOG_MESSAGE_MAX_SIZE, mLogMessage, args);
	va_end( args);
	
	switch( mLogLevel)
	{
		case SI_LOG_CRITICAL:
			debugTag = "[C]";
			break;
		case SI_LOG_ERROR:
			debugTag = "[E]";
			break;
		case SI_LOG_WARNING:
			debugTag = "[W]";
			break;
		case SI_LOG_NORMAL:
			debugTag = "[I]";
			break;
		case SI_LOG_DEBUG:
			debugTag = "[D]";
			break;
		default:
			debugTag = "[E]";
			break;
	}
	
	if( iLog->PrintTimeStamp == 1) 
	{
		//sprintf( f_buffer, "%s|%s|%lu|%s|%s\n", debugTag, dateString, ulThreadID, __siCore->LogConfig[ mLogType ].LogCat[ mLogCat ].sCatName, m_buffer);	
		//sprintf( f_buffer, "%s|%s|%s|%s\n", debugTag, dateString, __siCore->LogConfig[ mLogType ].LogCat[ mLogCat ].sCatName, m_buffer);
		sprintf( f_buffer, "%s|%s|%lu|%s|%s\n", debugTag, dateString, ulThreadID, __siCore->LogConfig[ mLogType ].LogCat[ mLogCat ].sCatName, m_buffer);
	} 
	else 
	{
		sprintf( f_buffer, "%s\n", m_buffer);
	}
	
	//printf("log to wrtte=%s\n", f_buffer);
	
	int bRotate = 0;
	
	if( iLog->LineCount >= 70000) 
	{
		bRotate = 1;
		
		if( iLog->iHandle != -1)
			close( iLog->iHandle);
	}
	
	if( bRotate == 1 || iLog->iHandle == -1)
	{
		iLog->LineCount = 0;

		char mFileNameBuffer[500];
		memset( &mFileNameBuffer, 0, 500);
		__si_makeIntFileName( &mFileNameBuffer[0], iLog->Path, iLog->Prefix, &iLog->iFileIndex);
		
		int iUmask 				= S_IWGRP | S_IWOTH;
		int iFileCreationMode 	= S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
		int iFlags 				= O_WRONLY | O_CREAT | O_APPEND;
		int iOldUmask 			= umask( iUmask);
		
		__si_mkpath( iLog->Path, 0700);
		iLog->iHandle = open( mFileNameBuffer, iFlags, iFileCreationMode);	
		
		umask( iOldUmask);
	}
	
	iLog->LineCount++;
	write( iLog->iHandle, f_buffer, strlen( f_buffer));
	
	pthread_mutex_unlock ( &iLog->Lock);	
}



void __si_addStreamToStream( SI_Stream * _root_stream, SI_Stream * _stream)
{
	if(!_root_stream->StreamHead)
	{
		_root_stream->StreamHead = _root_stream->StreamCurrent = _stream;
	}
	else
	{
		_root_stream->StreamCurrent->PoolNext = _stream;
		_root_stream->StreamCurrent = _stream;
	}
}


uint32_t __si_getStreamLength( SI_Stream * _stream)
{
	if(_stream)
	{
		SI_Stream * _root_stream = _stream;
		
		//printf("r. _stream=%p _stream->len=%d <%s|%s|%d>\n", _stream, _stream->len, __FILE__, __FUNCTION__ , __LINE__);
		
		uint32_t len = 0;
		
		len += _root_stream->len;
		_stream = _root_stream->StreamHead;
		
		while( _stream)
		{
			//printf("c._stream=%p len=%d _stream->len=%d <%s|%s|%d>\n", _stream, len, _stream->len, __FILE__, __FUNCTION__ , __LINE__);
			
			len += _stream->len;
			_stream = _stream->PoolNext;
		}
		
		//printf("f. len=%d <%s|%s|%d>\n", len, __FILE__, __FUNCTION__ , __LINE__);		
		
		return len;
	}
	return 0;
}


uint32_t __si_copyStreamBuffer( SI_Stream * _stream, char * buffer)
{
	int bPos = 0;
	
	if( _stream)
	{
		memcpy( &buffer[ bPos], _stream->buffer, _stream->len);
		bPos += _stream->len;
		
		SI_Stream * _root_stream = _stream;
		_stream = _root_stream->StreamHead;
		
		while( _stream)
		{
			memcpy( &buffer[ bPos], _stream->buffer, _stream->len);
			
			bPos += _stream->len;
			_stream = _stream->PoolNext;
		}
	}
	
	return bPos;
}


void __si_addBufferToStream( SI_Stream * _stream, char * buffer, int iLength)
{
	int _bytesCanCopy = ( SI_STREAM_STRUCT_SIZE - _stream->len);
	
	if( _bytesCanCopy > iLength)
	{
		memcpy( &_stream->buffer[_stream->len], buffer, iLength);
		_stream->len = (_stream->len + iLength);
	}
	else
	{
		SI_Stream * _root_stream = _stream;
		
		memcpy( &_stream->buffer[_stream->len], buffer, _bytesCanCopy);
		_stream->len = (_stream->len + _bytesCanCopy);		
		
		int iRemainingBufferLength = (iLength - _bytesCanCopy);
		int iBufferPos = _bytesCanCopy;
		int iMaxLength = SI_STREAM_STRUCT_SIZE;
		
		while( iRemainingBufferLength > 0)
		{
			_stream = __si_allocateStream();
			
			if( iMaxLength >= iRemainingBufferLength )
			{
				memcpy( _stream->buffer, &buffer[iBufferPos], iRemainingBufferLength);
				_stream->len = iRemainingBufferLength;
				iRemainingBufferLength -= iRemainingBufferLength;
				iBufferPos += iRemainingBufferLength;
			}
			else
			{
				memcpy( _stream->buffer, &buffer[iBufferPos], iMaxLength);
				_stream->len = iMaxLength;
				iRemainingBufferLength -= iMaxLength;
				iBufferPos += iMaxLength;
			}
			
			__si_addStreamToStream( _root_stream, _stream);
		}
	}
}


void __si_addToStreamPool( SI_Stream * _stream, uint8_t bInLockMode)
{
	if(bInLockMode) 
	{
		pthread_mutex_lock( &__siCore->StreamLock);
	}
	
	if( _stream->isReleased == 0)
	{	
		if(!__siCore->StreamHead) {
			__siCore->StreamHead = __siCore->StreamCurrent = _stream;
		}
		else {
			__siCore->StreamCurrent->PoolNext = _stream;
			__siCore->StreamCurrent = _stream;
		}
		
		_stream->isReleased = 1;
		__siCore->StreamPoolAvailableCount++;
	}
	
	if(bInLockMode) 
	{
		pthread_mutex_unlock( &__siCore->StreamLock);
	}	
}

void __si_releaseStream( SI_Stream * _stream)
{
	SI_Stream * _root_stream = _stream;
	SI_Stream * _streamNext = NULL;
	_stream = _root_stream->StreamHead;
	
	while( _stream)
	{
		_streamNext = _stream->PoolNext;
		_stream->PoolNext = NULL;
		
		__si_addToStreamPool( _stream, 1);
		
		_stream = _streamNext;
	}
	
	__si_addToStreamPool( _root_stream, 1);
}

//stream-pool
void __si_createStreamPool( int iSize, uint8_t bInLockMode)
{
	if( iSize == 0) return;
	
	//long totalAllocatedSize = 0;
	SI_Stream * _stream = NULL;
	
	uint8_t * _fblock = calloc( iSize, sizeof(SI_Stream));
	
	if(!_fblock)
	{
		printf("calloc failed %s|%s|%d\n", __FILE__, __FUNCTION__, __LINE__);
		return;
	}
	
	int i;
	for( i = 0; i < iSize; i++)
	{
		//SI_Stream * _stream = (SI_Stream *) __si_malloc(sizeof(SI_Stream));
		//__si_malloc2( sizeof(SI_Stream), (uint8_t **) &_stream);
		
		_stream = (SI_Stream *)_fblock;
		
		//totalAllocatedSize += sizeof(SI_Stream);
		
		memset( _stream, 0, sizeof(SI_Stream));
		//_stream->PoolNext = NULL; //already doing memset above
		
		_stream->isReleased = 0;
		__si_addToStreamPool( _stream, bInLockMode);
		__siCore->StreamPoolCount++;
		
		_fblock += sizeof(SI_Stream);
	}
	
	//printf( "memory reserved for StreamPool = %ld with size=%d\n", totalAllocatedSize, iSize);
	//printf("created stream pool %d\n", iSize);
}


SI_Stream * __si_allocateStream()
{
	SI_Stream * _stream = NULL;
	pthread_mutex_lock( &__siCore->StreamLock);
	
	_stream = __siCore->StreamHead;
	
	if(!_stream)
	{
		__si_createStreamPool( 1000, 0);
		_stream = __siCore->StreamHead;
	}
	
	if(_stream)
	{
		__siCore->StreamHead = _stream->PoolNext;
		_stream->PoolNext = NULL;		
	}
	
	__siCore->StreamPoolAvailableCount--;
	
	pthread_mutex_unlock( &__siCore->StreamLock);
	
	_stream->isReleased = 0;
	_stream->Head = NULL;
	_stream->Current = NULL;
	_stream->StreamHead = NULL;
	_stream->StreamCurrent = NULL;
	
	return _stream;
}


void __si_addToEventPool( SI_Event * _event, uint8_t bInLockMode)
{
	if(bInLockMode) 
	{
		pthread_mutex_lock( &__siCore->EventLock);
	}
	
	if(!__siCore->EventHead) 
	{
		__siCore->EventHead = __siCore->EventCurrent = _event;
	}
	else 
	{
		__siCore->EventCurrent->PoolNext = _event;
		__siCore->EventCurrent = _event;
	}
	
	_event->isReleased = 1;
	__siCore->EventPoolAvailableCount++;
	
	if(bInLockMode) 
	{
		pthread_mutex_unlock( &__siCore->EventLock);
	}	
}

int  __si_TotalTimerPoolCount()
{
	return __siCore->TotalTimerPoolCount;
}

int  __si_AvailableTimerPoolCount()
{
	return __siCore->AvailableTimerPoolCount;
}

int  __si_UsedTimerPoolCount()
{
	return __siCore->UsedTimerPoolCount;
}



void __si_add_timer_to_pool( SI_Timer * _timer, int inLockMode)
{
	if( inLockMode)
	{
		pthread_mutex_lock( &__siCore->TimerLock);
	}
	
	if( _timer->isReleased == 0)
	{	
		if( !__siCore->TimerHead)
		{
			__siCore->TimerHead = __siCore->TimerCurrent = _timer;
		}
		else
		{
			__siCore->TimerCurrent->Next = _timer;
			__siCore->TimerCurrent = _timer;
		}
		_timer->isReleased = 1;
		__siCore->AvailableTimerPoolCount++;
	}
	
	if( inLockMode)
	{
		pthread_mutex_unlock( &__siCore->TimerLock);
	}	
}

void __si_timer_create( int isize, int inLockMode)
{
	long totalAllocatedSize = 0;
	SI_Timer * _timer = NULL;
	
	int i;
	for( i = 0; i < isize; i++)
	{
		//SI_Timer * _timer = (SI_Timer *) __si_malloc( sizeof( SI_Timer));
		__si_malloc2( sizeof( SI_Timer), (uint8_t **) &_timer);
		
		totalAllocatedSize += sizeof( SI_Timer);
		
		memset( _timer, 0, sizeof( SI_Timer));
		
		__si_add_timer_to_pool( _timer, inLockMode);
		__siCore->TotalTimerPoolCount++;
	}
	
	//printf( "memory reserved for TimerPool = %ld, with size=%d\n", totalAllocatedSize, isize);	
}

SI_Timer * __si_allocate_timer()
{
	pthread_mutex_lock( &__siCore->TimerLock);

	SI_Timer * _timer = __siCore->TimerHead;

	if(!_timer)
	{
		__si_timer_create( 1000, 0);
		_timer = __siCore->TimerHead;
	}
	
	if( _timer)
	{
		__siCore->TimerHead = _timer->Next;
		_timer->Next = NULL;
		
		__siCore->UsedTimerPoolCount++;
		__siCore->AvailableTimerPoolCount--;
		_timer->isReleased = 0;
	}
	
	pthread_mutex_unlock( &__siCore->TimerLock);
	
	return _timer;
}

void __si_release_timer( SI_Timer * _timer)
{
	__si_add_timer_to_pool( _timer, 1);
}


int __si_core_sch_at( int seconds)
{
	int schAt = __siCore->TimerTickIndex + seconds;
	
	if( schAt >= MAX_TIMER_TICKS)
	{
		schAt = schAt - MAX_TIMER_TICKS;
	}
	
	if( schAt == MAX_TIMER_TICKS)
	{
		schAt = 0;
	}
	
	return schAt;
}

void __si_core_sch_timer( SI_Timer * _timer, int seconds)
{
	int schAt = __siCore->TimerTickIndex + seconds;
	
	if( schAt >= MAX_TIMER_TICKS)
	{
		schAt = schAt - MAX_TIMER_TICKS;
	}
	
	if( schAt == MAX_TIMER_TICKS)
	{
		schAt = 0;
	}
	
	if( schAt >= 0 && schAt < MAX_TIMER_TICKS)
	{
		SI_Timer_Tick * _ticker = &__siCore->Timers[schAt];
		
		pthread_mutex_lock( &_ticker->Lock);
		
		if(!_ticker->Head)
		{
			_ticker->Head = _ticker->Current = _timer;
		}
		else
		{
			_ticker->Current->Next = _timer;
			_ticker->Current = _timer;
		}
		
		pthread_mutex_unlock( &_ticker->Lock);
	}
}

void __si_add_app_event_handler( app_event_handler handler) 
{
	SI_AppEventInfo * appEventInfo = NULL; //(SI_AppEventInfo * )malloc( sizeof(SI_AppEventInfo));
	__si_malloc2( sizeof(SI_AppEventInfo), (uint8_t **)&appEventInfo);
	
	appEventInfo->handler = handler;
	appEventInfo->Next = NULL;
	
	pthread_mutex_lock( &__siCore->AppEventInfoLock);
	
	if(!__siCore->AppEventInfoHead)
	{
		__siCore->AppEventInfoHead = __siCore->AppEventInfoCurrent = appEventInfo;
	}
	else
	{
		__siCore->AppEventInfoCurrent->Next = appEventInfo;
		__siCore->AppEventInfoCurrent = appEventInfo;
	}
	
	pthread_mutex_unlock( &__siCore->AppEventInfoLock);
}

void * __si_app_events_thread( void * args)
{
	SI_AppEventInfo * appEventInfo = NULL;
	
	while(1)
	{
		appEventInfo = __siCore->AppEventInfoHead;
		
		while(appEventInfo)
		{
			if( appEventInfo->handler > 0)
			{
				appEventInfo->handler();
			}
			appEventInfo = appEventInfo->Next;
		}
		usleep( 999999);
	}
}

void * __si_timer_thread( void * args)
{
	while(1)
	{
		__siCore->TimerTickIndex++;
		__siCore->SeverTimerTick++;
		
		if( __siCore->TimerTickIndex >= MAX_TIMER_TICKS )
		{
			__siCore->TimerTickIndex = 0;
		}
		
		//printf("TimerTickIndex=%d schAt=%d  %s|%s|%d\n", __siCore->TimerTickIndex, __si_core_sch_at( 7), __FILE__, __FUNCTION__, __LINE__);

		
		SI_Timer_Tick * _ticker = &__siCore->Timers[ __siCore->TimerTickIndex];
		
		pthread_mutex_lock( &_ticker->Lock);
		
		SI_Timer * _timer = _ticker->Head;
		SI_Timer * _prev_timer = NULL;
		
		while( _timer)
		{
			if(_timer->isCleared == 0)
			{	
				//if( _timer->data)
				{
					__si_core_queue( _timer->data, _timer->handler);
				}
			}
			
			_timer->data = NULL;
			_prev_timer = _timer;
			_timer = _timer->Next;
			
			_prev_timer->Next = NULL;
			__si_release_timer( _prev_timer);
			_prev_timer = NULL;
		}
		
		_ticker->Head = NULL;
		_ticker->Current = NULL;

		pthread_mutex_unlock( &_ticker->Lock);
		
		usleep( 999900);
	}
}

void __si_core_clear_timer( SI_Timer * _timer)
{
	if( _timer) {
		_timer->isCleared = 1;
	}	
}

SI_Timer * __si_core_start_timer( uint8_t * data, timer_handler handler, int seconds)
{
	//if( !data || !handler || seconds <= 0)
	if( !handler || seconds <= 0)	
		return NULL;
	
	SI_Timer * _timer = __si_allocate_timer();
	
	_timer->data = data;
	_timer->handler = handler;
	_timer->isCleared = 0;
	
	__si_core_sch_timer( _timer, seconds);
	
	return _timer;
}

void __si_add_queue_to_pool( SI_Queue * _queue, int inLockMode)
{
	if( inLockMode)
	{
		pthread_mutex_lock( &__siCore->QueueLock);
	}
	
	if(!__siCore->QueueHead)
	{
		__siCore->QueueHead = __siCore->QueueCurrent = _queue;
	}
	else
	{
		__siCore->QueueCurrent->Next = _queue;
		__siCore->QueueCurrent = _queue;
	}
	_queue->isReleased = 1;
	__siCore->AvailableQueuePoolCount++;

	if( inLockMode)
	{
		pthread_mutex_unlock( &__siCore->QueueLock);
	}
}

void __si_queue_create( int isize, int inLockMode)
{
	if( inLockMode)
	{
		pthread_mutex_lock( &__siCore->QueueLock);
	}
	
	long totalAllocatedSize = 0;
	
	int i;
	SI_Queue * _queue = NULL;
	
	for( i = 0; i < isize; i++)
	{
		//SI_Queue * _queue = (SI_Queue *) __si_malloc( sizeof( SI_Queue));
		
		__si_malloc2( sizeof( SI_Queue), (uint8_t **) &_queue);
		totalAllocatedSize += sizeof( SI_Queue);
		
		memset( _queue, 0, sizeof( SI_Queue));
		
		__si_add_queue_to_pool( _queue, 0);
		__siCore->TotalQueuePoolCount++;
	}

	/*	
	printf( "memory reserved for QueuePool = %ld, with count=%d used-times=%ld QueueLineCount=%d availPoolCount=%d totalPoolCount=%d\n", 
		totalAllocatedSize, isize, __siCore->QueueUsedTimes, __siCore->QueueLineCount, 
		__siCore->AvailableQueuePoolCount, __siCore->TotalQueuePoolCount);	
	*/
	
	if( inLockMode)
	{
		pthread_mutex_unlock( &__siCore->QueueLock);
	}	
}

SI_Queue * __si_allocate_queue()
{
	pthread_mutex_lock( &__siCore->QueueLock);

	SI_Queue * _queue = __siCore->QueueHead;

	if(!_queue)
	{
		__si_queue_create( 1000, 0);
		_queue = __siCore->QueueHead;
	}
	
	if( _queue)
	{
		__siCore->QueueHead = _queue->Next;
		_queue->Next = NULL;
		
		__siCore->AvailableQueuePoolCount--;
		_queue->isReleased = 0;
	}
	
	__siCore->QueueUsedTimes++;
	pthread_mutex_unlock( &__siCore->QueueLock);
	
	return _queue;
}

void __si_release_queue( SI_Queue * _queue)
{
	if( _queue->isReleased == 0)
	{
		__si_add_queue_to_pool( _queue, 1);
	}
}


void __si_releaseEvent( SI_Event * _event)
{
	if( _event->isReleased == 0)
	{	
		__si_addToEventPool( _event, 1);
	}	
}


void __si_createEventPool( int iSize, uint8_t bInLockMode)
{
	long totalAllocatedSize = 0;
	
	int i;
	SI_Event * _event = NULL;
	
	for( i = 0; i < iSize; i++)
	{
		//SI_Event * _event = (SI_Event *) __si_malloc(sizeof(SI_Event));
		
		__si_malloc2( sizeof(SI_Event), (uint8_t **) &_event);	
		totalAllocatedSize += sizeof( SI_Event);
		
		memset( _event, 0, sizeof(SI_Event));
		_event->PoolNext = NULL;
		
		__si_addToEventPool( _event, bInLockMode);
		__siCore->EventPoolCount++;
	}
	
	//printf( "memory reserved for EventPool = %ld with size=%d\n", totalAllocatedSize, iSize);
}


SI_Event * __si_allocateEvent()
{
	SI_Event * _event = NULL;
	pthread_mutex_lock( &__siCore->EventLock);
	_event = __siCore->EventHead;
	
	if(!_event) 
	{
		__si_createEventPool( 1000, 0);
		_event = __siCore->EventHead;
	}
	
	if(_event) 
	{
		__siCore->EventHead = _event->PoolNext;
	}
	
	__siCore->EventPoolAvailableCount--;

	_event->isReleased = 0;	
	_event->PoolNext = NULL;
	
	pthread_mutex_unlock( &__siCore->EventLock);
	
	return _event;
}


void __si_addToTaskPool( SI_Task * _event, uint8_t bInLockMode)
{
	if(bInLockMode) 
	{
		pthread_mutex_lock( &__siCore->TaskLock);
	}
	
	if(!__siCore->TaskHead) 
	{
		__siCore->TaskHead = __siCore->TaskCurrent = _event;
	}
	else 
	{
		__siCore->TaskCurrent->PoolNext = _event;
		__siCore->TaskCurrent = _event;
	}
	
	_event->isReleased = 1;
	__siCore->TaskPoolAvailableCount++;
	
	if(bInLockMode) 
	{
		pthread_mutex_unlock( &__siCore->TaskLock);
	}	
}

void __si_createTaskPool( int iSize, uint8_t bInLockMode)
{
	long totalAllocatedSize = 0;
	
	int i;
	SI_Task * _task = NULL;
	
	for( i = 0; i < iSize; i++)
	{
		//SI_Task * _task = (SI_Task *) __si_malloc(sizeof(SI_Task));
		__si_malloc2( sizeof(SI_Task), (uint8_t **) &_task);
		
		totalAllocatedSize += sizeof(SI_Stream);
		
		memset( _task, 0, sizeof(SI_Task));
		_task->PoolNext = NULL;
		
		__si_addToTaskPool( _task, bInLockMode);
		__siCore->TaskPoolCount++;
	}
	
	//printf( "memory reserved for TaskPool = %ld with size=%d\n", totalAllocatedSize, iSize);
}

SI_Task * __si_allocateTask()
{
	SI_Task * _task = NULL;
	pthread_mutex_lock( &__siCore->TaskLock);
	_task = __siCore->TaskHead;
	
	if(!_task) 
	{
		__si_createTaskPool( 1000, 0);
		_task = __siCore->TaskHead;
	}
	
	if(_task) 
	{
		__siCore->TaskHead = _task->PoolNext;
	}
	
	__siCore->TaskPoolAvailableCount--;
	_task->isReleased = 0;
	
	pthread_mutex_unlock( &__siCore->TaskLock);
	_task->PoolNext = NULL;
	
	return _task;
}

void __si_releaseTask( SI_Task * _task)
{
	if( _task->isReleased == 0)
	{	
		__si_addToTaskPool( _task, 1);
	}	
}

void __si_execTask( SI_Task * _task)
{
	_task->taskExec( _task);
}

void __si_print_buffer( char * buff, int len)
{
	int i;
	for( i = 0; i < len; i++) 
	{
		printf("%02X ", buff[i] & 0xFF);
	}
	printf("\n");
}


int __si_build__apn( char * dst, const char * src, int length)
{
	int i = 0, j = 0;

    for (i = 0, j = 0; i < length; i++, j++) 
	{
        if (src[i] == '.') 
		{
            dst[i-j] = j;
            j = -1;
        } 
		else 
		{
            dst[i+1] = src[i];
        }
    }
    dst[i-j] = j;

    return length + 1;
}


int __si_build__parse(char *dst, const char *src, int length)
{
    int i = 0, j = 0;
    uint8_t len = 0;

    while (i+1 <= length) 
	{
        len = src[i++];
        
		if ((j + len + 1) > length) 
		{
            return -EINVAL;
        }
        
		memcpy(&dst[j], &src[i], len);

        i += len;
        j += len;

        if (i+1 < length)
            dst[j++] = '.';
        else
            dst[j] = 0;
    }

    return j;
}


void __si_print_buffer2( char *key, char * buff, int len, int haveSpace)
{
	printf("%s ", key);
	int i;
	for( i = 0; i < len; i++) 
	{
		if( haveSpace == 1)
			printf("%02X ", buff[i] & 0xFF);
		else
			printf("%02X", buff[i] & 0xFF);
	}
	printf("\n");
}


void __si_log_buffer( char * prefix, char * buff, int len)
{
	char sbuff[2000];
	memset( sbuff, 0, sizeof( sbuff));
	
	int i;
	for( i = 0; i < len; i++) 
	{
		sprintf( &sbuff[i*3], "%02X ", buff[i] & 0xFF);
	}
	__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "%s [%s] len=%d <%s|%s|%d>", prefix, sbuff, len, __FILE__, __FUNCTION__, __LINE__);
}

// buff_out - should be double length
void __si_hex_to_buffer( char * buff_in, int len, char * buff_out)
{
	int i;
	for( i = 0; i < len; i++) 
	{
		//sprintf( &buff_out[i*3], "%02X ", buff_in[i] & 0xFF);
		sprintf( &buff_out[i*2], "%02X", buff_in[i] & 0xFF);
	}
}



void __si_print_string( char * buff, int len)
{
	int i;
	for( i = 0; i < len; i++) 
	{
		printf("%c", buff[i]);
	}
	printf("\n");
}

int __si_set_pthread_on_core( int cpu_id)
{
	if( cpu_id < 0 || cpu_id > get_nprocs())
	{
		return EINVAL;
	}
	
	cpu_set_t cpuset;
	CPU_ZERO( &cpuset);
	CPU_SET( cpu_id, &cpuset);
	
	pthread_t current_thread = pthread_self();
	return pthread_setaffinity_np( current_thread, sizeof(cpu_set_t), &cpuset);
}

int __si_create_pthread_oncore( void *(*start_routine) (void *), void *arg, char * funcName, int cpu_id)
{
	if( cpu_id < 0 || cpu_id > get_nprocs())
	{
		printf("thread creation failed\n");
		return EINVAL;
	}

	cpu_set_t cpuset;
	CPU_ZERO( &cpuset);
	CPU_SET( cpu_id, &cpuset);
	
	pthread_t s_pthread_id;

	pthread_attr_t attr;
	pthread_attr_init( &attr);
	pthread_attr_setdetachstate( &attr, PTHREAD_CREATE_DETACHED);	
	
	int rc = pthread_create( &s_pthread_id, &attr, start_routine, arg);
	
	pthread_setaffinity_np( s_pthread_id, sizeof(cpu_set_t), &cpuset);
	pthread_setname_np( s_pthread_id, funcName);
	
	return rc;
}

int __si_create_pthread2( void *(*start_routine) (void *), void *arg, char * funcName)
{
	//printf("created thread for [%s][%s,%d]\n", funcName, __FUNCTION__, __LINE__);
	pthread_t s_pthread_id;

	pthread_attr_t attr;
	pthread_attr_init( &attr);
	pthread_attr_setdetachstate( &attr, PTHREAD_CREATE_DETACHED);	
	
	int rc = pthread_create( &s_pthread_id, &attr, start_routine, arg);
	
	pthread_setname_np( s_pthread_id, funcName);
	
	return rc;
}

void __si_counter_reinit( SI_Counter * siCounter, int total)
{
	if( total == 0)
	{
		siCounter->Request = 0;
		siCounter->Response = 0;
		siCounter->lastRequest = 0;	
		//siCounter->CurrentCount = 0;		
	}
	else if( total == 1)
	{
		siCounter->Request = 0;
		siCounter->Response = 0;
		siCounter->lastRequest = 0;		
		siCounter->Total = 0;
		//siCounter->CurrentCount = 0;
	}
	else if( total == 2)
	{
		siCounter->lastRequest = 0;		
		siCounter->CurrentCount = 0;
	}
}

void __si_counter_init( SI_Counter * siCounter, long int liMaxLimit, char * name)
{
	memset( siCounter, 0, sizeof( SI_Counter));
	
	pthread_mutex_init( &siCounter->Lock, NULL);
	pthread_mutex_init( &siCounter->RequestLock, NULL);
	pthread_mutex_init( &siCounter->ResponseLock, NULL);
	pthread_mutex_init( &siCounter->ErrorResponseLock, NULL);
	pthread_mutex_init( &siCounter->TotalLock, NULL);
	pthread_mutex_init( &siCounter->SendFailedLock, NULL);
	
	siCounter->MaxLimit = liMaxLimit;
	
	if( name) {
		if( strlen( name) < sizeof(siCounter->Name)) {
			memcpy( siCounter->Name, name, strlen( name));
		} else {
			memcpy( siCounter->Name, name, sizeof(siCounter->Name) - 1);
		}
	}
	
	siCounter->Request = 0;
	siCounter->Response = 0;
	siCounter->lastRequest = 0;	
	siCounter->Total = 0;
	siCounter->SendFailed = 0;
	siCounter->lastSendFailed = 0;
}

SI_Counter * __si_counter_create( long int liMaxLimit, char * name)
{
	//SI_Counter * siCounter = (SI_Counter *)__si_malloc( sizeof( SI_Counter) );
	
	SI_Counter * siCounter = NULL;
	__si_malloc2( sizeof( SI_Counter), (uint8_t **) &siCounter);
	
	memset( siCounter, 0, sizeof( SI_Counter));
	
	pthread_mutex_init( &siCounter->Lock, NULL);
	pthread_mutex_init( &siCounter->RequestLock, NULL);
	pthread_mutex_init( &siCounter->ResponseLock, NULL);
	pthread_mutex_init( &siCounter->ErrorResponseLock, NULL);
	pthread_mutex_init( &siCounter->SendFailedLock, NULL);
	
	siCounter->MaxLimit = liMaxLimit;
	
	if( name) {
		if( strlen( name) < sizeof(siCounter->Name)) {
			memcpy( siCounter->Name, name, strlen( name));
		} else {
			memcpy( siCounter->Name, name, sizeof(siCounter->Name) - 1);
		}
	}
	
	siCounter->Request = 0;
	siCounter->Response = 0;
	siCounter->lastRequest = 0;
	siCounter->SendFailed = 0;
	siCounter->lastSendFailed = 0;

	return siCounter;
}

int __si_counter_isMaxLimitReached( SI_Counter * siCounter)
{
	return ( siCounter->CurrentCount >= siCounter->MaxLimit) ? 1 : 0;
}

int __si_counter_increment( SI_Counter * siCounter)
{
	if( __si_counter_isMaxLimitReached( siCounter))
	{
		pthread_mutex_lock( &siCounter->Lock);
		
		siCounter->CurrentCount++;
		
		pthread_mutex_unlock( &siCounter->Lock);
		
		return 1;
	}
	return -1;
}

void __si_counter_decrement( SI_Counter * siCounter)
{
	pthread_mutex_lock( &siCounter->Lock);
	
	if( siCounter->CurrentCount > 0) 
	{	
		siCounter->CurrentCount++;
	}
	
	pthread_mutex_unlock( &siCounter->Lock);	
}

int __si_counter_increment_request( SI_Counter * siCounter)
{
	pthread_mutex_lock( &siCounter->RequestLock);
	siCounter->Request++;
	siCounter->Total++;
	pthread_mutex_unlock( &siCounter->RequestLock);
	return 0;
}

int __si_counter_increment_request2( SI_Counter * siCounter, int cnt)
{
	pthread_mutex_lock( &siCounter->RequestLock);
	siCounter->Request += cnt;
	siCounter->Total += cnt;
	pthread_mutex_unlock( &siCounter->RequestLock);
	return 0;
}

int __si_counter_increment_send_failed( SI_Counter * siCounter)
{
	pthread_mutex_lock( &siCounter->SendFailedLock);
	siCounter->SendFailed++;
	pthread_mutex_unlock( &siCounter->SendFailedLock);
	return 0;
}


int __si_counter_increment_response( SI_Counter * siCounter)
{
	pthread_mutex_lock( &siCounter->ResponseLock);
	siCounter->Response++;
	pthread_mutex_unlock( &siCounter->ResponseLock);
	return 0;
}

int __si_counter_increment_error_response( SI_Counter * siCounter)
{
	pthread_mutex_lock( &siCounter->ErrorResponseLock);
	siCounter->ErrorResponse++;
	pthread_mutex_unlock( &siCounter->ErrorResponseLock);
	return 0;
}

void __si_counter_plog( SI_Counter * siCounter)
{
	siCounter->CurrentCount = (siCounter->Request - siCounter->lastRequest);

	__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%-30s Request[Current=%-10ld Total=%-10lu] Response[Success=%-10lu Error=%-10lu Total=%-10lu] Difference=%-10ld", 
		siCounter->Name, siCounter->CurrentCount, siCounter->Request, siCounter->Response, siCounter->ErrorResponse, 
		siCounter->Response + siCounter->ErrorResponse, 
		( siCounter->Request - (siCounter->Response + siCounter->ErrorResponse)));
	
	siCounter->lastRequest = siCounter->Request;	
}

void __si_counter_plog2( SI_Counter * siCounter)
{
	__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%s Current=%ld Total=%lu", siCounter->Name, (siCounter->Request - siCounter->lastRequest), siCounter->Request);
	siCounter->lastRequest = siCounter->Request;	
}

void __si_counter_plog3( SI_Counter * siCounter)
{
	__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%-40s   %-10ld   %-10lu", siCounter->Name, (siCounter->Request - siCounter->lastRequest), siCounter->Request);
	siCounter->lastRequest = siCounter->Request;	
}

void __si_counter_plog4( SI_Counter * siCounter, int logType)
{
	siCounter->CurrentCount = (siCounter->Request - siCounter->lastRequest);
	siCounter->lastRequest = siCounter->Request;
	__si_log( logType, 0, SI_LOG_DEBUG, "%-40s   %-10ld   %-10lu", siCounter->Name, siCounter->CurrentCount, siCounter->Request);
}

void __si_counter_plog5( SI_Counter * siCounter)
{
	siCounter->CurrentCount = (siCounter->Request - siCounter->lastRequest);
	uint64_t sendFailedCurrentCount = (siCounter->SendFailed - siCounter->lastSendFailed);
	
	__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%-30s Request[Current=%-10ld Total=%-10lu SendFailed=%-10ld Total=%-10lu ] Response[Success=%-10lu Error=%-10lu Total=%-10lu] Difference=%-10ld", 
		siCounter->Name, siCounter->CurrentCount, siCounter->Request, 
		sendFailedCurrentCount, siCounter->SendFailed,
		siCounter->Response, siCounter->ErrorResponse, 
		siCounter->Response + siCounter->ErrorResponse, 
		( siCounter->Request - (siCounter->Response + siCounter->ErrorResponse)));
	
	siCounter->lastRequest = siCounter->Request;	
}

/***********************************************/
// hash table

long int __si_hashString( char * str)
{
	unsigned long hash = 5381;
	int c;

	while (c = *str++)
		hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
	
	return labs(hash);
}

long int __si_hashInt( long int x)
{
	x = ((x >> 16) ^ x) * 0x45d9f3b;
	x = ((x >> 16) ^ x) * 0x45d9f3b;
	x = ((x >> 16) ^ x);
	
	return labs(x);
}

SI_HashTable * __si_createHashTable( int size, int keySize)
{
	//SI_HashTable * hTable = (SI_HashTable *) __si_allocMV( sizeof( SI_HashTable));
	SI_HashTable * hTable = (SI_HashTable *) __si_allocM7( sizeof( SI_HashTable), __FILE__, __LINE__, 0);
	
	if( hTable)
	{	
		//memset( hTable, 0, sizeof( SI_HashTable));
		
		hTable->usedMalloc = 0;
		hTable->TableSize = size;
		hTable->KeySize = keySize;
		hTable->Count = 0;
		pthread_mutex_init( &hTable->Lock, NULL);
		
		//printf( "-1 TableSize=%d\n", hTable->TableSize);
		
		//size_t itemsSize = size * sizeof( SI_HashTableItem);
		size_t itemsSize = size * sizeof( SI_HashTableItem *);
		
		//printf( "required memory for hash table %ld MB\n", ((itemsSize/1024)/1024));
		
		//hTable->Items = ( SI_HashTableItem ** ) __si_allocMV( itemsSize);
		//hTable->Items = ( SI_HashTableItem ** ) __si_allocM7( itemsSize, __FILE__, __LINE__, 0);
		hTable->Items = ( SI_HashTableItem ** ) __si_malloc( itemsSize);
		
		if(!hTable->Items)
		{
			hTable->Items =  ( SI_HashTableItem ** ) __si_malloc_block( itemsSize, __FILE__, __LINE__);
			hTable->usedMalloc = 1;
		}
		
		
		//memset( &hTable->Items, 0, itemsSize);
		//printf( "allocated total size for items = %ld of each %ld \n", itemsSize, sizeof( SI_HashTableItem));
		
		//printf( "-2 TableSize=%d hTable->Items=%p\n", hTable->TableSize, hTable->Items);
		
		int i = 0;
		for( i = 0; i < hTable->TableSize; i++)
		{
			//printf( "hItems Items=%p\n", hTable->Items[i]);
			
			hTable->Items[i] = ( SI_HashTableItem *) __si_allocM7( sizeof( SI_HashTableItem ), __FILE__, __LINE__, 0);
			//hTable->Items[i] = ( SI_HashTableItem *) __si_malloc( sizeof( SI_HashTableItem ), __FILE__, __LINE__, 0);
		}
	
	}
	/*
	else
	{
		printf("table creation failed\n");
	}
	*/
	
	//printf("hTable=%p\n", hTable);
	
	return hTable;
}

void __si_removeAllInHashTable( SI_HashTable * hTable)
{
	if( hTable)
	{
		pthread_mutex_lock( &hTable->Lock);
		
		int i = 0;
		for( i = 0; i < hTable->TableSize; i++)
		{
			if( hTable->Items[i]->Key)
			{
				__si_freeM( hTable->Items[i]->Key);
			}
			
			if( hTable->Items[i]->DataPtr)
			{
				hTable->Items[i]->DataPtr = NULL;
			}
		}
		
		pthread_mutex_unlock( &hTable->Lock);
	}
}

void __si_deleteHashTable( SI_HashTable * hTable)
{
	__si_removeAllInHashTable( hTable);
	
	int i = 0;
	for( i = 0; i < hTable->TableSize; i++)
	{
		__si_freeM( (uint8_t *)hTable->Items[i] );
	}
	
	if( hTable->usedMalloc == 1) 
	{
		free( hTable->Items);
	} 
	else 
	{
		__si_freeM( (uint8_t *)hTable->Items);
	}
	
	__si_freeM( (uint8_t *)hTable);
	
	hTable = NULL;
}

void __si_hashTable_addEntry( SI_HashTableItem * hTableItem, SI_HashTable * hTable, char * key, uint8_t * dataPtr)
{
	hTableItem->Key = (char *) __si_allocM7( hTable->KeySize + 1, __FILE__, __LINE__, 0);
	memcpy( hTableItem->Key, key, hTable->KeySize);
	hTableItem->Key[ hTable->KeySize + 1 ] = '\0';
	
	hTableItem->DataPtr = dataPtr;
	hTable->Count++;
}

int __si_hashTable_free_rows_count( SI_HashTable * hTable)
{
	return ( hTable->TableSize - hTable->Count);
}

long int __si_hashTable_addlong( SI_HashTable * hTable, unsigned long key, uint8_t * dataPtr)
{
	char sKey[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	sprintf( sKey, "%lu", key);
	return __si_hashTable_add( hTable, sKey, dataPtr);
}

void __si_hashTable_findlong( SI_HashTable * hTable, unsigned long key, uint8_t ** dataPtr, uint8_t bDelete)
{
	char sKey[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	sprintf( sKey, "%lu", key);
	__si_hashTable_find( hTable, sKey, dataPtr, bDelete);
}

long int __si_hashTable_add( SI_HashTable * hTable, char * key, uint8_t * dataPtr)
{
	long int bAdded = 0;
	long int hash = 0;
	
	if( hTable)
	{
		pthread_mutex_lock( &hTable->Lock);
		
		if( hTable->Count >= hTable->TableSize)
		{
			pthread_mutex_unlock( &hTable->Lock);
			return -1;
		}
		
		hash = __si_hashString(key) % hTable->TableSize;
		long int origHash = hash;
		
		while( hash < hTable->TableSize)
		{
			//printf( "%s %d hash=%ld TableSize=%d item=%p\n", __FUNCTION__, __LINE__, hash, hTable->TableSize, hTable->Items[hash]);
			
			if(!hTable->Items[hash]->Key)
			{
				__si_hashTable_addEntry( hTable->Items[hash], hTable, key, dataPtr);
				bAdded = 1;
				break;
			}
			
			hash++;
		}
		
		if( bAdded == 0)
		{
			hash = (origHash - 1);
			
			while( hash > 0 )
			{
				if(!hTable->Items[hash]->Key)
				{
					__si_hashTable_addEntry( hTable->Items[hash], hTable, key, dataPtr);
					bAdded = 1;
					break;
				}
			
				hash--;
			}
		}
		
		pthread_mutex_unlock( &hTable->Lock);
	}
	
	return hash;
}

void __si_hashTable_find( SI_HashTable * hTable, char * key, uint8_t ** dataPtr, uint8_t bDelete)
{
	if( hTable)
	{
		pthread_mutex_lock( &hTable->Lock);
		
		long int hashbase = __si_hashString(key);
		
		//printf( "hashbase=%ld TableSize=%d\n", hashbase, hTable->TableSize);
		
		long int hash =  hashbase % hTable->TableSize;
		long int origHash = hash;
		int bFound = 0;
		
		while( hash < hTable->TableSize)
		{
			if( hTable->Items[hash]->Key)
			{
				if( strncmp( hTable->Items[hash]->Key, key, hTable->KeySize) == 0)
				{
					bFound = 1;
					*dataPtr = hTable->Items[hash]->DataPtr;
					
					if( bDelete == 1)
					{
						hTable->Count--;
						hTable->Items[hash]->DataPtr = NULL;
						__si_freeM( hTable->Items[hash]->Key);
						hTable->Items[hash]->Key = NULL;
					}
					
					break;
				}
			}			
			hash++;
		}

		if( bFound == 0)
		{
			hash = (origHash - 1);
			
			while( hash > 0 )
			{
				if(hTable->Items[hash]->Key)
				{
					if( strcmp( hTable->Items[hash]->Key, key) == 0)
					{
						bFound = 1;
						*dataPtr = hTable->Items[hash]->DataPtr;
						
						if( bDelete == 1)
						{
							hTable->Count--;
							hTable->Items[hash]->DataPtr = NULL;
							__si_freeM( hTable->Items[hash]->Key);
							hTable->Items[hash]->Key = NULL;
						}
						
						break;
					}
				}
			
				hash--;
			}
		}		
		
		pthread_mutex_unlock( &hTable->Lock);
	}
}

void __si_hashTable_delete( SI_HashTable * hTable, char * key)
{
	uint8_t * dataPtr = NULL;
	__si_hashTable_find( hTable, key, &dataPtr, 1);
}
// hash table
/***********************************************/
// power table
SI_PowerTable * __si_power_table_create()
{
	SI_PowerTable * pt = (SI_PowerTable *) __si_malloc( sizeof(SI_PowerTable));//__si_allocM7( sizeof(SI_PowerTable), __FILE__, __LINE__, 0);
	memset( pt, 0, sizeof(SI_PowerTable));
	
	pt->Root = NULL;
	pt->KeyElementsCount = 0;
	pt->DataItemCount = 0;
	pt->DeletedCount = 0;
	pthread_mutex_init( &pt->Lock, NULL);
	
	return pt;
}

int __si_power_table_get_item_count( SI_PowerTable * pt)
{
	return pt->DataItemCount;
}

void __si_power_table_destroy( SI_PowerTable * pt)
{
	SI_ExecTime oExecTime;
	__si_StartExecTime( &oExecTime);	
	
	pthread_mutex_lock( &pt->Lock);
	
	SI_PowerTableItem * pti = pt->PoolHead;
	SI_PowerTableItem * ptiNext = NULL;
	
	while( pti)
	{
		ptiNext = pti->PoolNext;
		
		pti->PoolNext = NULL;
		pti->Next = NULL;
		pti->PrevLevel = NULL;
		pti->NextLevel = NULL;
	
		pti->Key = 0;
		pti->DataPtr = NULL;			
		
		__si_freeM( (uint8_t *)pti);
		
		pti = ptiNext;
	}
	
	pt->Root = NULL;
	pt->PoolHead = NULL;
	pt->PoolCurrent = NULL;
	
	pt->KeyElementsCount = 0;
	pt->DataItemCount = 0;
	pt->DeletedCount = 0;
	
	pthread_mutex_unlock( &pt->Lock);	
	
	__si_freeM( ( uint8_t *) pt);
	
	pt = NULL;
	
	__si_EndExecTime( &oExecTime);
	printf( "destroyed-in %ld.%06ld <%s|%s|%d>\n", oExecTime.lapsed.tv_sec, oExecTime.lapsed.tv_usec, __FILE__,__FUNCTION__, __LINE__);
}

void __si_power_table_derive_key( SI_PowerTableItem * pti, char * key, int * len)
{
	char temp[100];
	int icharcount = 0;
	
	while( pti)
	{
		if( pti->Key < 255)
		{	
			temp[icharcount] = pti->Key;
			icharcount++;
		}
		
		pti = pti->PrevLevel;
	}
	
	int i = 0;
	for( i = 0; i < icharcount; i++)
	{
		key[i] = temp[ icharcount - (i+1)];
	}
	
	*len = icharcount;
	key[i+1] = '\0';
}

void * __si_power_table_get_ptr_dataitem( void * pi_item_ptr)
{
	if( pi_item_ptr)
		return (( SI_PowerTableItem *) pi_item_ptr)->DataPtr;
	
	return NULL;
}

void * __si_power_table_get_pending_ptr( SI_PowerTable * pt, void * lastPtr)
{
	if( pt || lastPtr)
	{	
		SI_PowerTableItem * pti = NULL;
		
		if( pt)
			pti = pt->PoolHead;
		
		if( lastPtr)
		{
			pti = ( SI_PowerTableItem *) lastPtr;	
			pti = pti->PoolNext;
		}
		
		while( pti)
		{
			if( pti->DataPtr)
			{
				return pti;
			}
			
			pti = pti->PoolNext;
		}
		
		return NULL;
	}
	
	return NULL;
}

void __si_power_table_release_all( SI_PowerTable * pt)
{
	pthread_mutex_lock( &pt->Lock);
	
	SI_PowerTableItem * pti = pt->PoolHead;
	
	while( pti)
	{
		if( pti->DataPtr)
		{
			__si_freeM( (uint8_t *)pti->DataPtr);
			pti->DataPtr = NULL;
		}
		
		pti = pti->PoolNext;
	}
	pthread_mutex_unlock( &pt->Lock);
	
	__si_power_table_rebuild( pt);
}

void __si_power_table_rebuild( SI_PowerTable * pt)
{
	// creates new table
	// copies all active elements to new table
	// copies root point from new to old, then destroy new table
	
	
	SI_ExecTime oExecTime;
	__si_StartExecTime( &oExecTime);	
	
	pthread_mutex_lock( &pt->Lock);
	
	SI_PowerTable * ptNew = __si_power_table_create();
	
	SI_PowerTableItem * pti = pt->PoolHead;
	
	int icount = 0;
	char key[100];
	int keylen = 0;
	uint8_t * DataPtr = NULL;
	
	while( pti)
	{
		DataPtr = pti->DataPtr;
		
		if( DataPtr)
		{
			__si_power_table_derive_key( pti, key, &keylen);
			__si_power_table_add( ptNew, key, keylen, DataPtr);
		}
		
		icount++;
		pti = pti->PoolNext;
	}
	
	//printf("ptNew total KeyElementsCount=%d DataItemCount=%d DeletedCount=%d\n", ptNew->KeyElementsCount, ptNew->DataItemCount, ptNew->DeletedCount);
	
	SI_PowerTableItem * tempRoot = pt->Root;
	SI_PowerTableItem * tempPoolHead = pt->PoolHead;
	SI_PowerTableItem * tempPoolCurrent = pt->PoolCurrent;
	
	int tempKeyElementsCount = pt->KeyElementsCount;
	int tempDataItemCount = pt->DataItemCount;
	int tempDeletedCount = pt->DeletedCount;
	
	pt->Root = ptNew->Root;
	pt->PoolHead = ptNew->PoolHead;
	pt->PoolCurrent = ptNew->PoolCurrent;
	pt->KeyElementsCount = ptNew->KeyElementsCount;
	pt->DataItemCount = ptNew->DataItemCount;
	pt->DeletedCount = 0;//ptNew->DeletedCount;
	
	ptNew->Root = tempRoot;
	ptNew->PoolHead = tempPoolHead;
	ptNew->PoolCurrent = tempPoolCurrent;
	ptNew->KeyElementsCount = tempKeyElementsCount;
	ptNew->DataItemCount = tempDataItemCount;
	ptNew->DeletedCount = tempDeletedCount;
	
	pthread_mutex_unlock( &pt->Lock);
	__si_EndExecTime( &oExecTime);
	
	printf( "rebuilt-in %ld.%06ld <%s|%s|%d>\n", oExecTime.lapsed.tv_sec, oExecTime.lapsed.tv_usec, __FILE__,__FUNCTION__, __LINE__);
	
	__si_power_table_destroy( ptNew);
}

void __si_power_table_swap( SI_PowerTable * pt, SI_PowerTable * ptNew)
{
	pthread_mutex_lock( &pt->Lock);
	
	SI_PowerTableItem * tempRoot = pt->Root;
	SI_PowerTableItem * tempPoolHead = pt->PoolHead;
	SI_PowerTableItem * tempPoolCurrent = pt->PoolCurrent;
	
	int tempKeyElementsCount = pt->KeyElementsCount;
	int tempDataItemCount = pt->DataItemCount;
	int tempDeletedCount = pt->DeletedCount;
	
	pt->Root = ptNew->Root;
	pt->PoolHead = ptNew->PoolHead;
	pt->PoolCurrent = ptNew->PoolCurrent;
	pt->KeyElementsCount = ptNew->KeyElementsCount;
	pt->DataItemCount = ptNew->DataItemCount;
	pt->DeletedCount = ptNew->DeletedCount;
	
	ptNew->Root = tempRoot;
	ptNew->PoolHead = tempPoolHead;
	ptNew->PoolCurrent = tempPoolCurrent;
	ptNew->KeyElementsCount = tempKeyElementsCount;
	ptNew->DataItemCount = tempDataItemCount;
	ptNew->DeletedCount = tempDeletedCount;	
	
	pthread_mutex_unlock( &pt->Lock);
}

SI_PowerTableItem * __si_power_table_create_element( SI_PowerTable * pt)
{
	SI_PowerTableItem * pti = (SI_PowerTableItem *) __si_allocM7( sizeof(SI_PowerTableItem), __FILE__, __LINE__, 0);
	pti->Key = 0;
	pti->Next = 0x0;
	pti->DataPtr = 0x0;
	pti->PrevLevel = 0x0;
	pti->NextLevel = 0x0;
	pti->PoolNext = 0x0;

	pt->KeyElementsCount++;
	
	if(!pt->PoolHead)
	{
		pt->PoolHead = pt->PoolCurrent = pti;
	} 
	else
	{
		pt->PoolCurrent->PoolNext = pti;		
		pt->PoolCurrent = pti;
	}
	
	return pti;
}	

SI_PowerTableItem * __si_power_table_get_next_level_item( SI_PowerTable * pt, SI_PowerTableItem * pti, uint8_t key, int add)
{
	if(!pti->NextLevel && add == 0)
	{
		return NULL;
	}
	
	if(!pti->NextLevel)
	{
		pti->NextLevel = __si_power_table_create_element( pt);
		pti->NextLevel->Key = key;
		
		pti->NextLevel->PrevLevel = pti;
		
		return pti->NextLevel;
	}
	
	SI_PowerTableItem * pti_next_level = pti->NextLevel;
	SI_PowerTableItem * pti_last_node = NULL;
	
	while( pti_next_level)
	{
		if( pti_next_level->Key == key)
		{
			return pti_next_level;
		}
		
		pti_last_node = pti_next_level;
		pti_next_level = pti_next_level->Next;
	}
	
	
	if(!pti_next_level && add == 0)
		return NULL;
	
	if(!pti_next_level)
	{
		pti_next_level = __si_power_table_create_element( pt);
		pti_next_level->Key = key;
		pti_next_level->PrevLevel = pti;
		
		pti_last_node->Next = pti_next_level;
		
		return pti_next_level;
	}
	
	return NULL;
}

void __si_power_table_add( SI_PowerTable * pt, char * key, int keylen, uint8_t * dataPtr)
{
	if(!dataPtr) return;
	if( keylen <= 0) return;
	
	pthread_mutex_lock( &pt->Lock);
	
	if( !pt->Root)
	{
		pt->Root = __si_power_table_create_element( pt);
		pt->Root->Key = 255;
	}
	
	SI_PowerTableItem * pti = pt->Root;
	
	int i = 0;
	for( i = 0; i < keylen; i++)
	{
		pti = __si_power_table_get_next_level_item( pt, pti, key[i], 1);
	}
	
	pti->DataPtr = dataPtr;
	pt->DataItemCount++;
	
	pthread_mutex_unlock( &pt->Lock);
}

void __si_power_table_add_lk( SI_PowerTable * pt, uint64_t key, uint8_t * dataPtr)
{
	if(!dataPtr) return;
	
	//18446744073709551615  - u64 MAX
	char ckey[20] = { 0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};
	sprintf( ckey, "%lu", key);
	//__si_power_table_add( pt, ckey, strlen(ckey), dataPtr);
	__si_power_table_add( pt, ckey, 20, dataPtr);
	
	//__si_print_buffer( ckey, 20);
}

void __si_power_table_del( SI_PowerTable * pt, char * key, int keylen)
{
	if( keylen <= 0) return;
	
	pthread_mutex_lock( &pt->Lock);
	
	if( !pt->Root)
	{
		pt->Root = __si_power_table_create_element( pt);
		pt->Root->Key = -1;
	}
	
	SI_PowerTableItem * pti = pt->Root;
	
	int i = 0;
	for( i = 0; i < keylen; i++)
	{
		pti = __si_power_table_get_next_level_item( pt, pti, key[i], 0);
		
		if(!pti)
		{
			break;
		}
	}
	
	if( pti)
	{	
		pti->DataPtr 		= NULL;
		pt->DataItemCount--;
		pt->DeletedCount++;
	}
	
	pthread_mutex_unlock( &pt->Lock);	
}

void __si_power_table_del_lk( SI_PowerTable * pt, uint64_t key)
{
	char ckey[20] = { 0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};
	sprintf( ckey, "%lu", key);
	//__si_power_table_del( pt, ckey, strlen(ckey));
	__si_power_table_del( pt, ckey, 20);
}


void __si_power_table_fnd( SI_PowerTable * pt, char * key, int keylen, uint8_t ** dataPtr)
{
	if( keylen <= 0) return;
	
	pthread_mutex_lock( &pt->Lock);
	
	*dataPtr = NULL;
	
	if( !pt->Root)
	{
		pt->Root = __si_power_table_create_element( pt);
		pt->Root->Key = -1;
	}
	
	SI_PowerTableItem * pti = pt->Root;
	
	int i = 0;
	for( i = 0; i < keylen; i++)
	{
		pti = __si_power_table_get_next_level_item( pt, pti, key[i], 0);

		if(!pti)
		{
			break;
		}
	}
	
	if( pti)
	{	
		*dataPtr = pti->DataPtr;
	}
	
	pthread_mutex_unlock( &pt->Lock);	
}

void __si_power_table_fnd_lk( SI_PowerTable * pt, uint64_t key, uint8_t ** dataPtr)
{
	char ckey[20] = { 0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};
	sprintf( ckey, "%lu", key);
	//__si_power_table_fnd( pt, ckey, strlen(ckey), dataPtr);
	__si_power_table_fnd( pt, ckey, 20, dataPtr);
	
	//__si_print_buffer( ckey, 20);
}

// power table
/***********************************************/
void __si_queue_thread_monitor_register( SI_Thread * threadInfo)
{
	if( !__siCore->ThreadHead) 
	{
		__siCore->ThreadHead = __siCore->ThreadCurrent = threadInfo;
	} 
	else
	{
		__siCore->ThreadCurrent->Next = threadInfo;
		__siCore->ThreadCurrent = threadInfo;
	}
}

int __si_core_get_last_processed_queue_count()
{
	/*
		lastTick ., current tick -1 is lastTick  
	*/
	int lastTick = (__siCore->SeverTimerTick - 1);
	int iTotalProcessedCount = 0;
	
	SI_Thread * threadInfo = __siCore->ThreadHead;
	
	while( threadInfo)
	{
		if( threadInfo->LastProcessedCount == 0)
		{
			// hanged thread
		}
		
		iTotalProcessedCount += threadInfo->LastProcessedCount;
		threadInfo = threadInfo->Next;
	}
	
	return iTotalProcessedCount;
}

void __si_queue_thread_monitor_increment( SI_Thread * threadInfo, SI_ExecTime * oExecTime)
{
	__si_EndExecTime( oExecTime);
	
	if( oExecTime->lapsed.tv_sec > 5)
	{
		threadInfo->MaxTimeTakenCounter++;
	}

	threadInfo->TotalProcessedTime += oExecTime->lapsed.tv_sec;
	threadInfo->TotalProcessedCount++;
	
	if( threadInfo->LastTimerTick < __siCore->SeverTimerTick)
	{
		threadInfo->LastProcessedCount = 0;
		
		if( threadInfo->TotalProcessedCount > threadInfo->LastTotalProcessedCount)
		{
			threadInfo->LastProcessedCount = (threadInfo->LastTotalProcessedCount - threadInfo->TotalProcessedCount);
		}
		
		threadInfo->LastTotalProcessedCount = threadInfo->TotalProcessedCount;
		threadInfo->LastTimerTick = __siCore->SeverTimerTick;
	}

	if( threadInfo->TotalProcessedCount > 4294967295)
	{
		threadInfo->TotalProcessedCount = 0;
		threadInfo->TotalProcessedTime = 0;
	}
	else if( threadInfo->TotalProcessedTime > 4294967295)
	{
		threadInfo->TotalProcessedCount = 0;
		threadInfo->TotalProcessedTime = 0;
	}
}


void * __si_queue_thread( void * args)
{
	//SI_Thread * threadInfo = (SI_Thread *) __si_malloc( sizeof( SI_Thread));
	SI_Thread * threadInfo = NULL;
	__si_malloc2( sizeof( SI_Thread), (uint8_t **) &threadInfo);
	
	memset( threadInfo, 0, sizeof( SI_Thread));
	threadInfo->id = pthread_self();
	threadInfo->isActive = 1;
	threadInfo->LastTimerTick = __siCore->SeverTimerTick;
	
	__si_queue_thread_monitor_register( threadInfo);
	
	
	SI_ExecTime execTime;
	SI_Queue * _queue;
	
	while(1)
	{
		sem_wait( &__siCore->queue_sem_lock);
		
		pthread_mutex_lock( &__siCore->QueueLineLock);
		
			_queue = __siCore->QueueLineHead;
			
			if( _queue) 
			{
				__siCore->QueueLineHead = _queue->Next;
				_queue->Next = NULL;
				
				__siCore->QueueLineCount--;
			}
		
		pthread_mutex_unlock( &__siCore->QueueLineLock);
		
		if( _queue)
		{
			if( _queue->handler)
			{
				__si_StartExecTime( &execTime);
				_queue->handler(  _queue->data);
				//__si_queue_thread_monitor_increment( threadInfo, &execTime);
				__siCore->QueueLineTotalProcessedCount++;
			}
			
			//move to top (check in lock)
			//pthread_mutex_lock( &__siCore->QueueLineLock);
			//__siCore->QueueLineCount--;
			//pthread_mutex_unlock( &__siCore->QueueLineLock);
			
			__si_release_queue( _queue);
		}
		
		/*
		// code for graceful shutdown, may be future use
		if( threadInfo->isActive == 0)
		{
			while( threadInfo->isActive == 0)
			{
				usleep( 555555);
			}
		}
		*/
	}
	
	return NULL;
}

void __si_core_create_queue_processing_thread( int icount)
{
	int i = 0;
	
	for( i = 0; i < icount; i++) 
	{
		__siCore->QueueLineThreadCount++; 
		__si_create_pthread2( __si_queue_thread, NULL, "si_queue");
	}	
}

static int __initial_queue_processing_thread_count = 5;

void __si_core_set_queue_processing_thread_count( int icount)
{
	if( icount > 0) {
		__initial_queue_processing_thread_count = icount;
	}	
}

void __si_core_queue( uint8_t * data, queue_handler handler)
{
	SI_Queue * _queue = __si_allocate_queue();
	
	_queue->data = data;
	_queue->handler = handler;
	
	pthread_mutex_lock( &__siCore->QueueLineLock);
	
	if(!__siCore->QueueLineHead)
	{
		__siCore->QueueLineHead = __siCore->QueueLineCurrent = _queue;
	}
	else
	{
		__siCore->QueueLineCurrent->Next = _queue;
		__siCore->QueueLineCurrent = _queue;
	}
	
	__siCore->QueueLineCount++;
	__siCore->QueueLineTotalQueuedCount++;
	
	if( __siCore->QueueLineThreadCount == 0) 
	{
		__si_core_create_queue_processing_thread( __initial_queue_processing_thread_count);
	}
	
	//if( __siCore->QueueLineCount > 500 && __siCore->QueueLineThreadCount < 50)

	struct timeval tval;
	struct timezone tzone;	
	gettimeofday( &tval, &tzone);
	
	/* at least 60seconds in each thread increase */
	if( (tval.tv_sec - __siCore->QueueLineThreadIncreasedTime.tv_sec) > 30)
	{
		int avgBacklog = 0;
		if( __siCore->QueueBacklogTotal > 0)
		{
			avgBacklog = (__siCore->QueueBacklogTotal/30);
			__siCore->LastAvgQueueBacklog = avgBacklog;
		}
		
		__siCore->QueueBacklogTotal = 0;
	
		if( avgBacklog > 500 && __siCore->QueueLineThreadCount < 50)	
		{
			gettimeofday( &__siCore->QueueLineThreadIncreasedTime, &tzone);
			__si_core_create_queue_processing_thread( 1);
		}	
	}
	
	
	pthread_mutex_unlock( &__siCore->QueueLineLock);
	
	sem_post( &__siCore->queue_sem_lock);
}

void __si_core_registerForEvent1( uint16_t eventType, void (*handler)( uint16_t , uint8_t *))
{
	__siCore->EventHandler[ __siCore->EventHandlerCount].eventType = eventType;
	__siCore->EventHandler[ __siCore->EventHandlerCount].Handler = handler;	
	__siCore->EventHandlerCount++;
}

void __si_core_EventHandler1( uint16_t eventType, uint8_t  * eventDataPtr)
{
	int i = 0;
	int eExecuted = 0;
	
	for( i = 0; i < __siCore->EventHandlerCount; i++)
	{
		if( __siCore->EventHandler[ __siCore->EventHandlerCount].eventType == eventType)
		{
			__siCore->EventHandler[ __siCore->EventHandlerCount].Handler( eventType, eventDataPtr);
			eExecuted = 1;
			break;
		}
	}
	
	if( eExecuted == 0)
	{
		__si_log( SI_STK_LOG, LOG_CAT_CORE, SI_LOG_DEBUG, "No Subscriptions Found for Event %d <%s|%s|%d>", eventType, __FILE__, __FUNCTION__, __LINE__);
	}
}

void __si_addEvent1( uint8_t * eventSetPtr, uint16_t eventType, uint8_t  * eventDataPtr)
{
	SI_EventSet * _eventSet = NULL;
	
	if( eventSetPtr) 
	{
		_eventSet = (SI_EventSet *)eventSetPtr;
	} 
	else 
	{
		_eventSet = __siCore->eventSet;	
	}
	
	
	SI_Event * _event = __si_allocateEvent();
	
	_event->eventType = eventType;
	_event->eventDataPtr = eventDataPtr;
	
	pthread_mutex_lock( &_eventSet->Lock);	
	
	if(!_eventSet->EventHead) 
	{
		_eventSet->EventHead = _eventSet->EventCurrent = _event;
	}
	else
	{
		_eventSet->EventCurrent->PoolNext = _event;
		_eventSet->EventCurrent = _event;
	}
	
	pthread_mutex_unlock( &_eventSet->Lock);
	
	sem_post( &_eventSet->sem_lock);
}


void * __si_eventNotifyEvent( void * args)
{
	SI_EventSet * _eventSet = (SI_EventSet *)args;
	SI_Event * _event = NULL;
	
	while(1)
	{
		sem_wait( &_eventSet->sem_lock);

		pthread_mutex_lock( &_eventSet->Lock);	
			
			_event = _eventSet->EventHead;
			
			if(_event)
			{
				_eventSet->EventHead = _event->PoolNext;
			}
		
		pthread_mutex_unlock( &_eventSet->Lock);
	
		if(_event)
		{	
			_eventSet->CallBack( _event->eventType, _event->eventDataPtr);
			__si_releaseEvent( _event);
		}
		
	}
	return NULL;
}


int __si_eventSetCreate1( uint8_t ** eventSetPtr, int iNoOfProcess, __si_event_callaback e_call_back)
{
	if(iNoOfProcess < 1)
		return -2;
	
	if(!e_call_back)
		return -3;
	
	SI_EventSet * si_eventSet = NULL;
	
	//si_eventSet = (SI_EventSet *) __si_malloc( sizeof( SI_EventSet));
	__si_malloc2( sizeof( SI_EventSet), (uint8_t **) &si_eventSet);
	memset( si_eventSet, 0, sizeof(SI_EventSet));
	
	si_eventSet->EventHead 					= NULL;
	si_eventSet->EventCurrent 				= NULL;
	si_eventSet->CallBack 					= e_call_back;
	sem_init( &si_eventSet->sem_lock, 0, 0);
	
	pthread_mutex_init( &si_eventSet->Lock, NULL);
	
	int i = 0;
	//pthread_t thread1;
	 
	for( i = 0; i < iNoOfProcess; i++)
	{	
		__si_create_pthread2( __si_eventNotifyEvent, (void*) si_eventSet, "si_eventNotify");
	}
	
	*eventSetPtr = (uint8_t *) si_eventSet;
	return 0;
}


int __si_createDefaultEventSet1( int iNoOfProcess, __si_event_callaback e_call_back)
{
	return __si_eventSetCreate1( (uint8_t **) &__siCore->eventSet, iNoOfProcess, e_call_back);
}


int debug__allocM__enable = 0;
int debug__allocM__size = 21;

uint8_t * __si_allocMemory( SI_MemoryPool * memoryPool, uint32_t alloc_size)
{
	pthread_mutex_lock( &memoryPool->Lock);
	
	if( !memoryPool->Head)
	{
		__si_allocate_Memory( memoryPool, memoryPool->IncrementPoolSize, 0);
	}
	
	SI_MemoryHead *_head = memoryPool->Head;
	
	if(_head)
	{	
		memoryPool->Head = _head->PoolNext;
		_head->PoolNext = NULL;
		_head->alloc_size = alloc_size;
		
		//__siCore->MemoryPool[40].size
		
		// if( memoryPool->size == 50 && memoryPool->Used > 40000)
		// {
			// raise(0);
			// int iz = 100/0;
		// }
		
		memoryPool->Available--;
		memoryPool->Used++;
		_head->isReleased = 0;
	}
	
	pthread_mutex_unlock( &memoryPool->Lock);
	
	//__si_log( SI_STK_LOG, LOG_CAT_BUFFER, SI_LOG_DEBUG, "_head=%p parentPtr=%p memory=%p sizeof(SI_MemoryHead)=%ld size=%d  <%s|%s|%d>", _head, _head->parentPtr, _head->memory, sizeof(SI_MemoryHead), memoryPool->size, __FILE__, __FUNCTION__, __LINE__);
	
	if( !_head)
	{
		return NULL;
	}
	
	
	if( memoryPool->size == debug__allocM__size && debug__allocM__enable == 1)
	{
		printf( "allocated size %d alloc_size=%u  mptr=%p  tp=%d ap=%d  %s|%s|%d\n", 
		memoryPool->size, _head->alloc_size, _head->memory, 
		memoryPool->TotalPoolSize,
		memoryPool->Available,
		__FILE__, __FUNCTION__, __LINE__);
	}
	
	
	return _head->memory;
}


void __si_allocMemory2( SI_MemoryPool * memoryPool, uint8_t ** dataPtr, uint32_t alloc_size)
{
	pthread_mutex_lock( &memoryPool->Lock);
	
	if( !memoryPool->Head)
	{
		__si_allocate_Memory( memoryPool, memoryPool->IncrementPoolSize, 0);
	}	
	
	SI_MemoryHead *_head = memoryPool->Head;
	
	if(_head)
	{	
		memoryPool->Head = _head->PoolNext;
		_head->PoolNext = NULL;
		_head->alloc_size = alloc_size;
		
		memoryPool->Available--;
		memoryPool->Used++;
		_head->isReleased = 0;
	}
	
	pthread_mutex_unlock( &memoryPool->Lock);
	
	//__si_log( SI_STK_LOG, LOG_CAT_BUFFER, SI_LOG_DEBUG, "_head=%p parentPtr=%p memory=%p sizeof(SI_MemoryHead)=%ld size=%d  <%s|%s|%d>", _head, _head->parentPtr, _head->memory, sizeof(SI_MemoryHead), memoryPool->size, __FILE__, __FUNCTION__, __LINE__);
	
	if( !_head)
	{
		*dataPtr = NULL;
		return;
	}

	
	if( memoryPool->size == debug__allocM__size && debug__allocM__enable == 1)
	{
		printf( "allocated size %d alloc_size=%u mptr=%p  tp=%d ap=%d  %s|%s|%d\n", 
		memoryPool->size, _head->alloc_size, _head->memory,  
		memoryPool->TotalPoolSize,
		memoryPool->Available,
		__FILE__, __FUNCTION__, __LINE__);
	}
	
	
	*dataPtr = _head->memory;
}

/*
static long int __si_freeM_debug__head_failed = 0;
static long int __si_freeM_debug__parent_failed = 0;
static long int __si_freeM_debug__memPool_failed = 0;
static long int __si_freeM_debug__released_count = 0;
static long int __si_freeM_debug__tot_release_called_count = 0;
static long int __si_freeM_debug__free_count = 0;

void print_freeM_failed()
{
	printf("head_failed=%ld parent_failed=%ld memPool_failed=%ld released=%ld rel-called=%ld free-count=%ld\n", 
		__si_freeM_debug__head_failed, __si_freeM_debug__parent_failed, 
		__si_freeM_debug__memPool_failed, 
		__si_freeM_debug__released_count,__si_freeM_debug__tot_release_called_count,
		__si_freeM_debug__free_count);
}
*/

void __si_freeM( uint8_t * ptr);

void __si_freeMV( void * ptr)
{
	__si_freeM( (uint8_t *) ptr);
}

//void __si_freeM( void * ptr)
void __si_freeM( uint8_t * ptr)
{
	//pthread_mutex_lock( &__siCore->MemoryFreeLock);
	
	if( ptr > 0)
	{	
		SI_MemoryHead * _head = ( (void *)ptr - sizeof(SI_MemoryHead));
		
		if(_head)
		{
			if( _head->parentPtr)
			{
				SI_MemoryPool * memoryPool = (SI_MemoryPool *)( _head->parentPtr);
				
				if( memoryPool)
				{
					
					
					if( memoryPool->size == debug__allocM__size && debug__allocM__enable == 1)
					{
						printf( "FreePtr=%p size=%d alloc_size=%u  %s|%s|%d\n", ptr, memoryPool->size, _head->alloc_size, __FILE__, __FUNCTION__, __LINE__);
					}
					
					
					__si_addToMemoryPool( memoryPool, _head, 1);
				}
			}
		}
	}
	
	//pthread_mutex_unlock( &__siCore->MemoryFreeLock);
}


uint8_t * __si_allocR(  void * ptr, size_t size)
{
	SI_MemoryHead * _head = (ptr - sizeof(SI_MemoryHead));
	//__si_log( SI_STK_LOG, LOG_CAT_CORE, SI_LOG_DEBUG, "_head=%p parentPtr=%p  <%s|%s|%d>", _head, _head->parentPtr, __FILE__, __FUNCTION__, __LINE__);
	
	if(_head)
	{
		if( _head->parentPtr)
		{
			SI_MemoryPool * memoryPool = (SI_MemoryPool *)( _head->parentPtr);
			if( memoryPool)
			{
				if( memoryPool->size > size)
					return ptr;
				
				uint8_t * data = __si_allocM7( size, __FILE__, __LINE__, 0);
				
				if( data)
				{	
					memcpy( data, ptr, memoryPool->size);
				}
				
				__si_addToMemoryPool( memoryPool, _head, 1);
				
				return data;
			}
		}
	}
	return NULL;
}

void __si_log_buffer_memory_stats()
{
	if( __siCore->enableStackPerLog == 0) {
		return;
	}
	
	int i = 0;
	for( i = 0; i < 41; i++)
	{
		__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "size=%10d  Available=%6d  Total=%6d Used=%6ld Returned=%6ld MRC=%6ld Pending=%6d  |%d", 
				__siCore->MemoryPool[i].size, __siCore->MemoryPool[i].Available, __siCore->MemoryPool[i].TotalPoolSize, 
				__siCore->MemoryPool[i].Used, __siCore->MemoryPool[i].Returned, __siCore->MemoryPool[i].MemoryReservedCount,
				(__siCore->MemoryPool[i].TotalPoolSize - __siCore->MemoryPool[i].Available), __LINE__
			);
	}
	
	long int lastQLPC = 0;
	lastQLPC = __siCore->QueueLineTotalProcessedCount - __siCore->QueueLineLastProcessedCount;

	long int lastTQC = 0;
	lastTQC = __siCore->QueueLineTotalQueuedCount - __siCore->QueueLineLastQueuedCount;
	
	if( lastTQC > 0) {
		__siCore->QueueBacklog = lastTQC - lastQLPC;
	} else {
		__siCore->QueueBacklog = __siCore->QueueLineTotalQueuedCount - __siCore->QueueLineTotalProcessedCount;
	}
	
	__siCore->QueueBacklogTotal += __siCore->QueueBacklog;
	
	__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "Core: StreamPoolCount=%6d  StreamPoolAvailableCount=%6d", __siCore->StreamPoolCount, __siCore->StreamPoolAvailableCount);
	__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "Core: EventPoolCount=%6d  EventPoolAvailableCount=%6d", __siCore->EventPoolCount, __siCore->EventPoolAvailableCount);
	__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "Core: QueuePoolCount=%6d  AvailableQueuePoolCount=%6d", __siCore->TotalQueuePoolCount, __siCore->AvailableQueuePoolCount);
	__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "Core: QueueLineCount=%6d  QueueLineThreadCount=%6d", __siCore->QueueLineCount, __siCore->QueueLineThreadCount);
	__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "Core: LastProcessedCount=%6ld QueuedCount=%6ld QueueBacklog=%6d LastAvgQBacklog=%d", 
			lastQLPC, lastTQC, __siCore->QueueBacklog, __siCore->LastAvgQueueBacklog);
		
	__siCore->QueueLineLastProcessedCount = __siCore->QueueLineTotalProcessedCount;
	__siCore->QueueLineLastQueuedCount = __siCore->QueueLineTotalQueuedCount;

	__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "Core: ServiceRequestTotalPoolCount=%6d  ServiceRequestAvailablePoolCount=%6d", __siCore->ServiceRequestTotalPoolCount, __siCore->ServiceRequestAvailablePoolCount);
	__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "Core: ActivityTotalPoolCount=%6d  ActivityAvailablePoolCount=%6d", __siCore->ActivityTotalPoolCount, __siCore->ActivityAvailablePoolCount);

	__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "-----------------------------------------------------------------------------------------------------------------------------------------------------------------------");
}





uint8_t * __si_allocMV( size_t size)
{
	return __si_allocM( size);
}


int imx = 0;

//void __si_allocMemory2( SI_MemoryPool * memoryPool, uint8_t ** dataPtr)
void __si_allocMX( size_t size, uint8_t ** dataPrt)
{
	//if( size > 50 && size < 100)
	// if( size == 14 )
	// {
		// printf( "size=%lu   %s|%s|%d\n", size,  __FILE__, __FUNCTION__, __LINE__);
		
		// imx++;
		
		// //if( size == x)
		
		// if( imx == 1)
		// {
			// int j = 100/0;
		// }
	// }
	
	
	
	if( size < __siCore->MemoryPool[40].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[40], dataPrt, size);
	}	
	else if( size < __siCore->MemoryPool[0].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[0], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[1].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[1], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[2].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[2], dataPrt, size);
	}		
	else if( size < __siCore->MemoryPool[3].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[3], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[4].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[4], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[5].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[5], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[6].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[6], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[7].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[7], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[8].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[8], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[9].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[9], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[10].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[10], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[11].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[11], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[12].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[12], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[13].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[13], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[14].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[14], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[15].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[15], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[16].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[16], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[17].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[17], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[18].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[18], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[19].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[19], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[20].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[20], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[21].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[21], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[22].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[22], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[23].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[23], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[24].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[24], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[25].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[25], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[26].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[26], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[27].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[27], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[28].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[28], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[29].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[29], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[30].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[30], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[31].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[31], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[32].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[32], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[33].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[33], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[34].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[34], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[35].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[35], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[36].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[36], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[37].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[37], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[38].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[38], dataPrt, size);
	}
	else if( size < __siCore->MemoryPool[39].size) 
	{
		__si_allocMemory2( &__siCore->MemoryPool[39], dataPrt, size);
	}	
}

void __si_allocMV2( size_t size, uint8_t ** dataPtr )
{
	*dataPtr = __si_allocM( size);
}

void * __si_allocMV1( size_t size)
{
	return __si_allocM( size);
}

uint8_t * __si_allocM7( size_t size, const char * file, int line, uint16_t id)
{
	//__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "buffer allocated with size=%ld  <%s|%d|%d>", size, file, line, __LINE__);
	return __si_allocM( size);
}



uint8_t * __si_allocM( size_t size)
{
	//if( size > 50 && size < 100)
	// if( size == 14 )
	// {
		// printf( "size=%lu imx=%d   %s|%s|%d\n", size,  imx, __FILE__, __FUNCTION__, __LINE__);
		
		// imx++;
		
		// //if( size == x)
		
		// if( imx == 26)
		// {
			// int j = 100/0;
		// }
	// }
	// printf("imx=%u\n", imx);

	
	if( size < __siCore->MemoryPool[40].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[40], size);
	}
	else if( size < __siCore->MemoryPool[0].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[0], size);
	}
	else if( size < __siCore->MemoryPool[1].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[1], size);
	}
	else if( size < __siCore->MemoryPool[2].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[2], size);
	}		
	else if( size < __siCore->MemoryPool[3].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[3], size);
	}
	else if( size < __siCore->MemoryPool[4].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[4], size);
	}
	else if( size < __siCore->MemoryPool[5].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[5], size);
	}
	else if( size < __siCore->MemoryPool[6].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[6], size);
	}
	else if( size < __siCore->MemoryPool[7].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[7], size);
	}
	else if( size < __siCore->MemoryPool[8].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[8], size);
	}
	else if( size < __siCore->MemoryPool[9].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[9], size);
	}
	else if( size < __siCore->MemoryPool[10].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[10], size);
	}
	else if( size < __siCore->MemoryPool[11].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[11], size);
	}
	else if( size < __siCore->MemoryPool[12].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[12], size);
	}
	else if( size < __siCore->MemoryPool[13].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[13], size);
	}
	else if( size < __siCore->MemoryPool[14].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[14], size);
	}
	else if( size < __siCore->MemoryPool[15].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[15], size);
	}
	else if( size < __siCore->MemoryPool[16].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[16], size);
	}
	else if( size < __siCore->MemoryPool[17].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[17], size);
	}
	else if( size < __siCore->MemoryPool[18].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[18], size);
	}
	else if( size < __siCore->MemoryPool[19].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[19], size);
	}
	else if( size < __siCore->MemoryPool[20].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[20], size);
	}
	else if( size < __siCore->MemoryPool[21].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[21], size);
	}
	else if( size < __siCore->MemoryPool[22].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[22], size);
	}
	else if( size < __siCore->MemoryPool[23].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[23], size);
	}
	else if( size < __siCore->MemoryPool[24].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[24], size);
	}
	else if( size < __siCore->MemoryPool[25].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[25], size);
	}
	else if( size < __siCore->MemoryPool[26].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[26], size);
	}
	else if( size < __siCore->MemoryPool[27].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[27], size);
	}
	else if( size < __siCore->MemoryPool[28].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[28], size);
	}
	else if( size < __siCore->MemoryPool[29].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[29], size);
	}
	else if( size < __siCore->MemoryPool[30].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[30], size);
	}
	else if( size < __siCore->MemoryPool[31].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[31], size);
	}
	else if( size < __siCore->MemoryPool[32].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[32], size);
	}
	else if( size < __siCore->MemoryPool[33].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[33], size);
	}
	else if( size < __siCore->MemoryPool[34].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[34], size);
	}
	else if( size < __siCore->MemoryPool[35].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[35], size);
	}
	else if( size < __siCore->MemoryPool[36].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[36], size);
	}
	else if( size < __siCore->MemoryPool[37].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[37], size);
	}
	else if( size < __siCore->MemoryPool[38].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[38], size);
	}
	else if( size < __siCore->MemoryPool[39].size) 
	{
		return __si_allocMemory( &__siCore->MemoryPool[39], size);
	}

	
	return NULL;
}



void __si_addToMemoryPool( SI_MemoryPool * memoryPool, SI_MemoryHead * itemPtr, int inLockMode)
{
	if( inLockMode == 1) 
	{
		pthread_mutex_lock( &memoryPool->Lock);
	}
	
	if( itemPtr->isReleased == 0)
	{	
		memoryPool->Available++;
		itemPtr->isReleased = 1;
		
		if(!memoryPool->Head) 
		{
			memoryPool->Head = memoryPool->Current = itemPtr;
		} 
		else 
		{
			memoryPool->Current->PoolNext = itemPtr;
			memoryPool->Current = itemPtr;
		}
	}
	
	if( inLockMode == 1) 
	{
		memoryPool->Returned++;
		pthread_mutex_unlock( &memoryPool->Lock);
	}
}


int logMemoryReservedCount = 0;


void __si_allocate_Memory( SI_MemoryPool * memoryPool, int count, int inLockMode)
{
	if( count == 0) return;
	
	uint32_t MemoryReservedCount = memoryPool->MemoryReservedCount;
	
	if( inLockMode == 1) 
	{
		pthread_mutex_lock( &memoryPool->Lock);
	}
	
	if( memoryPool->Available > 0 && memoryPool->MemoryReservedCount > MemoryReservedCount)
	{
		pthread_mutex_unlock( &memoryPool->Lock);
		return;
	}
	
	uint32_t size = memoryPool->size;	// for display in core file
	
	if( logMemoryReservedCount == 1)
	{
		printf("size=%d element-count=%d TotalPoolSize=%d  %s|%s|%d\n", size, count, memoryPool->TotalPoolSize, __FILE__, __FUNCTION__, __LINE__);
		
		// if( memoryPool->TotalPoolSize > 800000 && size == 50)
		// {
			// int x = 100/0;
		// }
		
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "MEMORY-POOL size=%d element-count=%d TotalPoolSize=%d  %s|%s|%d", 
			size, count, memoryPool->TotalPoolSize, __FILE__, __FUNCTION__, __LINE__);
	}
	
	//memoryPool->IncrementedTimes++;

	// if( memoryPool->Available == 0 && size == 21 && memoryPool->TotalPoolSize > 11001)
	// {
		// int z = 100/0;
	// }

	
	//uint8_t * _fblock = calloc( count, ( sizeof(SI_MemoryHead) + size));
	//uint8_t * _fblock = (uint8_t *)malloc( count * ( sizeof(SI_MemoryHead) + size));
	uint8_t * _fblock = (uint8_t *)__si_malloc_block( count * ( sizeof(SI_MemoryHead) + size), __FILE__, __LINE__);

	
	if(!_fblock)
	{
		printf("memory allocation failed %s|%s|%d\n", __FILE__, __FUNCTION__, __LINE__);
		return;
	}
	
	int z = 0;
	uint8_t * _block = NULL;
	
	for( z = 0; z < count; z++)
	{
		//uint8_t * _block = __si_malloc( sizeof(SI_MemoryHead) + memoryPool->size);
		//__si_malloc2( ( sizeof(SI_MemoryHead) + memoryPool->size), (uint8_t **) &_block);
		_block = _fblock;
		
		SI_MemoryHead * itemPtr = (SI_MemoryHead *) _block;
		itemPtr->memory = ( _block + sizeof(SI_MemoryHead));
		itemPtr->parentPtr = (uint8_t *) memoryPool;
		itemPtr->index = memoryPool->TotalPoolSize;
		itemPtr->block_size = size;
		itemPtr->isReleased = 0;
		itemPtr->PoolNext = NULL;
		
		__si_addToMemoryPool( memoryPool, itemPtr, 0);
		memoryPool->TotalPoolSize++;
		
		_fblock += ( sizeof(SI_MemoryHead) + size);
	}
	
	memoryPool->MemoryReservedCount++;

	
	
	if( inLockMode == 1) 
	{
		pthread_mutex_unlock( &memoryPool->Lock);
	}
}

void __si_initalize_MemoryPools()
{
	__siCore->MemoryPool[40].size = 21;
	__siCore->MemoryPool[40].InitialPoolSize = 10000;
	__siCore->MemoryPool[40].IncrementPoolSize = 1000;
	pthread_mutex_init( &__siCore->MemoryPool[40].Lock, NULL);	
	
	__siCore->MemoryPool[0].size = 50;
	//__siCore->MemoryPool[0].InitialPoolSize = 5000;
	//__siCore->MemoryPool[0].InitialPoolSize = 1200000;
	__siCore->MemoryPool[0].InitialPoolSize = 800000;
	__siCore->MemoryPool[0].IncrementPoolSize = 300;
	pthread_mutex_init( &__siCore->MemoryPool[0].Lock, NULL);
	
	__siCore->MemoryPool[1].size = 100;
	__siCore->MemoryPool[1].InitialPoolSize = 10000;
	__siCore->MemoryPool[1].IncrementPoolSize = 300;
	pthread_mutex_init( &__siCore->MemoryPool[1].Lock, NULL);
	
	__siCore->MemoryPool[2].size = 200;
	__siCore->MemoryPool[2].InitialPoolSize = 5000;
	__siCore->MemoryPool[2].IncrementPoolSize = 500;
	pthread_mutex_init( &__siCore->MemoryPool[2].Lock, NULL);

	__siCore->MemoryPool[3].size = 300;
	__siCore->MemoryPool[3].InitialPoolSize = 5000;
	__siCore->MemoryPool[3].IncrementPoolSize = 300;
	pthread_mutex_init( &__siCore->MemoryPool[3].Lock, NULL);
	
	__siCore->MemoryPool[4].size = 400;
	__siCore->MemoryPool[4].InitialPoolSize = 1000;
	__siCore->MemoryPool[4].IncrementPoolSize = 300;
	pthread_mutex_init( &__siCore->MemoryPool[4].Lock, NULL);
	
	__siCore->MemoryPool[5].size = 500;
	__siCore->MemoryPool[5].InitialPoolSize = 1000;
	__siCore->MemoryPool[5].IncrementPoolSize = 300;
	pthread_mutex_init( &__siCore->MemoryPool[5].Lock, NULL);
	
	__siCore->MemoryPool[6].size = 1000;
	__siCore->MemoryPool[6].InitialPoolSize = 2000;
	__siCore->MemoryPool[6].IncrementPoolSize = 300;
	pthread_mutex_init( &__siCore->MemoryPool[6].Lock, NULL);
	
	__siCore->MemoryPool[7].size = 2100;
	__siCore->MemoryPool[7].InitialPoolSize = 500;
	__siCore->MemoryPool[7].IncrementPoolSize = 100;
	pthread_mutex_init( &__siCore->MemoryPool[7].Lock, NULL);
	
	__siCore->MemoryPool[8].size = 3150;
	__siCore->MemoryPool[8].InitialPoolSize = 500;
	__siCore->MemoryPool[8].IncrementPoolSize = 100;
	pthread_mutex_init( &__siCore->MemoryPool[8].Lock, NULL);
	
	__siCore->MemoryPool[9].size = 4200;
	__siCore->MemoryPool[9].InitialPoolSize = 5000;
	__siCore->MemoryPool[9].IncrementPoolSize = 100;
	pthread_mutex_init( &__siCore->MemoryPool[9].Lock, NULL);
	
	__siCore->MemoryPool[10].size = 5300;
	__siCore->MemoryPool[10].InitialPoolSize = 5000;
	__siCore->MemoryPool[10].IncrementPoolSize = 100;
	pthread_mutex_init( &__siCore->MemoryPool[10].Lock, NULL);
	
	__siCore->MemoryPool[11].size = 6400;
	__siCore->MemoryPool[11].InitialPoolSize = 500;
	__siCore->MemoryPool[11].IncrementPoolSize = 10;
	pthread_mutex_init( &__siCore->MemoryPool[11].Lock, NULL);
	
	__siCore->MemoryPool[12].size = 7400;
	__siCore->MemoryPool[12].InitialPoolSize = 500;
	__siCore->MemoryPool[12].IncrementPoolSize = 10;
	pthread_mutex_init( &__siCore->MemoryPool[12].Lock, NULL);
	
	__siCore->MemoryPool[13].size = 8000;
	__siCore->MemoryPool[13].InitialPoolSize = 500;
	__siCore->MemoryPool[13].IncrementPoolSize = 10;
	pthread_mutex_init( &__siCore->MemoryPool[13].Lock, NULL);
	
	__siCore->MemoryPool[14].size = 9000;
	__siCore->MemoryPool[14].InitialPoolSize = 500;
	__siCore->MemoryPool[14].IncrementPoolSize = 10;
	pthread_mutex_init( &__siCore->MemoryPool[14].Lock, NULL);
	
	__siCore->MemoryPool[15].size = 10000;
	__siCore->MemoryPool[15].InitialPoolSize = 500;
	__siCore->MemoryPool[15].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[15].Lock, NULL);
	
	__siCore->MemoryPool[16].size = 20000;
	__siCore->MemoryPool[16].InitialPoolSize = 1000;
	__siCore->MemoryPool[16].IncrementPoolSize = 500;
	pthread_mutex_init( &__siCore->MemoryPool[16].Lock, NULL);
	
	__siCore->MemoryPool[17].size = 30000;
	__siCore->MemoryPool[17].InitialPoolSize = 10;
	__siCore->MemoryPool[17].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[17].Lock, NULL);
	
	__siCore->MemoryPool[18].size = 40000;
	__siCore->MemoryPool[18].InitialPoolSize = 10;
	__siCore->MemoryPool[18].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[18].Lock, NULL);
	
	__siCore->MemoryPool[19].size = 50000;
	__siCore->MemoryPool[19].InitialPoolSize = 10;
	__siCore->MemoryPool[19].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[19].Lock, NULL);
	
	__siCore->MemoryPool[20].size = 60000;
	__siCore->MemoryPool[20].InitialPoolSize = 10;
	__siCore->MemoryPool[20].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[20].Lock, NULL);	
	
	__siCore->MemoryPool[21].size = 70000;
	__siCore->MemoryPool[21].InitialPoolSize = 10;
	__siCore->MemoryPool[21].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[21].Lock, NULL);	
	
	__siCore->MemoryPool[22].size = 80000;
	__siCore->MemoryPool[22].InitialPoolSize = 10;
	__siCore->MemoryPool[22].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[22].Lock, NULL);	

	__siCore->MemoryPool[23].size = 90000;
	__siCore->MemoryPool[23].InitialPoolSize = 10;
	__siCore->MemoryPool[23].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[23].Lock, NULL);	

	__siCore->MemoryPool[24].size = 95000;
	__siCore->MemoryPool[24].InitialPoolSize = 10;
	__siCore->MemoryPool[24].IncrementPoolSize = 1;
	pthread_mutex_init( &__siCore->MemoryPool[24].Lock, NULL);

	__siCore->MemoryPool[25].size = 102400;										// 100 KB
	__siCore->MemoryPool[25].InitialPoolSize = 10;
	__siCore->MemoryPool[25].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[25].Lock, NULL);

	__siCore->MemoryPool[26].size = ( 2 * 102400);								// 200 KB
	__siCore->MemoryPool[26].InitialPoolSize = 10;
	__siCore->MemoryPool[26].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[26].Lock, NULL);

	__siCore->MemoryPool[27].size = ( 3 * 102400);								// 300 KB
	__siCore->MemoryPool[27].InitialPoolSize = 10;
	__siCore->MemoryPool[27].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[27].Lock, NULL);

	__siCore->MemoryPool[28].size = ( 4 * 102400);								// 400 KB
	__siCore->MemoryPool[28].InitialPoolSize = 10;
	__siCore->MemoryPool[28].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[28].Lock, NULL);

	__siCore->MemoryPool[29].size = ( 5 * 102400);								// 500 KB
	__siCore->MemoryPool[29].InitialPoolSize = 10;
	__siCore->MemoryPool[29].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[29].Lock, NULL);

	__siCore->MemoryPool[30].size = ( 6 * 102400);								// 600 KB
	__siCore->MemoryPool[30].InitialPoolSize = 10;
	__siCore->MemoryPool[30].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[30].Lock, NULL);

	__siCore->MemoryPool[31].size = ( 1 * (1024*1024));							// 1 MB
	__siCore->MemoryPool[31].InitialPoolSize = 10;
	__siCore->MemoryPool[31].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[31].Lock, NULL);
	
	__siCore->MemoryPool[32].size = ( 2 * (1024*1024));							// 2 MB
	__siCore->MemoryPool[32].InitialPoolSize = 10;
	__siCore->MemoryPool[32].IncrementPoolSize = 5;
	pthread_mutex_init( &__siCore->MemoryPool[32].Lock, NULL);

	__siCore->MemoryPool[33].size = ( 3 * (1024*1024));							// 3 MB
	__siCore->MemoryPool[33].InitialPoolSize = 1;
	__siCore->MemoryPool[33].IncrementPoolSize = 1;
	pthread_mutex_init( &__siCore->MemoryPool[33].Lock, NULL);

	__siCore->MemoryPool[34].size = ( 4 * (1024*1024));							// 4 MB
	__siCore->MemoryPool[34].InitialPoolSize = 1;
	__siCore->MemoryPool[34].IncrementPoolSize = 1;
	pthread_mutex_init( &__siCore->MemoryPool[34].Lock, NULL);

	__siCore->MemoryPool[35].size = ( 5 * (1024*1024));							// 5 MB
	__siCore->MemoryPool[35].InitialPoolSize = 1;
	__siCore->MemoryPool[35].IncrementPoolSize = 1;
	pthread_mutex_init( &__siCore->MemoryPool[35].Lock, NULL);

	__siCore->MemoryPool[36].size = ( 6 * (1024*1024));							// 6 MB
	__siCore->MemoryPool[36].InitialPoolSize = 1;
	__siCore->MemoryPool[36].IncrementPoolSize = 1;
	pthread_mutex_init( &__siCore->MemoryPool[36].Lock, NULL);

	__siCore->MemoryPool[37].size = ( 7 * (1024*1024));							// 7 MB
	__siCore->MemoryPool[37].InitialPoolSize = 1;
	__siCore->MemoryPool[37].IncrementPoolSize = 1;
	pthread_mutex_init( &__siCore->MemoryPool[37].Lock, NULL);

	__siCore->MemoryPool[38].size = ( 8 * (1024*1024));							// 8 MB
	__siCore->MemoryPool[38].InitialPoolSize = 1;
	__siCore->MemoryPool[38].IncrementPoolSize = 1;
	pthread_mutex_init( &__siCore->MemoryPool[38].Lock, NULL);

	__siCore->MemoryPool[39].size = ( 9 * (1024*1024));							// 9 MB
	__siCore->MemoryPool[39].InitialPoolSize = 1;
	__siCore->MemoryPool[39].IncrementPoolSize = 1;
	pthread_mutex_init( &__siCore->MemoryPool[39].Lock, NULL);

	
	#if SI_SXENG
		//__siCore->MemoryPool[7].size = 2100;
		__siCore->MemoryPool[7].InitialPoolSize = 5000;
		__siCore->MemoryPool[7].IncrementPoolSize = 1000;
	
		//__siCore->MemoryPool[31].size = ( 1 * (1024*1024));							// 1 MB
		__siCore->MemoryPool[31].InitialPoolSize = 200;
		__siCore->MemoryPool[31].IncrementPoolSize = 24;
	
		//__siCore->MemoryPool[32].size = ( 2 * (1024*1024));							// 2 MB
		__siCore->MemoryPool[32].InitialPoolSize = 100;
		__siCore->MemoryPool[32].IncrementPoolSize = 24;
	
		//__siCore->MemoryPool[33].size = ( 3 * (1024*1024));							// 3 MB
		__siCore->MemoryPool[33].InitialPoolSize = 30;
		__siCore->MemoryPool[33].IncrementPoolSize = 10;
	
		//__siCore->MemoryPool[34].size = ( 4 * (1024*1024));							// 4 MB
		__siCore->MemoryPool[34].InitialPoolSize = 20;
		__siCore->MemoryPool[34].IncrementPoolSize = 4;
		
		//__siCore->MemoryPool[35].size = ( 5 * (1024*1024));							// 5 MB
		__siCore->MemoryPool[35].InitialPoolSize = 3;
		__siCore->MemoryPool[35].IncrementPoolSize = 1;
		
		//__siCore->MemoryPool[36].size = ( 6 * (1024*1024));							// 6 MB
		__siCore->MemoryPool[36].InitialPoolSize = 3;
		__siCore->MemoryPool[36].IncrementPoolSize = 1;
	
		//__siCore->MemoryPool[37].size = ( 7 * (1024*1024));							// 7 MB
		__siCore->MemoryPool[37].InitialPoolSize = 3;
		__siCore->MemoryPool[37].IncrementPoolSize = 1;
	
		//__siCore->MemoryPool[38].size = ( 8 * (1024*1024));							// 8 MB
		__siCore->MemoryPool[38].InitialPoolSize = 3;
		__siCore->MemoryPool[38].IncrementPoolSize = 1;
	
	#endif	
	
	
	//memset is done for __siCore, no need to set null for members
	int i = 0;
	for( i = 0; i < 41; i++)
	{
		__siCore->MemoryPool[i].MemoryReservedCount = 0;
		__si_allocate_Memory( &__siCore->MemoryPool[i], __siCore->MemoryPool[i].InitialPoolSize, 1);
		
		//__siCore->MemoryPool[i].Available = __siCore->MemoryPool[i].InitialPoolSize;
		__siCore->MemoryPool[i].Used = 0;
		__siCore->MemoryPool[i].Returned = 0;
		
	}
}

int __si_getLocalTimeValue()
{
	return __siCore->LocalTimeValue;
}

void __si_setLocalTimeValue( int ltv)
{
	__siCore->LocalTimeValue = ltv;
}

int __si_lic__load_license( char * filename)
{
	//printf("%s\n", __FUNCTION__);
	//printf("loading license key: %s\n", filename);
	
	FILE * file = fopen( filename, "r");
	
	if(file)
	{
		struct stat st;
		int st_status = stat( filename, &st);
		u_char buffer[4096];
		memset( buffer, 0, sizeof( buffer));
		
		u_char act_buffer[4096];
		memset( act_buffer, 0, sizeof( act_buffer));
		
		if( st_status == 0)
		{
			int i = 0;
			while( i < st.st_size)
			{
				buffer[i] = getc( file);
				i++;
			}
			fclose( file);
			
			//printf("i=%d  SI_License=%ld\n", i, sizeof(SI_License));
			//printf("%s\n", buffer);
			
			int algId = 0;
			
			if( buffer[0] == '%' && buffer[1] == 'E' && buffer[2] == 'L' && buffer[3] == 'G' && buffer[4] == '-' &&
				buffer[5] == '9' && buffer[6] == '1' && buffer[7] == '%')
			{
				algId = 1;
			}
			else if( buffer[0] == '%' && buffer[1] == 'C' && buffer[2] == 'D' && buffer[3] == 'X' && buffer[4] == '-' &&
				buffer[5] == '8' && buffer[6] == '7' && buffer[7] == '%')
			{
				algId = 2;
			}
			
			if( algId == 0)
				return -3;
			
			int ix = 8;
			int j = 0;
			int jMax = 60;
			int act_i = 0, act_j = 0;
			
			if( algId == 2)
				jMax = 90;
	
			while( act_i < i)
			{
				act_buffer[act_j] = buffer[ix];
				ix++;
				act_i++;
				act_j++;
				
				if( j < jMax)
				{
					j++;
					ix++;
					act_i++;
				}
			}
			
			// printf("act_buffer=%s sz=%ld act_j=%d\n", act_buffer, sizeof(SI_License), act_j);
			
			Base64decode( (char *)&__siCore->license, act_buffer);
			
			// AlgId=%d ALG[%s] 
			// sLicense.algId, sLicense.alg, 
			
			printf("prodId[%u] MAC[%02X:%02X:%02X:%02X:%02X:%02X] serialNo=%d CN=%s IA=%s EXPIRY-DATE=%d-%02d-%02d DEVICE-ID=[%s] \n", 
					__siCore->license.productId, 
					__siCore->license.mac[0] & 0xFF, __siCore->license.mac[1] & 0xFF, __siCore->license.mac[2] & 0xFF,
					__siCore->license.mac[3] & 0xFF, __siCore->license.mac[4] & 0xFF, __siCore->license.mac[5] & 0xFF, 
					__siCore->license.serialNo, __siCore->license.company_short_name, __siCore->license.issuing_auth,
					(__siCore->license.expiry_date.tm_year + 1900), (__siCore->license.expiry_date.tm_mon + 1), 
					__siCore->license.expiry_date.tm_mday,
					__siCore->license.cpuid
				);
			
			return 1;
		}
		else
		{
			fclose( file);
			return -2;
		}
	}
	else
	{
		return -1;
	}
}


void __si_createLicenseKey( char * macAddress)
{
	struct timeval tv;
	struct timezone tzone;
	gettimeofday( &tv, &tzone);
	struct tm *timeinfo = gmtime( &tv.tv_sec);	
	
	char keyLen[20];
	
	keyLen[2] = macAddress[0];
	keyLen[4] = macAddress[1];
	keyLen[6] = macAddress[2];
	keyLen[8] = macAddress[3];
	keyLen[10] = macAddress[4];
	keyLen[12] = macAddress[5];
	
	keyLen[0] = timeinfo->tm_sec;
	keyLen[1] = (timeinfo->tm_sec + 5);	
	keyLen[3] = timeinfo->tm_sec + macAddress[3];
	keyLen[5] = timeinfo->tm_sec + macAddress[5];
	keyLen[7] = timeinfo->tm_sec + macAddress[2];
	keyLen[9] = timeinfo->tm_sec + macAddress[1];
	keyLen[11] = timeinfo->tm_sec + 11;
	keyLen[13] = timeinfo->tm_sec + 23;
	keyLen[14] = timeinfo->tm_sec + 34;
	keyLen[15] = timeinfo->tm_sec + 45;
	keyLen[16] = timeinfo->tm_sec + 56;
	keyLen[17] = timeinfo->tm_sec + 67;
	keyLen[18] = timeinfo->tm_sec + 78;
	keyLen[19] = 0;
	
	if( ( keyLen[0] % 2) == 1)
	{
		//printf( "MOD(1)\n");
		keyLen[2] = macAddress[5];
		keyLen[4] = macAddress[4];
		keyLen[6] = macAddress[3];
		keyLen[8] = macAddress[2];
		keyLen[10] = macAddress[1];
		keyLen[12] = macAddress[0];		
	}
	else
	{
		//printf( "MOD(0)\n");
	}
	
	/*
	printf("%02x:%02x:%02x:%02x:%02x:%02x\n", 
		macAddress[0] & 0xFF,
		macAddress[1] & 0xFF,
		macAddress[2] & 0xFF,
		macAddress[3] & 0xFF,
		macAddress[4] & 0xFF,
		macAddress[5] & 0xFF
	);
	*/
	/*
	int i = 0;
	for( i = 0; i < 20; i++)
	{
		if( i > 0){
			printf("-");
		}
		printf("%02x", keyLen[i] & 0xFF);
	}
	
	printf("\n");
	*/
	
	char sEncoded[200];
	memset( &sEncoded, 0, sizeof(sEncoded));
	
	Base64encode( sEncoded, keyLen, 20);
	//printf( "sEncoded = %s\n", sEncoded);
	
	char sCorrupted[400];
	memset( &sCorrupted, 0, sizeof(sCorrupted));	

	static const char xx[] =
    "wA4B5C2D1E5FhGlHpIpJdKgLaMtNyOrPwQrRsSqTqUdVaWqXcYdZabcdefghijklmnopqrstuvwxyz0123456ww7892+/wA4B5C2D1E5FhGlHpIpJdKgLaMtNyOrPwQrRsSqTqUdVaWqXcYdZabcdefghijklmnopqrstuvwxyz0123456ww7892+/wA4B5C2D1E5FhGlHpIpJdKgLaMtNyOrPwQrRsSqTqUdVaWqXcYdZabcdefghijklmnopqrstuvwxyz0123456ww7892+/";
	
	int j = 0;
	int i = 0;
	
	for( i = 0; i < strlen(sEncoded); i++)
	{
		sCorrupted[j] = sEncoded[i];
		j++;
		sCorrupted[j] = xx[ timeinfo->tm_sec + i];
		j++;		
	}
	sCorrupted[j-1] = '=';
	
	printf( "%s\n", sCorrupted);	
}

void __si_retrieveLicenseKey( char * base64)
{
	int len = strlen( base64);
	if( (len % 2) == 0)
	{
		//printf("valid length\n");
		char sEncoded[200];
		memset( &sEncoded, 0, sizeof(sEncoded));		
		
		int i = 0;
		int j = 0;
		
		for( i = 0; i < len; i++)
		{
			if( (i % 2) == 0)
			{	
				sEncoded[j] = base64[i];
				j++;
			}
		}
		
		//printf("O=%s\n", sEncoded);
		
		char keyLen[20];
		memset( keyLen, 0, sizeof(keyLen));
		
		Base64decode( keyLen, sEncoded);
		
		/*
		i = 0;
		for( i = 0; i < 20; i++)
		{
			if( i > 0){
				printf("-");
			}
			printf("%02x", keyLen[i] & 0xFF);
		}
		printf("\n");
		*/
		/*
		char macAddress[6];
		
		if( ( keyLen[0] % 2) == 1)
		{
			macAddress[5] = keyLen[2];
			macAddress[4] = keyLen[4];
			macAddress[3] = keyLen[6];
			macAddress[2] = keyLen[8];
			macAddress[1] = keyLen[10];
			macAddress[0] = keyLen[12];
		}
		else
		{
			macAddress[0] = keyLen[2];
			macAddress[1] = keyLen[4];
			macAddress[2] = keyLen[6];
			macAddress[3] = keyLen[8];
			macAddress[4] = keyLen[10];
			macAddress[5] = keyLen[12];			
		}
		*/
		/*
		printf("__si_retrieveLicenseKey %02x:%02x:%02x:%02x:%02x:%02x\n", 
			macAddress[0] & 0xFF,
			macAddress[1] & 0xFF,
			macAddress[2] & 0xFF,
			macAddress[3] & 0xFF,
			macAddress[4] & 0xFF,
			macAddress[5] & 0xFF
		);	
		*/	
	}
	else
	{
		printf("invalid length\n");
	}
}


int __si_ValidateLocalIPv4( uint32_t ipv4)
{
	struct ifaddrs *ifaddr, *ifa;
	int family, s;
	char host[100];
	
	if (getifaddrs(&ifaddr) == -1)
	{
		perror("getifaddrs");
		exit(0);
	}
	
	for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next)
	{
		if (ifa->ifa_addr == NULL)
			continue;
		
		if( ifa->ifa_addr->sa_family == AF_INET)
		{
			struct sockaddr_in * sa_in = (struct sockaddr_in *)ifa->ifa_addr;
			
			if( ipv4 == sa_in->sin_addr.s_addr)
			{
				freeifaddrs( ifaddr);
				return 1;
			}

			//printf( "sin_addr.s_addr=%u|%s\n", sa_in->sin_addr.s_addr, __si_core_convert_inttoipv4( sa_in->sin_addr.s_addr));
		}			
	}		
	
	freeifaddrs( ifaddr);
	return -1;
}

int __si_ValidateLicenseExpiryDate()
{
	if( __siCore->license.algId == 0)
		return -1;
	
	struct timezone tzone;
	struct timeval curr_timeval;
	gettimeofday( &curr_timeval, &tzone);
	
	time_t license_time = mktime( &__siCore->license.expiry_date);
	
	//printf( "remainig seconds = %ld\n", (license_time - curr_timeval.tv_sec));
	
	if( (license_time - curr_timeval.tv_sec) < 0)
	{
		return -4;
	}
	
	return 1;
}

int __si_ValidateDeviceId()
{
	if( __siCore->license.algId == 0)
		return -1;	
	
	int slen = strlen( __siCore->license.cpuid);
	
	if( slen == 0) return -1;
	
	
	char devInfob64[100];
	memset( devInfob64, 0, sizeof( devInfob64));
	
	int i = 0;
	for( i = 0; i < slen; i++)
	{
		devInfob64[i] = __siCore->license.cpuid[slen-(i+1)];
	}
	
	
	char devInfo[100];
	memset( devInfo, 0, sizeof( devInfo));	
	
	int pb = Base64decode( devInfo, devInfob64);
	
	//printf("devInfob64:[%s][%s][%d]\n", devInfob64, devInfo, pb);
	
	if( pb < 8) return -1;
	
	char PSN[10] = {0,0,0,0,0,0,0,0,0,0};
	__si_getCPUId( PSN);
	
	if( memcmp( PSN, devInfo, pb) == 0)
		return 1;
	else
		return -1;
}

int __si_ValidateLicenseWithExpiryDate( int prodId)
{
	if( __siCore->license.algId == 0)
		return -1;
	
	if( __siCore->license.productId != prodId)
	{
		return -2;
	}
	
	if( __si_ValidateMACAddress( __siCore->license.mac) != 1)
	{
		return -3;
	}
	
	struct timezone tzone;
	struct timeval curr_timeval;
	gettimeofday( &curr_timeval, &tzone);
	
	time_t license_time = mktime( &__siCore->license.expiry_date);
	
	//printf( "remainig seconds = %ld\n", (license_time - curr_timeval.tv_sec));
	
	if( (license_time - curr_timeval.tv_sec) < 0)
	{
		return -4;
	}
	/*
	else
	{
		//printf("remaining days = %ld\n", (license_time - curr_timeval.tv_sec)/86400);
	}
	*/
	
	
	//currently not validating device id 23-NOV-2020
	/*
	if( __si_ValidateDeviceId() != 1)
	{
		return -5;
	}
	*/
	
	//(__siCore->license.expiry_date.tm_year + 1900), (__siCore->license.expiry_date.tm_mon + 1), __siCore->license.expiry_date.tm_mday
	//char * macAddress, int prodId
	
	return 1;
}


char * __si__get_pci_bus_name__by_ifname( char * ifname)
{
	char path[PATH_MAX];
	char resolved[PATH_MAX];
	
	memset( path, 0, sizeof(path));
	memset( resolved, 0, sizeof(resolved));
	
	sprintf( path, "/sys/class/net/%s/device", ifname);
	
	size_t llen = readlink( path, resolved, sizeof(resolved) - 1);
	
	if( llen == -1)
	{
		return NULL;
	}
	
	resolved[llen] = '\0';
	
	char * busname = strrchr( resolved, '/');
	return busname + 1;
}

int __si_get_ipv4_by_ifname( char * ifname, uint32_t * uIPv4)
{
	int fd = 0;
	struct ifreq ifr;
	memset( &ifr, 0, sizeof(struct ifreq));
	strcpy( ifr.ifr_name, ifname);
	
	fd = socket( AF_INET, SOCK_DGRAM, 0);
	if( fd < 0) 
	{
		return -1;
	}
	
	if( ioctl( fd, SIOCGIFADDR, &ifr) < 0)
	{
		close( fd);
		return -2;
	}
	
	struct sockaddr_in * ipaddr = (struct sockaddr_in *)&ifr.ifr_addr;
	*uIPv4 = (uint32_t)ipaddr->sin_addr.s_addr;
	close( fd);
	return 0;
}

int __si_ifname_by_ip( char * ifname, char * ip)
{
	struct in_addr ip_addr;
	int bFound = 0;
	
	if( inet_pton( AF_INET, ip, &ip_addr) <= 0)
	{
		printf("inet_pton failed\n");
		return 0;
	}
	
	int sock = socket( AF_INET, SOCK_DGRAM, 0);
	if( sock < 0)
	{
		printf("socket creation failed\n");
		return 0;		
	}
	
	struct ifconf ifc;
	memset( &ifc, 0, sizeof(struct ifconf));
	char buf[8192];
	memset( buf, 0, sizeof(buf));
	ifc.ifc_len = sizeof(buf);
    ifc.ifc_buf = buf;
	
	if ( ioctl( sock, SIOCGIFCONF, &ifc) == -1) 
	{ 
		printf( "ioctl failed  | (%d) - %s \n", errno, strerror(errno));
		exit(0);
	}	
	
	struct ifreq * ifr = ifc.ifc_req;
    int num_interfaces = (ifc.ifc_len / sizeof(struct ifreq));
	
	int i = 0;
	for ( i = 0; i < num_interfaces; i++) 
	{
		struct sockaddr_in * sin = (struct sockaddr_in *)&ifr[i].ifr_addr;
		
		if( sin->sin_family == AF_INET)
		{
			if( memcmp( &sin->sin_addr, &ip_addr, sizeof(struct in_addr)) == 0)
			{
				strcpy( ifname, ifr[i].ifr_name);
				bFound = 1;
				break;
			}
		}
	}
	
	close(sock);
	return bFound;
}

int __si_get_ifname_by_ipv4( char * ifname, char * ip)
{
	return __si_ifname_by_ip( ifname, ip);
}

int __si_ValidateMACAddress( char * macAddress)
{
    struct ifreq ifr;
    struct ifconf ifc;
    char buf[1024];
    //int success = 0;

	int sock = socket( AF_INET, SOCK_DGRAM, IPPROTO_IP);
	
	if (sock <= 0) 
	{ 
		printf( "socket creation failed for MAC Validation | (%d) - %s \n", errno, strerror(errno));
		exit(0);
	};
	
    ifc.ifc_len = sizeof(buf);
    ifc.ifc_buf = buf;
	
    if ( ioctl(sock, SIOCGIFCONF, &ifc) == -1) 
	{ 
		printf( "ioctl failed for MAC Validation | (%d) - %s \n", errno, strerror(errno));
		exit(0);
	}	
	
	struct ifreq * it = ifc.ifc_req;
    const struct ifreq * const end = it + (ifc.ifc_len / sizeof(struct ifreq));
	
	for (; it != end; ++it) 
	{
		strcpy(ifr.ifr_name, it->ifr_name);
		//printf( "%s \n", it->ifr_name);
		if (ioctl(sock, SIOCGIFFLAGS, &ifr) == 0) 
		{
			if (! (ifr.ifr_flags & IFF_LOOPBACK)) 
			{
				if (ioctl( sock, SIOCGIFHWADDR, &ifr) == 0) 
				{
					/*
					printf( "address : %02x:%02x:%02x:%02x:%02x:%02x \n", 
						ifr.ifr_hwaddr.sa_data[0] & 0xFF,
						ifr.ifr_hwaddr.sa_data[1] & 0xFF,
						ifr.ifr_hwaddr.sa_data[2] & 0xFF,
						ifr.ifr_hwaddr.sa_data[3] & 0xFF,
						ifr.ifr_hwaddr.sa_data[4] & 0xFF,
						ifr.ifr_hwaddr.sa_data[5] & 0xFF
					);
					
					printf( "address : %02x:%02x:%02x:%02x:%02x:%02x \n", 
						macAddress[0] & 0xFF,
						macAddress[1] & 0xFF,
						macAddress[2] & 0xFF,
						macAddress[3] & 0xFF,
						macAddress[4] & 0xFF,
						macAddress[5] & 0xFF
					);
					*/
					
					if( ifr.ifr_hwaddr.sa_data[0] == macAddress[0] && ifr.ifr_hwaddr.sa_data[1] == macAddress[1] && 
						ifr.ifr_hwaddr.sa_data[2] == macAddress[2] && ifr.ifr_hwaddr.sa_data[3] == macAddress[3] && 
						ifr.ifr_hwaddr.sa_data[4] == macAddress[4] && ifr.ifr_hwaddr.sa_data[5] == macAddress[5])
					{
						return 1;
					}
				}
			}
		}
	}
	
	return 0;
}

void __si_enable_coredump()
{
	struct rlimit core_limits;
	core_limits.rlim_cur = core_limits.rlim_max = RLIM_INFINITY;
	setrlimit( RLIMIT_CORE, &core_limits);
}

void __si_core_set_max_fd( int iMaxFdCount)
{
	struct rlimit limit;
	
	if (getrlimit( RLIMIT_NOFILE, &limit) != 0) 
	{
		printf("getrlimit() failed with errno=%d, requires sudo user\n", errno);
		return;
	}
	
	//printf("The current fd soft limit is %lu\n", limit.rlim_cur);
	//printf("The current fd hard limit is %lu\n", limit.rlim_max);
	
	if( limit.rlim_cur < iMaxFdCount)
	{
		limit.rlim_cur = iMaxFdCount;
		
		if( limit.rlim_max < iMaxFdCount)
		{	
			limit.rlim_max = iMaxFdCount;		
		}
		
		if (setrlimit( RLIMIT_NOFILE, &limit) != 0) 
		{
			printf("setrlimit() failed with errno=%d, unable to set max fd-to-%d\n", errno, iMaxFdCount);
			return;
		}
		
		memset( &limit, 0, sizeof(struct rlimit));
		
		if (getrlimit( RLIMIT_NOFILE, &limit) != 0) 
		{
			printf("getrlimit() failed with errno=%d\n", errno);
			return;
		}
		
		printf("new fd soft limit is %lu\n", limit.rlim_cur);
		printf("new fd hard limit is %lu\n", limit.rlim_max);
	
	}
	
}

/***********************************************/
// linked list
void __si_linked_list_add_to_pool( SI_LinkedList * linkedList, int inLockMode)
{
	if(inLockMode) 
	{
		pthread_mutex_lock( &__siCore->LinkedListPoolLock);
	}
	
	if( linkedList->isReleased == 0)
	{
		linkedList->isReleased = 1;
		
		if( !__siCore->LinkedListPoolHead)
		{
			__siCore->LinkedListPoolHead = __siCore->LinkedListPoolCurrent = linkedList;
		}
		else
		{
			__siCore->LinkedListPoolCurrent->Next = linkedList;
			__siCore->LinkedListPoolCurrent = linkedList;
		}
		__siCore->AvailableLinkedListPoolCount++;
	}
	
	if(inLockMode) 
	{
		pthread_mutex_unlock( &__siCore->LinkedListPoolLock);	
	}
}

void __si_linked_list_create( int size, int inLockMode)
{
	if(inLockMode) 
	{
		pthread_mutex_lock( &__siCore->LinkedListPoolLock);
	}
	
	SI_LinkedList * linkedList = NULL;
	
	int i = 0;
	for( i = 0; i < size; i++)
	{
		__si_malloc2( sizeof(SI_LinkedList), (uint8_t **) &linkedList);
		
		linkedList->Next = NULL;
		
		linkedList->Head = NULL;
		linkedList->Current = NULL;		
		linkedList->Count = 0;
		linkedList->isReleased = 0;
		pthread_mutex_init( &linkedList->Lock, NULL);	
		
		__si_linked_list_add_to_pool( linkedList, 0); 
		__siCore->TotalLinkedListPoolCount++;
	}
	
	if(inLockMode) 
	{
		pthread_mutex_unlock( &__siCore->LinkedListPoolLock);	
	}
}

SI_LinkedList * __si_linked_list_allocate()
{
	pthread_mutex_lock( &__siCore->LinkedListPoolLock);

	if(!__siCore->LinkedListPoolHead) {
		__si_linked_list_create( 5, 0);
	}
	
	SI_LinkedList * linkedList = __siCore->LinkedListPoolHead;
	
	if( linkedList)
	{
		__siCore->LinkedListPoolHead = linkedList->Next;
		linkedList->Next = NULL;
		
		linkedList->Head = NULL;
		linkedList->Current = NULL;		
		linkedList->Count = 0;
		linkedList->isReleased = 0;
		
		__siCore->AvailableLinkedListPoolCount--;
	}
	
	pthread_mutex_unlock( &__siCore->LinkedListPoolLock);	
	
	return linkedList;
}

void __si_linked_list_release( SI_LinkedList * linkedList)
{
	__si_linked_list_add_to_pool( linkedList, 1);
}

void __si_linked_list_add( SI_LinkedList * ll, uint8_t * dataPtr)
{
	pthread_mutex_lock( &ll->Lock);
	
	SI_LinkedListItem * item = (SI_LinkedListItem *) __si_allocM7( sizeof(SI_LinkedListItem), __FILE__, __LINE__, 0);
	memset( item, 0, sizeof( SI_LinkedListItem));
	
	item->dataPtr = dataPtr;
	item->Prev = item->Next = NULL;

	if( !ll->Head)
	{
		ll->Head = ll->Current = item;
	}
	else
	{
		item->Prev = ll->Current;
		item->Next = NULL;
		
		ll->Current->Next = item;
		ll->Current = item;
	}
	
	ll->Count++;
	
	pthread_mutex_unlock( &ll->Lock);
}

int __si_linked_list_count( SI_LinkedList * ll)
{
	return ll->Count;
}

void __si_linked_list_removeAll( SI_LinkedList * ll)
{
	pthread_mutex_lock( &ll->Lock);

	SI_LinkedListItem * item = ll->Head;
	SI_LinkedListItem * itemNext = NULL;
	
	while( item)
	{
		itemNext = item->Next;
		
		item->Next = NULL;
		item->Prev = NULL;
		
		__si_freeM( (uint8_t *)item);
		
		item = itemNext;
	}
	
	ll->Head = NULL;
	ll->Current = NULL;
	ll->Count = 0;
	
	pthread_mutex_unlock( &ll->Lock);
}

int __si_linked_list_remove_item( SI_LinkedList * ll , uint8_t * u8ItemToRemove)
{
	SI_LinkedListItem * item = ll->Head;
	SI_LinkedListItem * itemToRemove = NULL;
	
	while( item)
	{
		if( item->dataPtr == u8ItemToRemove)
		{
			itemToRemove = item;
			break;
		}
		item = item->Next;
	}	
	
	if( itemToRemove)
	{
		pthread_mutex_lock( &ll->Lock);
		
		SI_LinkedListItem * prevItem = NULL;
		SI_LinkedListItem * nextItem = NULL;
		
		if( itemToRemove->Prev)
		{
			prevItem = itemToRemove->Prev;
		}
		
		if( itemToRemove->Next)
		{
			nextItem = itemToRemove->Next;
		}
		
		itemToRemove->Prev = NULL; 
		itemToRemove->Next = NULL; 
		
		if( prevItem)
		{
			prevItem->Next = nextItem;
		}
		
		if( nextItem)
		{
			nextItem->Prev = prevItem;
		}
		
		ll->Count--;
		__si_freeM( (uint8_t *)itemToRemove);
		itemToRemove = NULL;
		
		pthread_mutex_unlock( &ll->Lock);
		return 1;
	}

	return 0;	
}

int __si_linked_list_remove_itemAt( SI_LinkedList * ll , int index)
{
	SI_LinkedListItem * item = ll->Head;
	SI_LinkedListItem * itemToRemove = NULL;
	
	int i = 0;
	while( i <= index && item)
	{
		if( i == index)
		{
			itemToRemove = item;
			break;
		}
		
		i++;
		item = item->Next;
	}	
	
	if( itemToRemove)
	{
		pthread_mutex_lock( &ll->Lock);
		
		SI_LinkedListItem * prevItem = NULL;
		SI_LinkedListItem * nextItem = NULL;
		
		if( itemToRemove->Prev)
		{
			prevItem = itemToRemove->Prev;
		}
		
		if( itemToRemove->Next)
		{
			nextItem = itemToRemove->Next;
		}
		
		itemToRemove->Prev = NULL; 
		itemToRemove->Next = NULL; 
		
		if( prevItem)
		{
			prevItem->Next = nextItem;
		}
		
		if( nextItem)
		{
			nextItem->Prev = prevItem;
		}
		
		ll->Count--;
		__si_freeM( (uint8_t *)itemToRemove);
		itemToRemove = NULL;
		
		pthread_mutex_unlock( &ll->Lock);
		return 1;
	}		
	
	return 0;
}

void __si_linked_list_push( SI_LinkedList * ll, uint8_t * item)
{
	__si_linked_list_add( ll, item);
}

uint8_t * __si_linked_list_pop( SI_LinkedList * ll)
{
	uint8_t * item = NULL;
	pthread_mutex_lock( &ll->Lock);
	
	SI_LinkedListItem * llHead = ll->Head;
	
	if( llHead)
	{
		 item = llHead->dataPtr;
		 ll->Head = llHead->Next;
		 
		 if( ll->Head) {
			ll->Head->Prev = NULL;
		 }
		 
		 llHead->Next = NULL;
		 llHead->Prev = NULL;
		 llHead->dataPtr = NULL;
		 ll->Count--;
		__si_freeM( (uint8_t *)llHead);
	}
	
	pthread_mutex_unlock( &ll->Lock);
	return item;
}

uint8_t * __si_linked_list_get_item( SI_LinkedList * ll , int index)
{
	pthread_mutex_lock( &ll->Lock);
	
	SI_LinkedListItem * item = ll->Head;
	
	int i = 0;
	while( i <= index && item)
	{
		if( i == index)
		{	
			pthread_mutex_unlock( &ll->Lock);
			return item->dataPtr;
		}
		
		i++;
		item = item->Next;
	}
	
	pthread_mutex_unlock( &ll->Lock);
	return NULL;
}

// linked list
/***********************************************/

typedef struct __si_core_fsm_queue SI_CoreFSMQueue;

//#pragma pack(4)
typedef struct __si_core_queue
{
	SI_CoreQueueRecord * Head;
	SI_CoreQueueRecord * Current;	
	//SI_CoreFSMQueue * fsmQ;

	int ThreadCount;
	int MaxQueueCount;
	int CurrentQueueCount;
	long TotalQueued;
	long TotalProcessed;
	int LastProcessed;
	int MPS;					// Messages Per Second
	int MPSCounter;				// Messages Per Second Counter;
	int KeepAlive;
	pthread_mutex_t Lock;	
	sem_t sem_lock;
} SI_CoreQueue;

//#pragma pack(4)
typedef struct __si_core_routing_pointer
{
	void (*Routine)(void *); 
	void (*Routine2)(void *, int);
	//void (*Routine3)(void *, int, void *);	
	SI_CoreQueue * queueObject;
	int iIndex;
} SI_CoreQueue_RoutingPointer;

//#pragma pack(4)
typedef struct __si_core_fsm_queue
{
	SI_CoreQueue ** coreQueue;
	int ThreadCount;
	int MaxQueueCount;
	//int CurrentQueueCount;
	//long TotalQueued;
	pthread_mutex_t Lock;
} SI_CoreFSMQueue;

void __si_core_add_data_record_to_pool( SI_CoreDataRecord * dRecord, int inLockMode)
{
	if(inLockMode) {
		pthread_mutex_lock( &__siCore->DataRecordLock);
	}
	
	if(!__siCore->DataRecordHead) {
		__siCore->DataRecordHead = __siCore->DataRecordCurrent = dRecord;
	} else {
		__siCore->DataRecordCurrent->Next = dRecord;
		__siCore->DataRecordCurrent = dRecord;
	}
	
	if(inLockMode) {
		pthread_mutex_unlock( &__siCore->DataRecordLock);
	}	
}

void __si_core_create_data_record_pool( int size, int inLockMode)
{
	if(inLockMode) {
		pthread_mutex_lock( &__siCore->DataRecordLock);
	}
	
	int i = 0;
	SI_CoreDataRecord * qRecord = NULL;
	
	for( i = 0; i < size; i++)
	{
		__si_malloc2( sizeof( SI_CoreDataRecord), ( uint8_t **) &qRecord);
		
		qRecord->data1 = NULL;
		qRecord->data2 = NULL;
		qRecord->Next = NULL;
		
		__si_core_add_data_record_to_pool( qRecord, 0);
	}
	
	if(inLockMode) {
		pthread_mutex_unlock( &__siCore->DataRecordLock);
	}	
}

SI_CoreDataRecord * __si_core_allocate_data_record()
{
	pthread_mutex_lock( &__siCore->DataRecordLock);
	
	if(!__siCore->DataRecordHead) {
		__si_core_create_data_record_pool( 500, 0);
	}
	
	SI_CoreDataRecord * qRecord = __siCore->DataRecordHead;
	
	if( qRecord)
	{
		__siCore->DataRecordHead = qRecord->Next;
		
		qRecord->data1 = qRecord->data2 = qRecord->data3 = qRecord->data4 = NULL;
		qRecord->Next = NULL;
	}
	
	pthread_mutex_unlock( &__siCore->DataRecordLock);
	
	return qRecord;
}

void __si_core_release_data_record( SI_CoreDataRecord * qRecord)
{
	__si_core_add_data_record_to_pool( qRecord, 1);
}




void __si_core_add_queue_record_to_pool( SI_CoreQueueRecord * qRecord, int inLockMode)
{
	if(inLockMode) {
		pthread_mutex_lock( &__siCore->QueueRecordLock);
	}
	
	if(!__siCore->QueueRecordHead) {
		__siCore->QueueRecordHead = __siCore->QueueRecordCurrent = qRecord;
	} else {
		__siCore->QueueRecordCurrent->Next = qRecord;
		__siCore->QueueRecordCurrent = qRecord;
	}
	
	if(inLockMode) {
		pthread_mutex_unlock( &__siCore->QueueRecordLock);
	}	
}

void __si_core_create_queue_record_pool( int size, int inLockMode)
{
	if(inLockMode) {
		pthread_mutex_lock( &__siCore->QueueRecordLock);
	}
	
	int i = 0;
	SI_CoreQueueRecord * qRecord = NULL;
	
	for( i = 0; i < size; i++)
	{
		__si_malloc2( sizeof( SI_CoreQueueRecord), ( uint8_t **) &qRecord);
		
		qRecord->Data = NULL;
		qRecord->Next = NULL;
		qRecord->isReleased = 1;
		
		__si_core_add_queue_record_to_pool( qRecord, 0);
	}
	
	if(inLockMode) {
		pthread_mutex_unlock( &__siCore->QueueRecordLock);
	}	
}

SI_CoreQueueRecord * __si_core_allocate_queue_record()
{
	pthread_mutex_lock( &__siCore->QueueRecordLock);
	
	if(!__siCore->QueueRecordHead) {
		__si_core_create_queue_record_pool( 500, 0);
	}
	
	SI_CoreQueueRecord * qRecord = __siCore->QueueRecordHead;
	
	if( qRecord)
	{
		__siCore->QueueRecordHead = qRecord->Next;
		qRecord->Next = NULL;
		qRecord->executor = NULL;
		qRecord->isReleased = 0;
	}
	
	pthread_mutex_unlock( &__siCore->QueueRecordLock);
	
	return qRecord;
}

void __si_core_release_queue_record( SI_CoreQueueRecord * qRecord)
{
	__si_core_add_queue_record_to_pool( qRecord, 1);
}

void __si_core_release_queue_record_bulk( SI_CoreQueueRecord ** qRecords, int size)
{
	if( size > 0)
	{
		pthread_mutex_lock( &__siCore->QueueRecordLock);
		
		int i = 0;
		for( i = 0; i < size; i++)
		{
			__si_core_add_queue_record_to_pool( qRecords[i], 0);
		}
		
		pthread_mutex_unlock( &__siCore->QueueRecordLock);
	}
}


__si_mpscounter funcHandler = NULL;
void __si_set_mpscounter( __si_mpscounter Handler)
{
	funcHandler = Handler;
}

void * __si_core_queue_processing_thread( void * args)
{
	SI_CoreQueue_RoutingPointer * oRoutingPointer = ( SI_CoreQueue_RoutingPointer *) args;
	SI_CoreQueue * objQueue = oRoutingPointer->queueObject;
	
	void * dataPtr = NULL;
	void (*executor)( void *) = NULL;		//added on 04-12-2020 
	
	SI_CoreQueueRecord * qRecord = NULL;
	
	while(1)
	{	
		sem_wait( &objQueue->sem_lock);
		
		objQueue->KeepAlive++;
		
		if( objQueue->KeepAlive > 999999)
		{
			objQueue->KeepAlive = 0;
		}
		
		
		pthread_mutex_lock( &objQueue->Lock);
		
		qRecord = objQueue->Head;

		//printf("[%s,%d] qRecord=%p, threadIndex=%d\n", __FUNCTION__, __LINE__, qRecord, oRoutingPointer->iIndex);
		
		if( qRecord)
		{
			objQueue->Head = qRecord->Next;
			dataPtr = qRecord->Data;
			executor = qRecord->executor;
			
			qRecord->Data = NULL;
			qRecord->Next = NULL;
			
			__si_core_release_queue_record( qRecord);
			objQueue->CurrentQueueCount--;
			objQueue->TotalProcessed++;
		}
		
		pthread_mutex_unlock( &objQueue->Lock);
		
		if( dataPtr)
		{
			if( executor > 0)
				executor( dataPtr);
			else	
				oRoutingPointer->Routine2( dataPtr, oRoutingPointer->iIndex);
		
			// Messages per second implementation
			if( objQueue->MPS > 0)
			{
				objQueue->MPSCounter++;
				
				if( funcHandler > 0) {
					funcHandler();
				}
				
				if( objQueue->MPS == objQueue->MPSCounter) 
				{
					//__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "Delaying Q=%p as Per MPS=%d  %s|%d", objQueue, objQueue->MPS, __FUNCTION__, __LINE__);
					objQueue->MPSCounter = 0;
					//sleep(1);
					//int __si_nanosleep( long tv_nsec /* 0 to 999999999*/ )
					__si_nanosleep( 999999999/10 );	//10 times in second
					//usleep( 999999);
				}
			}
			
		}
		
		dataPtr = NULL;
		executor = NULL;
		qRecord = NULL;
	}
	
	return NULL;
}

SI_CoreQueue * __si_core_create_queueobject( int forAppWorkerThreads, int maxQueueItems)
{
	SI_CoreQueue * objQueue = (SI_CoreQueue *) __si_malloc( sizeof( SI_CoreQueue));
	memset( objQueue, 0, sizeof( SI_CoreQueue));
	
	objQueue->MaxQueueCount = maxQueueItems;
	objQueue->CurrentQueueCount = 0;
	objQueue->MPS = 0;
	objQueue->MPSCounter = 0;
	objQueue->KeepAlive = 0;
	objQueue->TotalQueued = 0;
	objQueue->LastProcessed = 0;
	objQueue->TotalProcessed = 0;
	
	pthread_mutex_init( &objQueue->Lock, NULL);
	sem_init( &objQueue->sem_lock, 0, 0);
	
	return objQueue;
}

int __si_core_queue_get( SI_CoreQueue * objQueue, uint8_t ** dataItem)
{
	int sts = 0;
	*dataItem = NULL;
	
	pthread_mutex_lock( &objQueue->Lock);
		
		SI_CoreQueueRecord * qRecord = objQueue->Head;
		
		if( qRecord)
		{
			objQueue->Head = qRecord->Next;
			*dataItem = qRecord->Data;
			
			qRecord->Data = NULL;
			qRecord->Next = NULL;
			
			__si_core_release_queue_record( qRecord);
			objQueue->CurrentQueueCount--;
			objQueue->TotalProcessed++;
			
			sts = 1;
		}
	
	pthread_mutex_unlock( &objQueue->Lock);
	
	return sts;
}

int __si_core_queue_wait( SI_CoreQueue * objQueue, uint8_t ** dataItem)
{
	sem_wait( &objQueue->sem_lock);
	return __si_core_queue_get( objQueue, dataItem);
}

int __si_core_queue_post( SI_CoreQueue * objQueue, uint8_t * item)
{
	int rStatus = 0;
	
	pthread_mutex_lock( &objQueue->Lock);	
	
	if( (objQueue->CurrentQueueCount < objQueue->MaxQueueCount))
	{
		rStatus = 1;
		
		SI_CoreQueueRecord * qRecord = __si_core_allocate_queue_record();
		qRecord->Data = item;
		
		if( !objQueue->Head) 
		{
			objQueue->Head = objQueue->Current = qRecord;
		} 
		else 
		{
			objQueue->Current->Next = qRecord;
			objQueue->Current = qRecord;
		}
		
		objQueue->CurrentQueueCount++;
	}
	
	pthread_mutex_unlock( &objQueue->Lock);
	sem_post( &objQueue->sem_lock);
	
	return rStatus;
}

// mps = Message Per Second
void __si_core_queue_set_mps( void * queuePoolObject, int mps)
{
	SI_CoreQueue * objQueue = (SI_CoreQueue *) queuePoolObject;
	objQueue->MPS = mps;
}


void __si_core_create_bulk_queue( void **queuePoolObject, int maxQueueItems)
{
	SI_CoreQueue * objQueue = (SI_CoreQueue *) __si_malloc_block( sizeof( SI_CoreQueue), __FILE__, __LINE__);
	memset( objQueue, 0, sizeof( SI_CoreQueue));
	
	objQueue->MPS = 0;
	objQueue->MPSCounter = 0;
	objQueue->MaxQueueCount = maxQueueItems;
	objQueue->CurrentQueueCount = 0;
	objQueue->KeepAlive = 0;
	objQueue->TotalQueued = 0;
	objQueue->LastProcessed = 0;
	objQueue->TotalProcessed = 0;

	*queuePoolObject = objQueue;

	pthread_mutex_init( &objQueue->Lock, NULL);
	sem_init( &objQueue->sem_lock, 0, 0);
}


//void QueuePool_CreateWithNThreads2( void **pQueuePoolObject, void (*ptrCallBackHandler)(void*), int iNoOfThreads)
void __si_core_create_queue( void ** queuePoolObject, void (*ptrCallBackHandler)(void*, int), int iNoOfThreads, int maxQueueItems)
{
	//SI_CoreQueue * objQueue = (SI_CoreQueue *) __si_malloc( sizeof( SI_CoreQueue));
	//SI_CoreQueue * objQueue = (SI_CoreQueue *) malloc( sizeof( SI_CoreQueue));
	SI_CoreQueue * objQueue = (SI_CoreQueue *) __si_malloc_block( sizeof( SI_CoreQueue), __FILE__, __LINE__);
	memset( objQueue, 0, sizeof( SI_CoreQueue));
	
	objQueue->MPS = 0;
	objQueue->MPSCounter = 0;
	objQueue->MaxQueueCount = maxQueueItems;
	objQueue->CurrentQueueCount = 0;
	objQueue->KeepAlive = 0;
	objQueue->TotalQueued = 0;
	objQueue->LastProcessed = 0;
	objQueue->TotalProcessed = 0;

	*queuePoolObject = objQueue;
	
	pthread_mutex_init( &objQueue->Lock, NULL);
	sem_init( &objQueue->sem_lock, 0, 0);
	
	if( ptrCallBackHandler )
	{
		int i = 0;
		for( i = 0; i < iNoOfThreads; i++)
		{
			//SI_CoreQueue_RoutingPointer * oRoutingPointer = (SI_CoreQueue_RoutingPointer *) __si_malloc(sizeof(SI_CoreQueue_RoutingPointer));
			//SI_CoreQueue_RoutingPointer * oRoutingPointer = (SI_CoreQueue_RoutingPointer *) malloc(sizeof(SI_CoreQueue_RoutingPointer));
			SI_CoreQueue_RoutingPointer * oRoutingPointer = NULL;
			__si_malloc2( sizeof(SI_CoreQueue_RoutingPointer), (uint8_t **)&oRoutingPointer);
			
			oRoutingPointer->Routine2 = ptrCallBackHandler;
			oRoutingPointer->queueObject = objQueue;
			oRoutingPointer->iIndex = i;
			
			__si_create_pthread2( __si_core_queue_processing_thread, oRoutingPointer, "app_thread");
		}
	}
}

int __si_core_queue_bulk_items_force( void * queuePoolObject, uint8_t ** dataItem, int force, int count)
{
	SI_CoreQueue * objQueue = (SI_CoreQueue * ) queuePoolObject;
	
	if( !objQueue)
	{	
		printf("[coding problem] invalid queue object %d|%s\n", __LINE__, __FUNCTION__);
		return -1;
	}
	
	int rStatus = 0;
	
	pthread_mutex_lock( &objQueue->Lock);
	int j = 0;
	
	for( j = 0 ; j < count; j++)
	{
		if( (objQueue->CurrentQueueCount < objQueue->MaxQueueCount) || force == 1)
		{
			rStatus++;
			
			SI_CoreQueueRecord * qRecord = __si_core_allocate_queue_record();
			qRecord->Data = dataItem[j];
			
			if( !objQueue->Head) 
			{
				objQueue->Head = objQueue->Current = qRecord;
			} 
			else 
			{
				objQueue->Current->Next = qRecord;
				objQueue->Current = qRecord;
			}
			objQueue->CurrentQueueCount++;
			objQueue->TotalQueued++;
		}
	}
	
	pthread_mutex_unlock( &objQueue->Lock);

	
	sem_post( &objQueue->sem_lock);
	return rStatus;
}


int __si_core_queue_bulk_items_recv( void * queuePoolObject, uint8_t ** dataItem, int size)
{
	SI_CoreQueue * objQueue = (SI_CoreQueue * ) queuePoolObject;
	
	pthread_mutex_lock( &objQueue->Lock);

	int i = 0;
	
	SI_CoreQueueRecord * qRecord = NULL;
	SI_CoreQueueRecord * qRecords[size];
	
	while(objQueue->Head && i < size)
	{
		if( objQueue->Head)
		{
			qRecord = objQueue->Head;
			
			if( qRecord)
			{
				dataItem[i]		= qRecord->Data;
				objQueue->Head 	= qRecord->Next;
				
				qRecords[i]		= qRecord;
				i++;
			}
			else
			{
				break;
			}
		}
	}
	
	pthread_mutex_unlock( &objQueue->Lock);
	
	if( i > 0)
	{
		__si_core_release_queue_record_bulk( qRecords, i);
	}
	
	return i;
}


int __si_core_queue_item_force( void * queuePoolObject, void * dataItem, int force)
{
	SI_CoreQueue * objQueue = (SI_CoreQueue * ) queuePoolObject;
	
	if( !objQueue)
	{	
		printf("[coding problem] invalid queue object %d|%s\n", __LINE__, __FUNCTION__);
		return -1;
	}
	
	int rStatus = 0;
	
	pthread_mutex_lock( &objQueue->Lock);
	
	if( (objQueue->CurrentQueueCount < objQueue->MaxQueueCount) || force == 1)
	{
		rStatus = 1;
		
		SI_CoreQueueRecord * qRecord = __si_core_allocate_queue_record();
		qRecord->Data = dataItem;
		
		if( !objQueue->Head) {
			objQueue->Head = objQueue->Current = qRecord;
		} else {
			objQueue->Current->Next = qRecord;
			objQueue->Current = qRecord;
		}
		objQueue->CurrentQueueCount++;
		objQueue->TotalQueued++;
	}
	
	pthread_mutex_unlock( &objQueue->Lock);
	
	sem_post( &objQueue->sem_lock);
	
	return rStatus;
}

void __si_core_print_buffer( uint8_t * buffer, int len)
{
	int i = 0;
	for( i = 0; i < len; i++)
	{
		printf( "%02X ", buffer[i] & 0xFF);
	}
	printf("\n");
}


int __si_core_queue_bulk_items( void * queuePoolObject, uint8_t ** dataItem, int count)
{
	return __si_core_queue_bulk_items_force( queuePoolObject, dataItem, 0, count);	
}


int __si_core_queue_item( void * queuePoolObject, void * dataItem)
{
	return __si_core_queue_item_force( queuePoolObject, dataItem, 0);
	/*
	SI_CoreQueue * objQueue = (SI_CoreQueue * ) queuePoolObject;
	
	int rStatus = 0;
	
	pthread_mutex_lock( &objQueue->Lock);
	
	if( objQueue->CurrentQueueCount < objQueue->MaxQueueCount)
	{
		rStatus = 1;
		
		SI_CoreQueueRecord * qRecord = __si_core_allocate_queue_record();
		qRecord->Data = dataItem;
		
		if( !objQueue->Head) {
			objQueue->Head = objQueue->Current = qRecord;
		} else {
			objQueue->Current->Next = qRecord;
			objQueue->Current = qRecord;
		}
		objQueue->CurrentQueueCount++;
	}
	
	pthread_mutex_unlock( &objQueue->Lock);
	
	sem_post( &objQueue->sem_lock);
	
	return rStatus;
	*/
}


void __si_core_create_fsmqueue( void ** fsmQueuePoolObject, void (*ptrCallBackHandler)(void*, int), int iNoOfThreads, int maxQueueItems)
{
	SI_CoreFSMQueue * fsmQueue = (SI_CoreFSMQueue *) __si_malloc( sizeof( SI_CoreFSMQueue));
	memset( fsmQueue, 0, sizeof( SI_CoreFSMQueue));	
	
	fsmQueue->ThreadCount = iNoOfThreads;
	fsmQueue->MaxQueueCount = maxQueueItems;
	//fsmQueue->CurrentQueueCount = 0;
	//fsmQueue->TotalQueued = 0;
	
	pthread_mutex_init( &fsmQueue->Lock, NULL);
	
	*fsmQueuePoolObject = fsmQueue;
	
	fsmQueue->coreQueue = (SI_CoreQueue **) __si_malloc( iNoOfThreads * sizeof(SI_CoreFSMQueue *));
	
	int i = 0;
	for( i = 0; i < iNoOfThreads; i++)
	{
		SI_CoreQueue * objQueue = (SI_CoreQueue *) __si_malloc( sizeof( SI_CoreQueue));
		memset( objQueue, 0, sizeof( SI_CoreQueue));
		
		objQueue->MaxQueueCount = maxQueueItems;
		objQueue->CurrentQueueCount = 0;
		objQueue->KeepAlive = 0;
		objQueue->TotalQueued = 0;
		objQueue->LastProcessed = 0;
		objQueue->TotalProcessed = 0;
		
		pthread_mutex_init( &objQueue->Lock, NULL);
		sem_init( &objQueue->sem_lock, 0, 0);
	
		fsmQueue->coreQueue[i] = objQueue;
		
		SI_CoreQueue_RoutingPointer * oRoutingPointer = (SI_CoreQueue_RoutingPointer *) __si_malloc(sizeof(SI_CoreQueue_RoutingPointer));
		oRoutingPointer->Routine2 = ptrCallBackHandler;
		oRoutingPointer->queueObject = objQueue;
		oRoutingPointer->iIndex = i;
		
		__si_create_pthread2( __si_core_queue_processing_thread, oRoutingPointer, "fsm_thread");
	}
	
}

int __si_core_queue_fsm2( void * fsmQueuePoolObject, uint32_t index, void * dataItem, void (*executor)(void *))
{
	SI_CoreFSMQueue * fsmQueue = (SI_CoreFSMQueue * ) fsmQueuePoolObject;

	if( !fsmQueue && !fsmQueue->coreQueue)
	{	
		printf("[coding problem] invalid queue object %d|%s\n", __LINE__, __FUNCTION__);
		return -1;
	}

	SI_CoreQueue * objQueue = fsmQueue->coreQueue[index];
	
	if(!objQueue) return -1;

	int rStatus = 0;
	
	pthread_mutex_lock( &objQueue->Lock);
	
	if( (objQueue->CurrentQueueCount < objQueue->MaxQueueCount) || 1 == 1)
	{
		rStatus = 1;
		
		SI_CoreQueueRecord * qRecord = __si_core_allocate_queue_record();
		qRecord->Data = dataItem;
		qRecord->executor = executor;
		
		if( !objQueue->Head) {
			objQueue->Head = objQueue->Current = qRecord;
		} else {
			objQueue->Current->Next = qRecord;
			objQueue->Current = qRecord;
		}
		objQueue->CurrentQueueCount++;
		objQueue->TotalQueued++;
	}
	
	pthread_mutex_unlock( &objQueue->Lock);
	
	sem_post( &objQueue->sem_lock);
	return rStatus;	
}

int __si_core_queue_fsm( void * fsmQueuePoolObject, uint32_t index, void * dataItem)
{
	return __si_core_queue_fsm2( fsmQueuePoolObject, index, dataItem, NULL);
}

/***********************************************/

void __si_core_wait()
{
	while(1)
	{
		usleep( 999999);
	}
}

void __si_core_wait_secs( int secs)
{
	int wi = 0;
	for( wi = 0; wi <= secs; wi++) {
		usleep( 999999);
	}
}


static uint8_t __init_sirik = 0;

time_t * __si_core__get_start_time()
{
	return &__siCore->startTime;
}

uint32_t __si_core__get_start_time_as_u32( uint32_t addseconds)
{
	time_t t2 = __siCore->startTime + 2208988800UL + addseconds;
	
	uint32_t t1 = 0;
	u_char * timestamp = (u_char *)&t1;
	
	timestamp[3] = (t2 >> 24) & 0xFF;
	timestamp[2] = (t2 >> 16) & 0xFF;
	timestamp[1] = (t2 >> 8) & 0xFF;
	timestamp[0] = (t2) & 0xFF;		
	
	return t1;
}

void __init_sirik_core()
{
	#if CORE_LIC
	int sts = __si_dateInRange( "01-07-2025", "31-12-2025");

	if( sts == 0)
	{
		printf( "sirik-core expired, please download latest version from https://github.com/vayuputra79/\n");
		exit(0);
	}
	#endif
		
	if( __init_sirik == 0)
	{
		__init_sirik = 1;
		
		//printf("starting core initialization %s-%d\n", __FUNCTION__, __LINE__);
		srand(time(0));
		
		pthread_mutex_init( &__si_MallocLock, NULL);
		
		__si_initial_malloc();
		
		//__siCore = (SI_Core *)__si_malloc( sizeof(SI_Core) );
		__si_malloc2( sizeof(SI_Core), (uint8_t **) &__siCore);
		memset( __siCore, 0, sizeof(SI_Core));

		__siCore->startTime = time( NULL);
		__siCore->EventHandlerCount = 0;
		__siCore->LocalTimeValue = 0;
		__siCore->UUID4SerialNumber = __si_core_getU64RAND();
		
		__siCore->StreamHead = NULL;
		__siCore->StreamCurrent = NULL;	
		__siCore->StreamPoolCount = 0;
		__siCore->StreamPoolAvailableCount = 0;
		pthread_mutex_init( &__siCore->StreamLock, NULL);	
		
		__siCore->EventHead = NULL;
		__siCore->EventCurrent = NULL;	
		__siCore->EventPoolCount = 0;
		__siCore->EventPoolAvailableCount = 0;		
		pthread_mutex_init( &__siCore->EventLock, NULL);
		
		__siCore->TaskHead = NULL;
		__siCore->TaskCurrent = NULL;	
		__siCore->TaskPoolCount = 0;
		__siCore->TaskPoolAvailableCount = 0;		
		pthread_mutex_init( &__siCore->TaskLock, NULL);		
		
		__siCore->QueueLineHead = __siCore->QueueHead = NULL;
		__siCore->QueueLineCurrent = __siCore->QueueCurrent = NULL;
		pthread_mutex_init( &__siCore->QueueLock, NULL);
		pthread_mutex_init( &__siCore->QueueLineLock, NULL);
		sem_init( &__siCore->queue_sem_lock, 0, 0);
		__siCore->TotalQueuePoolCount = 0;
		__siCore->AvailableQueuePoolCount = 0;
		__siCore->QueueLineCount = 0;
		__siCore->QueueLineThreadCount = 0;
		__siCore->QueueUsedTimes = 0;
		__siCore->QueueLineLastProcessedCount = 0;
		__siCore->QueueLineTotalProcessedCount = 0;
		__siCore->QueueLineLastQueuedCount = 0;
		__siCore->QueueLineTotalQueuedCount = 0;
		__siCore->QueueBacklog = 0;
		__siCore->QueueBacklogTotal = 0;
		__siCore->LastAvgQueueBacklog = 0;
		
		struct timezone tzone;	
		gettimeofday( &__siCore->QueueLineThreadIncreasedTime, &tzone);		
		
		__siCore->LinkedListPoolHead = __siCore->LinkedListPoolCurrent = NULL;
		pthread_mutex_init( &__siCore->LinkedListPoolLock, NULL);
		__siCore->TotalLinkedListPoolCount = 0;
		__siCore->AvailableLinkedListPoolCount = 0;
		
		__siCore->TimerHead = NULL;
		__siCore->TimerCurrent = NULL;
		pthread_mutex_init( &__siCore->TimerLock, NULL);
		__siCore->TotalTimerPoolCount = 0;
		__siCore->AvailableTimerPoolCount = 0;
		__siCore->UsedTimerPoolCount = 0;		
		
		__siCore->QueueRecordHead = NULL;
		__siCore->QueueRecordCurrent = NULL;
		pthread_mutex_init( &__siCore->QueueRecordLock, NULL);
		__siCore->QueueRecordCount = 0;
		__siCore->QueueRecordAvailableCount = 0;		
		
		__siCore->DataRecordHead = NULL;
		__siCore->DataRecordCurrent = NULL;
		pthread_mutex_init( &__siCore->DataRecordLock, NULL);
		__siCore->DataRecordAvailableCount = 0;
		__siCore->DataRecordCount = 0;
		
		
		
		//__si_log_cat_setName( SI_STK_LOG, LOG_CAT_CORE, "SI-CORE");
		__si_log_cat_setName( SI_STK_LOG, LOG_CAT_CORE, "CORE");
		__si_log_cat_setName( SI_STK_LOG, LOG_CAT_STREAM, "SI-STREAM");
		__si_log_cat_setName( SI_BUF_LOG1, LOG_CAT_BUFFER, "SI-BUFFER");
		
		__si_log_cat_enable_disable( SI_BUF_LOG1, LOG_CAT_BUFFER, 1);

		/*
		#if SI_SXENG
			__si_createStreamPool( 10000, 1);
		#else
			__si_createStreamPool( 500, 1);
		#endif	
		*/
		
		__si_createStreamPool( 500, 1);
		__si_createEventPool( 500, 1);
		__si_createTaskPool( 500, 1);
		__si_queue_create( 20000, 1);
		__si_timer_create( 1000, 1);
		
		int i;
		for( i = 0; i < MAX_TIMER_TICKS; i++)
		{
			__siCore->Timers[i].Head = __siCore->Timers[i].Current = NULL;
			pthread_mutex_init( &__siCore->Timers[i].Lock, NULL);
		}
		
		__siCore->SeverTimerTick = 1;
		__siCore->TimerTickIndex = 0;
		__si_create_pthread2( __si_timer_thread, NULL, "si_timer");
		__si_create_pthread2( __si_app_events_thread, NULL, "si_appevents");
		
		__siCore->AppEventInfoHead = NULL;
		__siCore->AppEventInfoCurrent = NULL;
		pthread_mutex_init( &__siCore->AppEventInfoLock, NULL);
	
		pthread_mutex_init( &__siCore->MemoryFreeLock, NULL);
		__si_initalize_MemoryPools();
		logMemoryReservedCount = 1;
		
		__siCore->ServiceRequestHead = NULL;
		__siCore->ServiceRequestCurrent = NULL;
		pthread_mutex_init( &__siCore->ServiceRequestLock, NULL);
		__siCore->ServiceRequestTotalPoolCount = 0;
		__siCore->ServiceRequestAvailablePoolCount = 0;
		
		__siCore->ActivityHead = NULL;
		__siCore->ActivityCurrent = NULL;
		pthread_mutex_init( &__siCore->ActivityLock, NULL);
		__siCore->ActivityTotalPoolCount = 0;
		__siCore->ActivityAvailablePoolCount = 0;
		
		__siCore->si_buffPool = NULL;
		
		printf("The system has %d processors configured and %d processors are available\n", get_nprocs_conf(), get_nprocs());
		
		//__si_checkexpiry();
	}
}

void * __si_bcd_to_buffer(const char *in, void *out, int *out_len)
{
    int i = 0;
    uint8_t *out_p = out;
    int in_len = strlen(in);

    for (i = 0; i < in_len; i++) {
        if (i & 0x01)
            out_p[i>>1] = out_p[i>>1] | (((in[i] - 0x30) << 4) & 0xF0);
        else
            out_p[i>>1] = (in[i] - 0x30) & 0x0F;
    }

    *out_len = (in_len + 1) / 2;
    if (in_len & 0x01) {
        out_p[(*out_len)-1] |= 0xF0;
    }

    return out;
}

void * __si_bcd_to_buffer_reverse_order(const char *in, void *out, int *out_len)
{
    int i = 0;
    uint8_t *out_p = out;
    int in_len = strlen(in);

    for (i = 0; i < in_len; i++) {
        if (i & 0x01)
            out_p[i>>1] = out_p[i>>1] | ((in[i] - 0x30) & 0x0F);
        else
            out_p[i>>1] = ((in[i] - 0x30) << 4) & 0xF0;
    }

    *out_len = (in_len + 1) / 2;
    if (in_len & 0x01) {
        out_p[(*out_len)-1] |= 0xF0;
    }

    return out;
}

void * __si_buffer_to_bcd(uint8_t *in, int in_len, void *out)
{
    int i = 0;
    uint8_t *out_p = out;

    for (i = 0; i < in_len-1; i++) {
        out_p[i*2] = 0x30 + (in[i] & 0x0F);
        out_p[i*2+1] = 0x30 + ((in[i] & 0xF0) >> 4);
    }

    if ((in[i] & 0xF0) == 0xF0) {
        out_p[i*2] = 0x30 + (in[i] & 0x0F);
        out_p[i*2+1] = 0;
    } else {
        out_p[i*2] = 0x30 + (in[i] & 0x0F);
        out_p[i*2+1] = 0x30 + ((in[i] & 0xF0) >> 4);
        out_p[i*2+2] = 0;
    }

    return out;
}

int __si_convertStrToBCD( char * inStr, int inLen, char * outStr, int * outLen)
{
	int i = 0;
	int j = 1;
	int tPos = 0;

	j = 0;
		
	for( i = 0; i < inLen; i++) {
		if( j == 0) {	
			outStr[tPos]  = inStr[i] & 0x0F;
		} else {	
			outStr[tPos] |= (inStr[i] << 4) & 0xF0;
		}
		
		j++;
		
		if( j == 2) {
			j = 0;
			tPos++;
		}
	}
	
	if( j > 0) 
	{
		outStr[tPos] |= 0xF0;
		tPos++;
	}	
	
	*outLen = tPos;
	return 0;
}

int __si_convertBCDToStr( char * inStr, int inLen, char * outStr, int * outLen)
{
	int i = 0;
	int j = 0;
	
	for( i = 0; i < inLen; i++)
	{
		if( (inStr[i] & 0x0F) > 9)
			break;
		
		outStr[j] = ((inStr[i] & 0x0F) + 48);
		j++;
		
		if( ((inStr[i] & 0xF0) >> 4) > 9)
			break;
		
		outStr[j] = (((inStr[i] & 0xF0) >> 4) + 48);
		j++;
	}
	
	*outLen = j;
	return 0;
}

int __si_convertBCDToBCDStr( char * inbcd, int inbcdlen, char * outbcdstr, int * outbcdstrlen)
{
	uint32_t ix = 0;
	uint32_t ix2 = 0;
	
	while( ix < inbcdlen)
	{
		sprintf( &outbcdstr[ix2], "%02X", inbcd[ix] & 0xFF);
		
		ix2 += 2;
		ix++;
	}
	
	return 0;
}

int __si_convertBCDStrToBCD( char * inbcdstr, int inbcdstrlen, char * outbcd, int * outbcdlen)
{
	uint32_t ix = 0;
	uint32_t ix2 = 0;
	char temp[3] = {0,0,0};
	
	while( ix < inbcdstrlen)
	{
		temp[0] = inbcdstr[ix];
		temp[1] = inbcdstr[ix + 1];
		
		outbcd[ix2] = strtol( temp, NULL, 16);
		
		ix2++;
		ix += 2;
	}
	*outbcdlen = ix2;
}

// Test Data = jionet.mnc872.mcc405.gprs
int __si_convertApnToGtpApn( char * inStr, int inLen, char * outStr, int * outLen)
{
	int i = 0;	//in string
	int j = 1;	//out string
	int sublen = 0;		//no of chars to be filled
	int noofchars = 0;
	
	for( i = 0; i < inLen; i++)
	{
		if( inStr[i] == '.')
		{
			// printf("\n");
			outStr[sublen] = noofchars;
			noofchars = 0;
			sublen = j;
		}
		else
		{
			// printf("%c", inStr[i] & 0xFF);
			outStr[j] = inStr[i];
			noofchars++;
		}
		j++;
	}
	
	if( noofchars > 0)
	{
		outStr[sublen] = noofchars;
	}
	
	//printf("\n");
	*outLen = j;
	
	return 0;
}

int __si_convertGtpApnToApn( char * inStr, int inLen, char * outStr, int * outLen)
{
	if( inLen > 0)
	{
		uint8_t sublen = inStr[0];
		int i = 1;
		int j = 0;
		int pos = 0;
		
		while( i < inLen)
		{
			//printf("%d %d sublen=%d \n", i, inLen, sublen);
			
			for( j = 0; j < sublen; j++)
			{
				//printf("%c", inStr[i]);
				outStr[pos] = inStr[i];
				pos++;
				i++;
			}
			
			if( i < inLen)
			{
				sublen = inStr[i];
				outStr[pos] = '.';
				pos++;
			}
			
			//printf("\n");
			i++;
		}
		
		//printf("\n");
		*outLen = pos;
	}
	return 0;
}



int __si_convertStringToBCD2( char * inStr, int inLen, char * outStr, int * outLen)
{
	int i = 0;
	int j = 0;
	int tPos = 0;	
	
	for( i = 0; i < inLen; i++)
	{
		if( j == 0)
		{	
			outStr[tPos] = (inStr[i] & 0xF0);
		}
		else 
		{
			outStr[tPos] |= (inStr[i] << 4 & 0x0F);
		}
		
		j++;
		if( j == 2)
		{
			j = 0;
			tPos++;
		}
	}
	
	if( j > 0)
	{	
		outStr[tPos] |= 0xF0;
		tPos++;
	}
	
	return 0;
}

int __si_convertLongToBCD2( uint64_t emergencyNumber, char * outStr, int * outLen)
{
	char sNumber[20] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	int count = sprintf( sNumber, "%lu", emergencyNumber);
	
	//return __si_convertStringToBCD2( sNumber, count, outStr, outLen);
	//printf("count=%d\n", count);
	return __si_convertStrToBCD( sNumber, count, outStr, outLen);
}

int __si_convertStringToBCD( char * inStr, int inLen, char * outStr, int * outLen, uint8_t OddEvenIndication)
{
	int i = 0;
	int j = 1;
	int tPos = 0;
	
	if( OddEvenIndication == 1)
	{
		for( i = 0; i < inLen; i++)
		{
			if( j == 1)
			{	
				outStr[tPos] |= inStr[i] << 4;
			}
			else 
			{
				outStr[tPos] = inStr[i] & 0x0F;
			}
			
			j++;
			if( j == 2)
			{
				j = 0;
				tPos++;
			}
		}
		
		if( j > 0)
		{	
			outStr[tPos] |= 0xF0;
			tPos++;
		}
	}
	else
	{
		j = 0;
		
		for( i = 0; i < inLen; i++)
		{
			if( j == 0)
			{	
				outStr[tPos]  = inStr[i] << 4;
			}
			else
			{	
				outStr[tPos] |= inStr[i] & 0x0F;
			}
			
			j++;
			
			if( j == 2)
			{
				j = 0;
				tPos++;
			}
		}
		
		if( j > 0)
		{	
			outStr[tPos] |= 0x0F;
			tPos++;
		}	
	}
	
	*outLen = tPos;
	
	return 0;
}

int __si_convertLongToBCD( uint64_t emergencyNumber, char * outStr, int * outLen, uint8_t OddEvenIndication)
{
	char sNumber[20] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	int count = sprintf( sNumber, "%lu", emergencyNumber);
	
	return __si_convertStringToBCD( sNumber, count, outStr, outLen, OddEvenIndication);
}

uint32_t __si_core_convert_ipv4toint( char * ipaddress)
{
	return inet_addr( ipaddress);
}

char * __si_core_convert_inttoipv4( uint32_t ipv4)
{
    struct in_addr ip_addr;
    ip_addr.s_addr = ipv4;
	return inet_ntoa( ip_addr);
}

void __si_core_convert_inttoipv4_2( uint32_t ipv4, char * ip)
{
	sprintf( ip, "%u.%u.%u.%u", (ipv4) & 0xFF, (ipv4 >> 8) & 0xFF, (ipv4 >> 16) & 0xFF, (ipv4 >> 24) & 0xFF);
}

int __si_conver_hex_to_hexstr( char * hexstrout, char * hexin, int inlen)
{
	int i = 0, j = 0;
	while( i < inlen)
	{
		sprintf( &hexstrout[j], "%02X", hexin[i] & 0xFF);
		
		j += 2;
		i++;
	}
}

int __si_conver_str_to_hex( char * hexout, char * hexstrin)
{
	int i = 0;
	int j = 0;
	int z = 0;
	char temp[2] = {0,0};
	
	for( i = 0; i < strlen(hexstrin); i++)
	{
		if( j == 0)
		{
			temp[0] = hexstrin[i];
			j++;
		}
		else if( j == 1)
		{
			temp[j] = hexstrin[i];
			hexout[z] = strtol( temp, NULL, 16);
			//printf( "temp=%s %02X\n", temp, strtol( temp, NULL, 16));
			j = 0;
			z++;
		}
	}
	
	if( j > 0)
	{
		temp[1] = '\0';
		//printf( "2 temp=%s %02X\n", temp, strtol( temp, NULL, 16));
		hexout[z] = strtol( temp, NULL, 16);
		z++;
	} 
	return z;
}

uint8_t __si_uint8_to_hex( uint8_t u8)
{
	uint8_t quotient = u8;
	uint8_t reminder = 0;
	uint8_t result = 0;
	
	while( quotient != 0)
	{
		reminder = quotient % 16;
		
		if( reminder < 10)
			result = 48 + reminder;
		else
			result = 55 + reminder;
		
		quotient = quotient / 16;
	}
	return result;
}

uint8_t __si_uint8_to_hex2( uint8_t u8)
{
	char day[2];
	sprintf( day, "%u", u8);
	
	char xday[1];
	__si_hexString_to_hexArray( day, 2, xday);

	return xday[0] & 0xFF;
}

uint8_t __si_uint8_to_hex2_with_swap( uint8_t u8)
{
	uint8_t u81 = __si_uint8_to_hex2( u8);
	return __si_nibble_swap( u81);
}

uint8_t __si_nibble_swap( unsigned char u8)
{
	return ((u8 & 0x0F) << 4 | (u8 & 0xF0) >> 4);
}

uint8_t __si_nibble_swapu8( uint8_t u8)
{
	return ((u8 & 0x0F) << 4 | (u8 & 0xF0) >> 4);
}


uint8_t __si_nibble_high( unsigned char u8)
{
	return ((u8 & 0x0F) << 4);
}

uint8_t __si_nibble_low( unsigned char u8)
{
	return ((u8 & 0xF0) >> 4);
}

uint16_t __si_get_u16( unsigned char * buff)
{
	return (uint16_t) (( buff[0] << 8) & 0xFF00) + (buff[1] & 0x00FF);
}

uint32_t __si_get_u24( unsigned char * buff)
{
	return (uint32_t) ((buff[0] << 16) & 0x00FF0000) + (( buff[1] << 8) & 0x0000FF00) + (buff[2] & 0x000000FF);
}

uint32_t __si_get_u32( unsigned char * buff)
{
	return (uint32_t) (( buff[0] << 24) & 0xFF000000) + ((buff[1] << 16) & 0x00FF0000) + ((buff[2] << 8) & 0x0000FF00) + (buff[3] & 0x000000FF);
}

uint64_t __si_get_u40( unsigned char * buff)
{
	return ((((uint64_t)buff[0] << 32) & 0x000000FF00000000U) + ((buff[1] << 24) & 0x00000000FF000000U) + ((buff[2] << 16) & 0x0000000000FF0000U) + ((buff[3] << 8) & 0x000000000000FF00U) + (buff[4] & 0x00000000000000FFU));
}

uint64_t __si_get_u48( unsigned char * buff)
{
	return ( (((uint64_t)buff[0] << 40) & 0x0000FF0000000000U) + (((uint64_t)buff[1] << 32) & 0x000000FF00000000U) + ((buff[2] << 24) & 0x00000000FF000000U) + ((buff[3] << 16) & 0x0000000000FF0000U) + ((buff[4] << 8) & 0x000000000000FF00U) + (buff[5] & 0x00000000000000FFU));
}

uint64_t __si_get_u64( unsigned char * buff)
{
	return (
	(((uint64_t)buff[0] << 56) & 0xFF00000000000000U) + (((uint64_t)buff[1] << 48) & 0x00FF000000000000U) + (((uint64_t)buff[2] << 40) & 0x0000FF0000000000U) +
	(((uint64_t)buff[3] << 32) & 0x000000FF00000000U) + ((buff[4] << 24) & 0x00000000FF000000U) + ((buff[5] << 16) & 0x0000000000FF0000U) + ((buff[6] << 8) & 0x000000000000FF00U) 
	+ (buff[7] & 0x00000000000000FFU));
}

uint8_t __si_buffer_get_u8( SI_Buffer * siBuffer)
{
	uint8_t u8 = 0;
	if( (siBuffer->pos + 1) <= siBuffer->len)
	{
		u8 = (uint8_t) siBuffer->buffer[siBuffer->pos];
		siBuffer->pos++;
	}
	else
	{
		siBuffer->Error = SI_MAX_BUFFER_ERROR_INSUFFICENT;
	}
	return u8;
}

uint16_t __si_buffer_get_u16( SI_Buffer * siBuffer)
{
	uint16_t u16 = 0;
	
	if( (siBuffer->pos + 2) <= siBuffer->len)
	{
		u16 = (uint16_t) (( siBuffer->buffer[siBuffer->pos + 0] << 8) & 0xFF00) + (siBuffer->buffer[siBuffer->pos + 1] & 0x00FF);
		siBuffer->pos += 2;
	}
	else
	{
		siBuffer->Error = SI_MAX_BUFFER_ERROR_INSUFFICENT;
	}
	return u16;
}

uint32_t __si_buffer_get_u24( SI_Buffer * siBuffer)
{
	uint32_t uVal = 0;
	
	if( (siBuffer->pos + 3) < siBuffer->len)
	{
		uVal = (uint32_t) ((siBuffer->buffer[siBuffer->pos] << 16) & 0x00FF0000) + (( siBuffer->buffer[siBuffer->pos + 1] << 8) & 0x0000FF00) + (siBuffer->buffer[siBuffer->pos + 2] & 0x000000FF);
		siBuffer->pos += 3;
	}
	else
	{
		siBuffer->Error = SI_MAX_BUFFER_ERROR_INSUFFICENT;
	}
	return uVal;
}

uint32_t __si_buffer_get_u32( SI_Buffer * siBuffer)
{
	uint32_t uVal = 0;
	
	if( (siBuffer->pos + 3) < siBuffer->len)
	{
		uVal = (uint32_t) (( siBuffer->buffer[ siBuffer->pos ] << 24) & 0xFF000000) + (( siBuffer->buffer[siBuffer->pos + 1] << 16) & 0x00FF0000) + (( siBuffer->buffer[siBuffer->pos + 2] << 8) & 0x0000FF00) + (siBuffer->buffer[siBuffer->pos + 3] & 0x000000FF);
		siBuffer->pos += 4;
	}
	else
	{
		siBuffer->Error = SI_MAX_BUFFER_ERROR_INSUFFICENT;
	}
	return uVal;
}


int __si_lastIndexOf( u_char * data, uint16_t datalen, uint8_t cchar)
{
	if( data)
	{
		int i = 0;
		while( i < datalen)
		{
			i++;
			if( data[ datalen - i] == cchar)
			{
				return (datalen - i);
			}
		}			
	}
	return -1;
}

int __si_indexOf( u_char * data, uint16_t datalen, uint8_t cchar)
{
	if( data)
	{
		int i = 0;
		for( i = 0; i < datalen; i++)
		{
			if( data[i] == cchar)
				return i;
		}			
	}
	return -1;
}

int __si_indexOf2( u_char * data, uint16_t datalen, u_char * str)
{
	if( data)
	{
		int i = 0;
		for( i = 0; i < (datalen-1); i++)
		{
			if( data[i] == str[0] && data[ i + 1] == str[1])
			{
				return i;
			}	
		}
	}
	return -1;	
}

int __si_find_string( u_char * data, int datalen, u_char * find, int findlen)
{
	int z = 0, j = 0;
	
	while( j < findlen)
	{
		//if(!data[z])
		//	return -1;
		
		if( data[z] != find[j])
		{	
			//printf( "%c != %c\n", data[z], find[j]);
			return -1;
		}
		z++;
		j++;
	}
	
	//printf( "xx j=%d findlen=%d \n", j, findlen);
	
	if( j == (findlen))
		return 1;
	
	return -1;
}

int __si_indexOf3( u_char * data, int datalen, u_char * find, int findlen)
{
	//if(!data) return -1;
	//if(!find) return -1;
	
	if( datalen > findlen)
	{
		int i = 0, index = 0;
		
		for( i = 0; i < (datalen); i++)
		{
			//if(!data[i]) return -1;
			
			index = __si_find_string( &data[i], (datalen - i), find, findlen);
			
			//printf( "index=%d datalen=%d i=%d (datalen-i)=%d findlen=%d data=%s\n", index, datalen, i, (datalen - i), findlen, &data[i]);
			
			if( index >= 0)
				return i;
		}
	}		
	return -1;
}

void __si_str_replace( char * search , char * replace , char * subject)
{
	/*
	char * p = strstr( subject , search);
	
	if( p)
	{	
		int len = strlen( search) + strlen(replace) + 10
		char nstr[ len];
		memset( nstr, 0, sizeof(nstr));

		printf( "p=%s [%ld]\n", p, p-subject);
		
		int i = 0,j = strlen(subject);
		
		
	}
	*/
	
	
	/*
	char  *p = NULL , *old = NULL;
	int c = 0 , search_size;
	
	search_size = strlen( search);
	
	for(p = strstr(subject , search) ; p != NULL ; p = strstr(p + search_size , search))
	{
		c++;
	}
	
	//Final size
	c = ( strlen(replace) - search_size )*c + strlen(subject);

	char new_subject[c + 1]; 
	memset( new_subject, 0, c+1);
	
	old = subject;
	*/
	
}

int __si_indexOf4( u_char * data, u_char * find)
{
	return __si_indexOf3( data, strlen( data), find, strlen( find));
}

//SI_LinkedList * __si_string_split( u_char * data, int len, char cspliter)
SI_LinkedList * __si_string_split( u_char * data, int len, char * cspliter)
{
	SI_LinkedList * ll = __si_linked_list_allocate();
	
	int ind = 0;
	int spos = 0;
	
	char * dataItem = NULL;
	__si_stringv_t * str = NULL;
	
	int splitter_len = strlen( cspliter);
	
	while(1)
	{	
		//ind = __si_indexOf( &data[spos], (len-spos), cspliter);
		ind = __si_indexOf3( &data[spos], (len-spos), cspliter, splitter_len);
		
		//printf("[ind=%d]\n", ind);
		
		// printf("-------\n");
		// printf("--splitter[%s]-----\n", cspliter);
		// printf("-------\n");
		// printf( "ind=%d splitter_len=%d data=%s \n\n", ind, splitter_len, &data[spos]);
		// printf("-------\n");
		
		if( ind < 0)
		{	
			if( spos < (len - splitter_len))
			{
				ind = ((len-spos));
				dataItem  = (char *) __si_allocM7( ind + 1, __FILE__, __LINE__, 0);
				memcpy( dataItem, &data[spos], ind);
				dataItem[ind] = '\0';
				
				str = (__si_stringv_t *) __si_allocM7( sizeof(__si_stringv_t) + 1, __FILE__, __LINE__, 0);
				str->val = dataItem;
				str->len = ind;
				__si_linked_list_add( ll, (uint8_t *) str);
				
				//printf( " -1- dataItem=%s-\n", dataItem);
				
				//printf("1 LINE=%d FILE=%s  ind=%d len=%d spos=%d splitter_len=%d\n", __LINE__, __FILE__, ind, len, spos, splitter_len);
				
				/*
				
				__si_print_buffer( dataItem, ind);
				__si_print_string( dataItem, ind);
				printf("1\n");
				*/
				
				
				// printf("chunk-1 <<[[\n");
				// __si_print_string( dataItem, ind);
				// __si_print_buffer( dataItem, ind);
				// printf("]]>>\n");
				/**/
			}
			
			break;
		}
		
		if( ind > 0)
		{	
			dataItem  = (char *) __si_allocM7( ind + 1, __FILE__, __LINE__, 0);
			memcpy( dataItem, &data[spos], ind);
			dataItem[ind] = '\0';
			
			str = (__si_stringv_t *) __si_allocM7( sizeof(__si_stringv_t) + 1, __FILE__, __LINE__, 0);
			str->val = dataItem;
			str->len = ind;
				
			__si_linked_list_add( ll, (uint8_t *)str);
			
			//printf( " -2- dataItem=%s-\n", dataItem);
			
			
			// printf("2 LINE=%d FILE=%s  ind=%d len=%d spos=%d  splitter_len=%d\n", __LINE__, __FILE__, ind, len, spos, splitter_len);
			
			
			// printf("chunk-2 <<[[\n");
			// __si_print_string( dataItem, ind);
			// __si_print_buffer( dataItem, ind);
			// printf("]]>>\n");
			/**/
		}
		
		spos += (ind + splitter_len);
	}
	
	//printf( "ll-count >= %d %s|%d\n",  __si_linked_list_count( ll), __FILE__, __LINE__);
	return ll;	
}

SI_LinkedList * __si_getlines_n( u_char * data, int len)
{
	return __si_string_split( data, len, "\n");
}

SI_LinkedList * __si_getlines_rn( u_char * data, int len)
{
	SI_LinkedList * ll = __si_linked_list_allocate();
	
	int ind = 0;
	int spos = 0;
	
	char * dataItem = NULL;
	
	while(1)
	{	
		ind = __si_indexOf2( &data[spos], (len-spos), "\r\n");	
		
		if( ind < 0)
		{
			if( spos < (len-2))
			{
				ind = ((len-spos));
				dataItem  = (char *) __si_allocM7( ind + 1, __FILE__, __LINE__, 0);
				memcpy( dataItem, &data[spos], ind);
				dataItem[ind] = '\0';
				__si_linked_list_add( ll, (uint8_t *)dataItem);
			}			
			break;
		}
		
		if( ind > 0)
		{	
			dataItem  = (char *) __si_allocM7( ind + 1, __FILE__, __LINE__, 0);
			memcpy( dataItem, &data[spos], ind);
			dataItem[ind] = '\0';
			__si_linked_list_add( ll, (uint8_t *)dataItem);
		}
		
		spos += (ind + 2);	// 2 is for \r\n
	}
	
	return ll;
}

SI_LinkedList * __si_string_double_split( u_char * data, int len, char * sp1it_1, char * split_2)
{
	if( sp1it_1)
	{	
		SI_LinkedList * step1_ll = __si_string_split( data, len, sp1it_1);
		
		if( split_2)
		{
			SI_LinkedList * rootList = __si_linked_list_allocate();
			
			int i = 0, j = 0, icount = 0, jcount = 0;
			icount = __si_linked_list_count( step1_ll);
			
			char * dataItem = NULL, * dataItem2 = NULL;
			SI_LinkedList * step2_ll = NULL;
			
			for( i = 0; i < icount; i++)
			{
				dataItem = ( char *) __si_linked_list_get_item( step1_ll, i);
				
				step2_ll = __si_string_split( dataItem, strlen(dataItem), split_2);
				
				if( step2_ll)
				{	
					jcount = __si_linked_list_count( step2_ll);
					
					for( j = 0; j < jcount; j++)
					{
						dataItem2 = ( char *) __si_linked_list_get_item( step2_ll, j);
						__si_linked_list_add( rootList, (uint8_t *) dataItem2);
					}
					
					//items in ll are stored in another array, so no need to free items
					__si_linked_list_removeAll( step2_ll);
				}
			}
			
			return rootList;
		}
		
		return step1_ll;
	}
	
	return NULL;
}

void __si_substr( u_char * data, u_char * outdata, int bPos, int ePos)
{
	memcpy( outdata, &data[bPos], (ePos - bPos));
}

int __si_file__get_extension( u_char * filename, u_char * ext, int * extLen)
{
	if(!filename) return -1;
	
	int len = strlen( filename);
	if( len == 0 ) return -2;	
	
	int ind = __si_lastIndexOf( filename, len, '.');
	
	if( ind > 0 && (len-(ind+1)) < 10)
	{
		__si_substr( filename, ext, ind+1, len);
		*extLen = (len-(ind+1));
	}
	return -3;
}

char * __si_get_keypair_val( u_char * data, u_char * key)
{
	int ix = __si_indexOf4( data, key);
	
	if( ix >= 0)
	{	
		return &data[ix + strlen(key)];
	}
	
	return NULL;
}



SI_KeyValPair * __si_get_KeyValPair( u_char * data, int len, char * splitter)
{
	if( strlen( data) > 0)
	{
		int ix = __si_indexOf3( data, len, splitter, strlen(splitter));
		
		if( ix > 0 && ix < len)
		{
			SI_KeyValPair * kvPair = (SI_KeyValPair *) __si_allocM7( sizeof( SI_KeyValPair), __FILE__, __LINE__, 0);
			
			kvPair->keylen 		= ix;
			kvPair->key 		= (char *) __si_allocM7( kvPair->keylen + 1, __FILE__, __LINE__, 0);
			memcpy( kvPair->key, data, ix);
			kvPair->key[ kvPair->keylen] = '\0';
			
			kvPair->vallen 		= (len-ix);
			kvPair->val 		= (char *) __si_allocM7( kvPair->vallen + 1, __FILE__, __LINE__, 0);	
			memcpy( kvPair->val, &data[ix+1], (len-(ix+1)));
			kvPair->key[ kvPair->vallen] = '\0';			
			
			//printf( "-->  ix=%d len=%d  [key=%s] [val=%s] \n", ix, len, kvPair->key, kvPair->val);
			//__si_print_string( data, len);
			return kvPair;
		}
		
	}
	return NULL;
}

void __si_fill_KeyValPair( u_char * data, int len, char * splitter, char * key, char * val)
{
	if( strlen( data) > 0)
	{
		int ix = __si_indexOf3( data, len, splitter, strlen(splitter));
		
		if( ix > 0 && ix < len)
		{
			//memcpy( key, data, ix);
			__si_ltrim_copy( data, key,  ix );
			//memcpy( val, &data[ix + 1], (len-(ix+1)));
			__si_ltrim_copy( &data[ix + 1], val,  (len-(ix+1))  );
		}
	}
}

uint8_t __si_char2hex( char c)
{
	if( '0' <= c && c <= '9') return c - '0';
	if( 'a' <= c && c <= 'f') return 10 + c - 'a';
	if( 'A' <= c && c <= 'F') return 10 + c - 'A';
	
	return 0;
}

u_char __si_hex2char( uint8_t hex )
{
	switch(hex)
	{
		case 0:
			return '0';
		case 1:
			return '1';
		case 2:
			return '2';
		case 3:
			return '3';
		case 4:
			return '4';
		case 5:
			return '5';
		case 6:
			return '6';
		case 7:
			return '7';
		case 8:
			return '8';
		case 9:
			return '9';
		case 10:
			return 'A';
		case 11:
			return 'B';
		case 12:
			return 'C';
		case 13:
			return 'D';
		case 14:
			return 'E';
		case 15:
			return 'F';
		default:
			return '0';
	}
}

void __si_hexArray_to_hexString( u_char * uIn, int len, u_char * uOut)
{
	int j = 0, i = 0;
	for( i = 0; i < len; i++)
	{
		uOut[j] = __si_hex2char(( uIn[i] >> 4) & 0x0F);
		j++;

		uOut[j] = __si_hex2char(uIn[i] & 0x0F);
		j++;		
	}
}

void __si_hexString_to_hexArray( u_char * uIn, int len, u_char * uOut)
{
	int f = 0, i = 0;
	for( i = 0; i < (len/2); i++)
	{
		uOut[i]  = (__si_char2hex(uIn[f]) << 4) & 0xF0;
		f++;
		
		uOut[i] |= __si_char2hex(uIn[f]) & 0x0F;
		f++;
	}
}

char * __si_ltrim( char * data)
{
	int j = 0, len = strlen( data);
	
	while( j < len)
	{
		if( data[j] == ' ' || data[j] == '\t' || data[j] == '\r' || data[j] == '\n')
			j++;
		else
			break;
	}
	
	return &data[j];
}

char * __si_ltrim_copy( char * data, char * dst, int len)
{
	int j = 0;
	
	while( j < len)
	{
		if( data[j] == ' ' || data[j] == '\t' || data[j] == '\r' || data[j] == '\n')
			j++;
		else
			break;
	}
	
	memcpy( dst, &data[j], len-j);
}

int __si_nanosleep( long tv_nsec /* 0 to 999999999*/ )
{
	struct timespec ts;
	ts.tv_sec = 0;
	ts.tv_nsec = tv_nsec;
	return nanosleep( &ts, NULL);
}

int __si_file__init( char * path, SI_FileInfo * fileInfo)
{
	fileInfo->file = NULL;
	fileInfo->pos = 0;
	fileInfo->st_status = 0;
	
	fileInfo->st_status = stat( path, &fileInfo->st);
	
	if( fileInfo->st_status == 0)
	{
		fileInfo->file = fopen( path, "r");
	}
	
	return fileInfo->st_status;
}

void __si_file__close( SI_FileInfo * fileInfo)
{
	if( fileInfo->file)
	{
		fclose( fileInfo->file);
	}
}

int __si_file__hasdata( SI_FileInfo * fileInfo)
{
	if( fileInfo->st_status != 0) return -1;
	if( !fileInfo->file) return -2;

	return (fileInfo->st.st_size - fileInfo->pos);
}


int __si_file__readfile( char * fileName, u_char * buff)
{
	FILE * file = fopen( fileName, "r");
	
	if( file)
	{
		struct stat st;
		int st_status = stat( fileName, &st);	
		
		if( st_status == 0)
		{
			int i = 0;
			while( i < st.st_size)
			{
				buff[i] = getc( file);
				i++;
			}
			fclose( file);
			return i;
		}
	}
	
	return 0;
}

int __si_file__readdata( char * fileName, int pos, u_char * buff, int readSize)
{
	struct stat st;
	int st_status = stat( fileName, &st);
	
	if( st_status == 0 && st.st_size >= ( pos + readSize))
	{
		FILE * file = fopen( fileName, "r");
		
		if( file)
		{
			fseek( file, pos, SEEK_SET);
			
			int i = 0;
			while( i < readSize)
			{
				buff[i] = getc( file);
				i++;
			}
			
			fclose( file);
			return i;
		}
	}
	
	return 0;
}

int __si_file__read( SI_FileInfo * fileInfo, u_char * buff, int readSize, int * pending)
{
	if( fileInfo->st_status != 0) return -1;
	if( !fileInfo->file) return -2;
	
	int bytestoread = 0;
	
	int availableBytes = fileInfo->st.st_size - fileInfo->pos;
	
	if( availableBytes > readSize)
		bytestoread = readSize;
	else
		bytestoread = availableBytes;
	
	int i = 0;
	while( i < bytestoread)
	{
		buff[i] = getc( fileInfo->file);
		i++;
	}
	buff[i] = 0;	//buffer size should be readSize+1
	
	fileInfo->pos += i;
	*pending = fileInfo->st.st_size - fileInfo->pos;
	
	return bytestoread;
}

int __si_file__createf( char * cFileName, uint8_t deleteExisting)
{
	if( deleteExisting == 1) {
		remove( cFileName);
	}
	
	int iUmask 				= S_IWGRP | S_IWOTH;
	int iFileCreationMode 	= S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
	int iFlags 				= O_CREAT | O_APPEND | O_WRONLY;

	int iOldUmask 			= umask( iUmask);
	int iHandle 			= open( cFileName, iFlags, iFileCreationMode);
	umask( iOldUmask);
	
	return iHandle;
}

void __si_file__write( int fhd, char * contents)
{
	write( fhd, contents, strlen(contents));
}

void __si_file__writef( int fhd, char * contents, int len)
{
	write( fhd, contents, len);	
}

void __si_file__writeln( int fhd, char * contents, ...)
{
	char m_buffer[1000];
	memset( m_buffer, 0, sizeof m_buffer);

    va_list args;// = 0;
    va_start( args, contents);
    vsnprintf( m_buffer, 1000, contents, args);
	va_end( args);
	
	int slen = strlen(m_buffer);
	m_buffer[slen] = '\n';
	
	__si_file__writef( fhd, m_buffer, slen + 1);
}





void __si_file__closef( int fhd)
{
	close( fhd);
}

int __si_file__writeallf( char * cFileName, uint8_t deleteExisting, char * contents, int len)
{
	int fhd = __si_file__createf( cFileName, deleteExisting);
	__si_file__writef( fhd, contents, len);
	__si_file__closef( fhd);
}

void ngtff__u32id_to_charid( uint32_t uid, char * cid)
{
	memcpy( (char *)cid, (char *)&uid, 4);
}

void ngtff__charid_to_u32id( char * cid, uint32_t * uid)
{
	memcpy( (char *)uid, (char *)cid, strlen(cid));	
}

//#pragma pack(4)
typedef struct ngtff_index_table_row
{
	struct ngtff_index_table_row * Next;
	
	uint32_t Id;
	uint8_t * bPtr;
	
} ngtff_index_table_row_t;

//#pragma pack(4)
typedef struct ngtff_index_table
{
	ngtff_index_table_row_t * freeHead;
	ngtff_index_table_row_t * freeCurrent;
	pthread_mutex_t freeLock;
	uint32_t freeCount;
	
	uint32_t Count;
	ngtff_index_table_row_t ** table;
} ngtff_index_table_t;

void ngtff_itable__get_counts( uint8_t * itable, uint32_t * freeCount, uint32_t * totalCount)
{
	ngtff_index_table_t * table = (ngtff_index_table_t *) itable;
	*freeCount = table->freeCount;
	*totalCount = table->Count;
}

uint8_t * ngtff_itable__create( uint32_t count, uint32_t ssize)
{
	//ngtff_index_table_t * table = (ngtff_index_table_t *)malloc( sizeof(ngtff_index_table_t));
	ngtff_index_table_t * table = NULL;
	__si_malloc2( sizeof(ngtff_index_table_t), (uint8_t **)&table);

	
	memset( table, 0, sizeof( ngtff_index_table_t));
	
	table->freeHead = table->freeCurrent = NULL;
	pthread_mutex_init( &table->freeLock, NULL);
	
	//table->table = calloc( count, sizeof(ngtff_index_table_row_t *));
	//table->table = malloc( count * sizeof(ngtff_index_table_row_t *));
	table->table = (ngtff_index_table_row_t **)__si_malloc_block( count * sizeof(ngtff_index_table_row_t *), __FILE__, __LINE__);
	if(!table->table) return NULL;
	
	//uint8_t * buf = calloc( count, (sizeof(ngtff_index_table_row_t) + ssize));
	//uint8_t * buf = malloc( count * (sizeof(ngtff_index_table_row_t) + ssize));
	uint8_t * buf = __si_malloc_block( ( count * (sizeof(ngtff_index_table_row_t) + ssize)), __FILE__, __LINE__);
	if(!buf) return NULL;
	
	ngtff_index_table_row_t * row = NULL;
	
	int i = 0, j = 0;
	for( i = 0; i < count; i++)
	{
		row = (ngtff_index_table_row_t *)&buf[j];
		
		memset( row, 0, (sizeof(ngtff_index_table_row_t) + ssize));
		row->Id = (i + 1);
		
		table->table[i] = row;
		
		j += sizeof(ngtff_index_table_row_t);
		
		row->bPtr = (uint8_t *) &buf[j];
		
		if(!table->freeHead) 
		{
			table->freeHead = table->freeCurrent = row;
		} 
		else 
		{
			table->freeCurrent->Next = row;
			table->freeCurrent = row;
		}
		table->freeCount++;
		j += ssize;
	}
	
	table->Count = count;
	
	return (uint8_t *)table;
}

uint8_t * ngtff_itable__getfree_item( uint8_t * itable)
{
	ngtff_index_table_t * table = (ngtff_index_table_t *) itable;
	
	ngtff_index_table_row_t * rowItem = NULL;
	pthread_mutex_lock( &table->freeLock);
	
	rowItem = table->freeHead;

	if( rowItem)
	{
		table->freeHead = rowItem->Next;
		rowItem->Next = NULL;
		table->freeCount--;
	}
	
	pthread_mutex_unlock( &table->freeLock);
	return (uint8_t *) rowItem;
}

uint8_t * ngtff_itable__getitem_byid( uint8_t * itable, uint32_t id)
{
	ngtff_index_table_t * table = (ngtff_index_table_t *) itable;
	
	if( id > 0 && id < (table->Count + 1))
	{
		return (uint8_t *)table->table[id-1];
	}
	return NULL;
}

void ngtff_itable__putitem( uint8_t * itable, uint8_t * row)
{
	ngtff_index_table_t * table = (ngtff_index_table_t *) itable;
	ngtff_index_table_row_t * rowItem = (ngtff_index_table_row_t *) row;
	
	pthread_mutex_lock( &table->freeLock);
	
	if(!table->freeHead)
	{
		table->freeHead = table->freeCurrent = rowItem;
	}
	else
	{
		table->freeCurrent->Next = rowItem;
		table->freeCurrent = rowItem;
	}

	table->freeCount++;	
	pthread_mutex_unlock( &table->freeLock);
}

uint32_t ngtff_itable__getitem_id( uint8_t * row)
{
	ngtff_index_table_row_t * rowItem = (ngtff_index_table_row_t *) row;
	return rowItem->Id;
}

uint8_t * ngtff_itable__getitem_bufferpointer( uint8_t * row)
{
	ngtff_index_table_row_t * rowItem = (ngtff_index_table_row_t *) row;
	return rowItem->bPtr;
}

int __si_string5_set( __si_string5_t * ptr_string, u_char * val, uint16_t len)
{
	if( len <= 5)
	{	
		memcpy( ptr_string->val, val, len);
		ptr_string->isset = 1;
		ptr_string->len = len;
		ptr_string->val[len] = 0;
		
		return 1;
	}
	return -1;	
}

int __si_string10_set( __si_string10_t * ptr_string, u_char * val, uint16_t len)
{
	if( len <= 10)
	{	
		memcpy( ptr_string->val, val, len);
		ptr_string->isset = 1;
		ptr_string->len = len;
		ptr_string->val[len] = 0;
		
		return 1;
	}
	return -1;	
}

int __si_string20_set( __si_string20_t * ptr_string, u_char * val, uint16_t len)
{
	if( len <= 20)
	{	
		memcpy( ptr_string->val, val, len);
		ptr_string->isset = 1;
		ptr_string->len = len;
		ptr_string->val[len] = 0;
		
		return 1;
	}
	return -1;
}

int __si_string40_set( __si_string40_t * ptr_string, u_char * val, uint16_t len)
{
	if( len <= 40)
	{	
		memcpy( ptr_string->val, val, len);
		ptr_string->isset = 1;
		ptr_string->len = len;
		ptr_string->val[len] = 0;
		
		return 1;
	}
	return -1;
}


int __si_string60_set( __si_string60_t * ptr_string, u_char * val, uint16_t len)
{
	if( len <= 60)
	{	
		memcpy( ptr_string->val, val, len);
		ptr_string->isset = 1;
		ptr_string->len = len;
		ptr_string->val[len] = 0;
		
		return 1;
	}
	return -1;
}


int __si_string80_set( __si_string80_t * ptr_string, u_char * val, uint16_t len)
{
	if( len <= 80)
	{	
		memcpy( ptr_string->val, val, len);
		ptr_string->isset = 1;
		ptr_string->len = len;
		ptr_string->val[len] = 0;
		
		return 1;
	}
	return -1;
}


int __si_string100_set( __si_string100_t * ptr_string, u_char * val, uint16_t len)
{
	if( len <= 100)
	{	
		memcpy( ptr_string->val, val, len);
		ptr_string->isset = 1;
		ptr_string->len = len;
		ptr_string->val[len] = 0;
		
		return 1;
	}
	return -1;
}

int __si_string120_set( __si_string120_t * ptr_string, u_char * val, uint16_t len)
{
	if( len <= 120)
	{	
		memcpy( ptr_string->val, val, len);
		ptr_string->isset = 1;
		ptr_string->len = len;
		ptr_string->val[len] = 0;
		
		return 1;
	}
	return -1;
}

int __si_string140_set( __si_string140_t * ptr_string, u_char * val, uint16_t len)
{
	if( len <= 140)
	{	
		memcpy( ptr_string->val, val, len);
		ptr_string->isset = 1;
		ptr_string->len = len;
		ptr_string->val[len] = 0;
		
		return 1;
	}
	return -1;
}

int __si_string160_set( __si_string160_t * ptr_string, u_char * val, uint16_t len)
{
	if( len <= 160)
	{	
		memcpy( ptr_string->val, val, len);
		ptr_string->isset = 1;
		ptr_string->len = len;
		ptr_string->val[len] = 0;
		
		return 1;
	}
	return -1;
}

int __si_string180_set( __si_string180_t * ptr_string, u_char * val, uint16_t len)
{
	if( len <= 180)
	{	
		memcpy( ptr_string->val, val, len);
		ptr_string->isset = 1;
		ptr_string->len = len;
		ptr_string->val[len] = 0;
		
		return 1;
	}
	return -1;
}

int __si_string200_set( __si_string200_t * ptr_string, u_char * val, uint16_t len)
{
	if( len <= 200)
	{	
		memcpy( ptr_string->val, val, len);
		ptr_string->isset = 1;
		ptr_string->len = len;
		ptr_string->val[len] = 0;
		
		return 1;
	}
	return -1;
}

int __si_stringv_set( __si_stringv_t * ptr_string, u_char * val, uint16_t len)
{
	ptr_string->val = (u_char *)__si_allocM7( len + 1, __FILE__, __LINE__, 0);
	
	memcpy( ptr_string->val, val, len);
	ptr_string->isset = 1;
	ptr_string->len = len;
	ptr_string->val[len] = 0;
	ptr_string->vType = 'd';
	ptr_string->pos = 0;
	return 1;
}

int __si_stringv_setr( __si_stringv_t * ptr_string, u_char * val, uint16_t len)
{
	ptr_string->val = val;
	ptr_string->isset = 1;
	ptr_string->len = len;
	ptr_string->pos = 0;
	ptr_string->vType = 'r';
	
	return 1;
}

int __si_u32_set( SI_U32 * u32, uint32_t val)
{
	u32->val = val;
	u32->isset = 1;
	return 0;
}

int __si_u64_set( SI_U64 * u64, uint64_t val)
{
	u64->val = val;
	u64->isset = 1;	
	return 0;
}


void __si_stringv_put( __si_stringv_t * ptr_string)
{
	__si_freeM( ptr_string->val);
	ptr_string->isset = 0;
	ptr_string->len = 0;	
}

void ngtff_fsmq_init( NG_FSMQ * fsmq, uint8_t * object, __ng_fsm_thread_t * fThread)
{
	fsmq->object = object;
	fsmq->Head = NULL;
	fsmq->Current = NULL;
	//fsmq->isInQ = 0;
	pthread_mutex_init( &fsmq->Lock, NULL);	
	//pthread_mutex_init( &fsmq->isInQLock, NULL);	
	fsmq->fThread = fThread;
}

void ngtff_fsmq_addaction( NG_FSMQ * fsmq, int action, uint8_t * executor)
{
	pthread_mutex_lock( &fsmq->Lock);
	
	NG_FSM * fsm = (NG_FSM *) __si_allocM7( sizeof(NG_FSM), __FILE__, __LINE__, 0);
	
	fsm->Next = NULL;
	fsm->action = action;
	fsm->executor = executor;
	
	if(!fsmq->Head) {
		fsmq->Head = fsmq->Current = fsm;
	} else {
		fsmq->Current->Next = fsm;
		fsmq->Current = fsm;
	}
	
	pthread_mutex_unlock( &fsmq->Lock);
	
	__si_core_queue_item( fsmq->fThread->msgQueue, (void *)fsmq);
	
	/*
	pthread_mutex_lock( &fsmq->isInQLock);
	
	if( fsmq->isInQ == 0)
	{
		fsmq->isInQ = 1;
		__si_core_queue_item( fsmQueueThreads->msgQueue, (void *)fsmq);
	}
	
	pthread_mutex_unlock( &fsmq->isInQLock);
	*/
}

NG_FSM * ngtff_fsmq_getItem( NG_FSMQ * fsmq)
{
	NG_FSM * item = NULL;
	pthread_mutex_lock( &fsmq->Lock);
	
	if(fsmq->Head) 
	{
		item = fsmq->Head;
		fsmq->Head = item->Next;
	}
	
	pthread_mutex_unlock( &fsmq->Lock);
	return item;
}

void ngtff_fsmq_worker_thread( void * vFsmq, int index)
{
	NG_FSMQ * fsmq = (NG_FSMQ *) vFsmq;
	
	NG_FSM * fsm = ngtff_fsmq_getItem( fsmq);
	
	while( fsm)
	{
		if( fsmq->status == NGTFF__FSM__STOP)
		{
			__si_freeM( (void *)fsm);
			fsm = NULL;			
			break;
		}
		
		if( fsmq->fThread->ptrCallBackHandler > 0)
		{
			fsmq->status = fsmq->fThread->ptrCallBackHandler( fsmq, fsm->action);
		}
		
		__si_freeM( (void *)fsm);
		fsm = NULL;
		
		if( fsmq->status == NGTFF__FSM__STOP)
			break;
		
		fsm = ngtff_fsmq_getItem( fsmq);
	}

	/*
	pthread_mutex_lock( &fsmq->isInQLock);
	fsmq->isInQ = 0;
	pthread_mutex_unlock( &fsmq->isInQLock);
	*/
}

__ng_fsm_thread_t * ngtff_fsmq_create_thread( int (*ptrCallBackHandler)( NG_FSMQ *, int), int iNoOfThreads)
{
	__ng_fsm_thread_t * fsm_thread = (__ng_fsm_thread_t *)malloc( sizeof( __ng_fsm_thread_t));
	fsm_thread->ptrCallBackHandler = ptrCallBackHandler;
	__si_core_create_queue( &fsm_thread->msgQueue, ngtff_fsmq_worker_thread, iNoOfThreads, 10000);
	return fsm_thread;
}

void __si_ServiceRequest__setLogTag( SI_ServiceRequest * serviceRequest, char * str)
{
	int len = strlen( str);
	
	if( len  < 20) 
	{
		memcpy( serviceRequest->logtag, str, len);
		serviceRequest->logtag[len] = 0;
	} else {
		serviceRequest->logtag[0] = 0;
	}
}

void __si_ServiceRequest__setLogTag_u64( SI_ServiceRequest * serviceRequest, uint64_t uval)
{
	memset( serviceRequest->logtag, 0, sizeof( serviceRequest->logtag));
	sprintf( serviceRequest->logtag, "%lu", uval);
}


void __si_ServiceRequest__add( SI_ServiceRequest * serviceRequest, int lockMode)
{
	if( lockMode) {
		pthread_mutex_lock( &__siCore->ServiceRequestLock);	
	}
	
	if(!__siCore->ServiceRequestHead)
	{
		__siCore->ServiceRequestHead = __siCore->ServiceRequestCurrent = serviceRequest;
	}
	else
	{
		__siCore->ServiceRequestCurrent->Next = serviceRequest;
		__siCore->ServiceRequestCurrent = serviceRequest;
	}
	
	__siCore->ServiceRequestAvailablePoolCount++;
	
	if( lockMode) {
		pthread_mutex_unlock( &__siCore->ServiceRequestLock);	
	}
}

void __si_ServiceRequest__create( int size, int lockMode)
{
	if( lockMode) {
		pthread_mutex_lock( &__siCore->ServiceRequestLock);	
	}
	
	int i = 0;
	SI_ServiceRequest * serviceRequest = NULL;
	
	for( i = 0; i < size; i++)
	{
		serviceRequest = (SI_ServiceRequest *)__si_malloc( sizeof( SI_ServiceRequest));
		memset( serviceRequest, 0, sizeof( SI_ServiceRequest));
		
		__si_ServiceRequest__add( serviceRequest, 0);
		__siCore->ServiceRequestTotalPoolCount++;
	}
	
	if( lockMode) {
		pthread_mutex_unlock( &__siCore->ServiceRequestLock);	
	}	
}

SI_ServiceRequest * __si_ServiceRequest__allocate()
{
	pthread_mutex_lock( &__siCore->ServiceRequestLock);
	SI_ServiceRequest * serviceRequest = __siCore->ServiceRequestHead;

	if(!serviceRequest)
	{
		__si_ServiceRequest__create( 1000, 0);
		serviceRequest = __siCore->ServiceRequestHead;
	}
	
	if(serviceRequest)
	{
		__siCore->ServiceRequestHead = serviceRequest->Next;
		
		serviceRequest->Next = NULL;

		serviceRequest->ServiceRequestId = 0;
		serviceRequest->ApiId = 0;
		serviceRequest->InterfaceId = 0;
		serviceRequest->Timer = NULL;
		serviceRequest->transportObject = NULL;
		__si_StartExecTime( &serviceRequest->execTime);
		__siCore->ServiceRequestAvailablePoolCount--;
	}
	
	pthread_mutex_unlock( &__siCore->ServiceRequestLock);
	return serviceRequest;	
}


SI_ServiceRequest * __si_ServiceRequest__allocate2( uint32_t InterfaceId, uint32_t ApiId, uint32_t requestDataObjectSize)
{
	SI_ServiceRequest * serviceRequest 	= __si_ServiceRequest__allocate();	
	
	if(!serviceRequest) return NULL;
	
	serviceRequest->InterfaceId 		= InterfaceId;
	serviceRequest->ApiId 				= ApiId;
	serviceRequest->RetryCount 			= 0;
	serviceRequest->NssaiCount			= 0;
	serviceRequest->selInterface		= NULL;	
	serviceRequest->TimeOutSeconds		= 0;
	serviceRequest->transportObject		= NULL;
	serviceRequest->transportObjectRetain = 0;
	
	memset( &serviceRequest->Route, 0, sizeof( serviceRequest->Route));
	memset( serviceRequest->serviceName, 0, sizeof( serviceRequest->serviceName));
	serviceRequest->location = NULL;
	
	if( requestDataObjectSize > 0)
	{	
		serviceRequest->Data 				= (uint8_t *) __si_allocM7( requestDataObjectSize, __FILE__, __LINE__, 0);;
		memset( serviceRequest->Data, 0, requestDataObjectSize);
	}
	else
	{
		serviceRequest->Data = NULL;
	}
	
	return serviceRequest;
}

void __si_ServiceRequest__release( SI_ServiceRequest * serviceRequest)
{
	serviceRequest->Object = NULL;
	
	if( serviceRequest->Data)					//Request
		__si_freeM( serviceRequest->Data);
	
	if( serviceRequest->ResponseData)			//Response
		__si_freeM( serviceRequest->ResponseData);

	if( serviceRequest->ResponseContentType)			//Response
		__si_freeM( serviceRequest->ResponseContentType);
		
	if( serviceRequest->location)
		__si_freeM( serviceRequest->location);	

	serviceRequest->Data = NULL;
	serviceRequest->ResponseData = NULL;
	serviceRequest->ResponseContentType = NULL;
	serviceRequest->location = NULL;
	
	__si_ServiceRequest__add( serviceRequest, 1);
}

int __si_Activity__get_total_count()
{
	return __siCore->ActivityTotalPoolCount;
}

int __si_Activity__get_available_count()
{
	return __siCore->ActivityAvailablePoolCount;
}


void __si_Activity__add( SI_Activity * activityItem, int lockMode)
{
	if( lockMode) {
		pthread_mutex_lock( &__siCore->ActivityLock);	
	}
	
	if(!__siCore->ActivityHead)
	{
		__siCore->ActivityHead = __siCore->ActivityCurrent = activityItem;
	}
	else
	{
		__siCore->ActivityCurrent->Next = activityItem;
		__siCore->ActivityCurrent = activityItem;
	}
	
	__siCore->ActivityAvailablePoolCount++;

	if( lockMode) {
		pthread_mutex_unlock( &__siCore->ActivityLock);	
	}
}


void __si_Activity__create( int size, int lockMode)
{
	if( lockMode) {
		pthread_mutex_lock( &__siCore->ActivityLock);	
	}
	
	int i = 0;
	SI_Activity * activityItem = NULL;
	
	for( i = 0; i < size; i++)
	{
		activityItem = (SI_Activity *)__si_malloc( sizeof( SI_Activity));
		memset( activityItem, 0, sizeof( SI_Activity));
		
		__si_Activity__add( activityItem, 0);
		__siCore->ActivityTotalPoolCount++;
	}
	
	if( lockMode) {
		pthread_mutex_unlock( &__siCore->ActivityLock);	
	}
}


	
SI_Activity * __si_Activity__allocate()
{
	pthread_mutex_lock( &__siCore->ActivityLock);
	SI_Activity * activityItem = __siCore->ActivityHead;

	if(!activityItem)
	{
		__si_Activity__create( 1000, 0);
		activityItem = __siCore->ActivityHead;
	}
	
	if(activityItem)
	{
		__siCore->ActivityHead = activityItem->Next;
		
		activityItem->Next = NULL;
		activityItem->Parent = NULL;
		activityItem->ActivityType = 0;
		activityItem->ActivityStatus = 0;
		activityItem->ActivityStateId = 0;
		activityItem->data = NULL;
	
		__siCore->ActivityAvailablePoolCount--;
	}
	
	pthread_mutex_unlock( &__siCore->ActivityLock);
	return activityItem;
}

void __si_Activity__release( SI_Activity * activityItem)
{
	__si_Activity__add( activityItem, 1);
}


SI_ServiceRequestManager * __si_ServiceRequestManager__create()
{
	SI_ServiceRequestManager * srm = (SI_ServiceRequestManager *) __si_malloc( sizeof(SI_ServiceRequestManager) );
	memset( srm, 0, sizeof( SI_ServiceRequestManager));
	
	return srm;
}

SI_ServiceRequestInterface * __si_ServiceRequestManager__findInterface( SI_ServiceRequestManager * srm, uint32_t interfaceId)
{
	if(!srm) return NULL;
	
	SI_ServiceRequestInterface * sriItem =  srm->sriHead;
	int bFoundInterface = 0;
	
	//Find interface
	while( sriItem)
	{
		if( sriItem->InterfaceId == interfaceId)
		{
			return sriItem;
		}
		
		sriItem = sriItem->Next;
	}
	return NULL;
}

SI_ServiceRequestAPI * __si_ServiceRequestManager__findApi( SI_ServiceRequestInterface * sriItem, uint32_t apiId)
{
	if(!sriItem) return NULL;
	
	SI_ServiceRequestAPI * apiItem = sriItem->apiHead;
	
	while( apiItem)
	{
		if( apiItem->ApiId == apiId)
		{
			return apiItem;
		}
		apiItem = apiItem->Next;
	}
	return NULL;
}

int __si_ServiceRequestManager__register( SI_ServiceRequestManager * srm, uint32_t interfaceId, uint32_t apiId, ServiceExecutionFunction func)
{
	SI_ServiceRequestInterface * sriItem =  __si_ServiceRequestManager__findInterface( srm, interfaceId);
	
	if(!sriItem)
	{
		sriItem = (SI_ServiceRequestInterface *) __si_malloc( sizeof(SI_ServiceRequestInterface));
		memset( sriItem, 0, sizeof( SI_ServiceRequestInterface));
		
		sriItem->InterfaceId = interfaceId;
		
		if(!srm->sriHead)
		{
			srm->sriHead = srm->sriCurrent = sriItem;
		}
		else
		{
			srm->sriCurrent->Next = sriItem;
			srm->sriCurrent = sriItem;
		}
	}
	
	//Find API in interface
	SI_ServiceRequestAPI * apiItem = __si_ServiceRequestManager__findApi( sriItem, apiId);
	
	if( apiItem)
	{
		return 0;
	}
	
	apiItem = (SI_ServiceRequestAPI *)__si_malloc( sizeof(SI_ServiceRequestAPI));
	memset( apiItem, 0, sizeof( SI_ServiceRequestAPI));
	
	apiItem->ApiId = apiId;
	apiItem->Func = func;
	
	if(!sriItem->apiHead)
	{
		sriItem->apiHead = sriItem->apiCurrent = apiItem;
	}
	else
	{
		sriItem->apiCurrent->Next = apiItem;
		sriItem->apiCurrent = apiItem;
	}
	
	return 1;
}

SI_ServiceRequestAPI * __si_ServiceRequestManager__getApi( SI_ServiceRequestManager * srm, uint32_t interfaceId, uint32_t apiId)
{
	//printf("interfaceId=%u   apiId=%u   %s|%s|%d\n", interfaceId, apiId, __FILE__, __FUNCTION__, __LINE__);
	
	SI_ServiceRequestInterface * sriItem =  __si_ServiceRequestManager__findInterface( srm, interfaceId);
	
	//printf("sriItem=%p %s|%s|%d\n", sriItem, __FILE__, __FUNCTION__, __LINE__);
	
	SI_ServiceRequestAPI * apiItem = __si_ServiceRequestManager__findApi( sriItem, apiId);
	return apiItem;
}

int __si_ServiceRequestManager__execute( SI_ServiceRequestManager * srm, SI_ServiceRequest * serviceRequest)
{
	SI_ServiceRequestAPI * srApi = __si_ServiceRequestManager__getApi( srm, serviceRequest->InterfaceId, serviceRequest->ApiId);
	
	if( srApi)
	{
		if( srApi->Func)
		{
			srApi->Func( serviceRequest);
		}
		else 
		{
			return -2;
		}	
	}
	else 
	{
		return -1;
	}
	
	return 1;
}

int __si_ServiceRequestManager__executeAsync( SI_ServiceRequestManager * srm, SI_ServiceRequest * serviceRequest)
{
	SI_ServiceRequestAPI * srApi = __si_ServiceRequestManager__getApi( srm, serviceRequest->InterfaceId, serviceRequest->ApiId);
	
	if( srApi)
	{
		if( srApi->Func)
		{
			//srApi->Func( serviceRequest);
			__si_core_queue( (uint8_t *) serviceRequest, (queue_handler) srApi->Func);
			return 1;
		}
		else 
		{
			return -2;
		}	
	}
	else 
	{
		return -1;
	}
	
	return 1;
}

u_char * __si_strdup( u_char * pstr)
{
	if(!pstr) return NULL;
	
	int _strlen = strlen( pstr);
	
	u_char * str = (u_char *) __si_allocM7( _strlen, __FILE__, __LINE__, 0);
	strncpy( str, pstr, _strlen);
	str[_strlen] = '\0';
	
	return str;	
}

u_char * __si_strdup2( u_char * pstr, int len)
{
	if(!pstr) return NULL;
	
	int _strlen = len;
	
	u_char * str = (u_char *) __si_allocM7( _strlen, __FILE__, __LINE__, 0);
	strncpy( str, pstr, _strlen);
	str[_strlen] = '\0';
	
	return str;	
}

u_char * __si_strdup3( u_char * pstr, int startPos, int len)
{
	if(!pstr) return NULL;
	
	int _strlen = len;
	
	u_char * str = (u_char *) __si_allocM7( len + 1, __FILE__, __LINE__, 0);
	memcpy( str, &pstr[startPos], _strlen);
	str[_strlen] = '\0';
	
	return str;	
}


//perminent
u_char * __si_pstrdup( u_char * pstr)
{
	if(!pstr) return NULL;
	
	int _strlen = strlen( pstr) + 1;
	
	u_char * str = (u_char *) __si_malloc( _strlen);
	strncpy( str, pstr, _strlen-1);
	str[_strlen] = '\0';
	
	return str;
}

SI_IdProvider * __si_idProvider_create( uint32_t basNo, uint32_t MaximumNo, uint32_t Count)
{
	SI_IdProvider * idProvider = (SI_IdProvider *)__si_malloc( sizeof(SI_IdProvider));
	memset( idProvider, 0, sizeof( SI_IdProvider));
	
	idProvider->BaseNo = basNo;
	idProvider->MaximumNo = MaximumNo;
	idProvider->Count = Count;
	
	return idProvider;
}

uint32_t __si_idProvider_getNext( SI_IdProvider * idProvider, uint32_t uRotatedVal)
{
	if( (uRotatedVal + idProvider->Count) > idProvider->MaximumNo)
	{
		return __si_idProvider_getBaseNo( idProvider, uRotatedVal);
	}
	return (uRotatedVal + idProvider->Count);
}

uint32_t __si_idProvider_calcBaseNo( SI_IdProvider * idProvider, uint32_t uIdNo)
{
	return uIdNo + idProvider->BaseNo;
}

uint32_t __si_idProvider_getBaseNo( SI_IdProvider * idProvider, uint32_t uRotatedVal)
{
	return ((uRotatedVal - idProvider->BaseNo) % idProvider->Count) + idProvider->BaseNo;
}

uint32_t __si_idProvider_getIdNo( SI_IdProvider * idProvider, uint32_t uIdNo)
{
	return ((uIdNo - idProvider->BaseNo) % idProvider->Count);
}



uint32_t __si_indexRow_getId( SI_IndexRow * iRow)
{
	//return iRow->id;
	return iRow->next_id;
}

uint8_t * __si_indexRow_getObject( SI_IndexRow * iRow)
{
	return iRow->Object;
}

uint8_t * __si_indexRow_getObject2( SI_IndexRow * iRow)
{
	return iRow->Object2;
}

void __si_indexRow_setObject( SI_IndexRow * iRow, uint8_t * Obj)
{
	iRow->Object = Obj;
}

void __si_indexRow_setObject2( SI_IndexRow * iRow, uint8_t * Obj)
{
	iRow->Object2 = Obj;
}

timer_handler __si_indexRow_getTimerHandler(SI_IndexRow * iRow)
{
	return iRow->handler;
}

void __si_indexRow_setTimerHandler(SI_IndexRow * iRow, timer_handler handler)
{
	iRow->handler = handler;
}

void __si_indexRow_setTimer( SI_IndexRow * iRow, timer_handler handler, int seconds)
{
	if( seconds > 0)
	{
		iRow->timer = __si_core_start_timer( (uint8_t*)iRow, handler, seconds);
	}
}

void __si_indexRow_clearTimer( SI_IndexRow * iRow)
{
	if( iRow->timer)
	{
		__si_core_clear_timer( iRow->timer);
	}
}


SI_IndexTable * __si_IndexTable_create(  uint32_t baseId, uint32_t count)
{
	SI_IndexTable * indexTable = (SI_IndexTable *)__si_malloc( sizeof(SI_IndexTable));
	memset( indexTable, 0, sizeof( SI_IndexTable));
	
	indexTable->idProvider = __si_idProvider_create( baseId, UINT_MAX-count, count);
	
	pthread_mutex_init( &indexTable->Lock, NULL);
	indexTable->table = (SI_IndexRow **)malloc( sizeof( SI_IndexRow *) * count);
	
	SI_IndexRow * iRow = NULL;
	
	int i = 0;
	for( i = 0; i < count; i++)
	{
		iRow = (SI_IndexRow *)__si_malloc( sizeof( SI_IndexRow));
		
		iRow->id = __si_idProvider_calcBaseNo( indexTable->idProvider, i);
		iRow->next_id = iRow->id;
		
		iRow->Object = NULL;
		iRow->Object2 = NULL;
		iRow->timer = NULL;		
		iRow->Parent = indexTable;
		iRow->Next = NULL;
		
		if(!indexTable->rowHead) 
		{
			indexTable->rowHead = indexTable->rowCurrent = iRow;
		} 
		else 
		{
			indexTable->rowCurrent->Next = iRow;
			indexTable->rowCurrent = iRow;
		}
		indexTable->table[i] = iRow;
	}
	
	indexTable->Total 		= count;
	indexTable->Available 	= count;
	indexTable->Used 		= 0;

	return indexTable;
}


SI_IndexTable * __si_IndexTable_create2(  uint32_t baseId, uint32_t count, uint32_t max)
{
	SI_IndexTable * indexTable = (SI_IndexTable *)__si_malloc( sizeof(SI_IndexTable));
	memset( indexTable, 0, sizeof( SI_IndexTable));
	
	indexTable->idProvider = __si_idProvider_create( baseId, max, count);
	
	pthread_mutex_init( &indexTable->Lock, NULL);
	indexTable->table = (SI_IndexRow **)malloc( sizeof( SI_IndexRow *) * count);
	
	SI_IndexRow * iRow = NULL;
	
	int i = 0;
	for( i = 0; i < count; i++)
	{
		iRow = (SI_IndexRow *)__si_malloc( sizeof( SI_IndexRow));
		
		iRow->id = __si_idProvider_calcBaseNo( indexTable->idProvider, i);
		iRow->next_id = iRow->id;
		
		iRow->Object = NULL;
		iRow->Object2 = NULL;
		iRow->timer = NULL;		
		iRow->Parent = indexTable;
		iRow->Next = NULL;
		
		if(!indexTable->rowHead) 
		{
			indexTable->rowHead = indexTable->rowCurrent = iRow;
		} 
		else 
		{
			indexTable->rowCurrent->Next = iRow;
			indexTable->rowCurrent = iRow;
		}
		indexTable->table[i] = iRow;
	}
	
	indexTable->Total 		= count;
	indexTable->Available 	= count;
	indexTable->Used 		= 0;

	return indexTable;
}



SI_IndexRow * __si_IndexTable_FindRow( SI_IndexTable * indexTable, uint32_t id)
{
	uint32_t indexId = __si_idProvider_getIdNo( indexTable->idProvider, id);
	
	if( indexId < indexTable->Total)
	{
		SI_IndexRow * indexRow = indexTable->table[indexId];
		
		if( __si_indexRow_getId( indexRow) != id)
		{
			//id rotated
			return NULL;
		}
		
		return indexRow;
	}
	
	return NULL;
}


uint8_t * __si_IndexTable_FindObject1( SI_IndexTable * indexTable, uint32_t id)
{
	uint32_t indexId = __si_idProvider_getIdNo( indexTable->idProvider, id);
	
	if( indexId < indexTable->Total)
	{
		SI_IndexRow * indexRow = indexTable->table[indexId];
		
		if( __si_indexRow_getId( indexRow) != id)
		{
			//id rotated
			return NULL;
		}
		
		return __si_indexRow_getObject( indexRow);
	}
	
	return NULL;	
}


void __si_IndexTable_FreeRow( SI_IndexTable * indexTable, uint32_t id)
{
	uint32_t indexId = __si_idProvider_getIdNo( indexTable->idProvider, id);
	
	if( indexId < indexTable->Total)
	{
		SI_IndexRow * indexRow = indexTable->table[indexId];
		
		if( __si_indexRow_getId( indexRow) != id)
		{
			return;
		}
		
		__si_IndexTable_putRow( indexRow);
	}	
}


void __si_IndexTable_plog( char * name, SI_IndexTable * indexTable)
{
	if( indexTable)
	{	
		__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%-29s   Total=%-08u   Available=%-08u   Used=%-08lu", name, indexTable->Total, indexTable->Available, indexTable->Used);
	}
}

SI_IndexRow * __si_IndexTable_getRow( SI_IndexTable * indexTable)
{
	pthread_mutex_lock( &indexTable->Lock);
	
	SI_IndexRow * iRow = indexTable->rowHead;
	
	if(iRow)
	{	
		iRow->Parent->Available--;
		indexTable->rowHead = iRow->Next;
	}
	
	pthread_mutex_unlock( &indexTable->Lock);
	
	return iRow;
}

uint32_t __si_IndexTable_allocateRowId( SI_IndexTable * indexTable, uint8_t * obj)
{
	SI_IndexRow * iRow = __si_IndexTable_getRow( indexTable);
	__si_indexRow_setObject( iRow, obj);
	return __si_indexRow_getId( iRow);
}


void __si_IndexTable_putRow( SI_IndexRow * iRow)
{
	pthread_mutex_lock( &iRow->Parent->Lock);
	
	if(!iRow->Parent->rowHead) 
	{
		iRow->Parent->rowHead = iRow->Parent->rowCurrent = iRow;
	} 
	else 
	{
		iRow->Parent->rowCurrent->Next = iRow;
		iRow->Parent->rowCurrent = iRow;
	}

	iRow->next_id = __si_idProvider_getNext( iRow->Parent->idProvider, iRow->next_id);
	
	iRow->Parent->Available++;
	pthread_mutex_unlock( &iRow->Parent->Lock);
}


#define UUID_NUM_OF_BYTES   16
#define UUID4_LEN 37

//#pragma pack(4)
typedef struct __dater
{
    unsigned char day;      /* 1-31 */
    unsigned char month;    /* 1-12 */
    unsigned short year;    /* 1980-2078 */
} date_r;

//#pragma pack(4)
typedef struct __time_r
{
    unsigned char hour;     /* 0-23 */
    unsigned char minute;   /* 0-59 */
    unsigned char second;   /* 0-59 */
} time_r;

//#pragma pack(4)
typedef struct __CDate
{
    date_r dosdate;
    time_r dostime;
} CDate;


static uint64_t xorshift128plus(uint8_t *seedBuffer)
{
    uint64_t *s = (uint64_t *)seedBuffer;
    /* http://xorshift.di.unimi.it/xorshift128plus.c */
    uint64_t s1 = s[0];
    const uint64_t s0 = s[1];
    s[0] = s0;
    s1 ^= s1 << 23;
    s[1] = s1 ^ s0 ^ (s1 >> 18) ^ (s0 >> 5);
    return s[1] + s0;
}

static void generateSeed( CDate * date, uint8_t *serialNumber, uint8_t *seedBuffer)
{
	int i = 0;
    for (i = 0; i < 10; ++i)
    {
        seedBuffer[i] = serialNumber[i];
    }

    seedBuffer[10] = date->dostime.second;
    seedBuffer[11] = date->dostime.minute;
    seedBuffer[12] = date->dostime.hour;

    seedBuffer[13] = date->dosdate.day;
    seedBuffer[14] = date->dosdate.month;
    seedBuffer[15] = date->dosdate.year - 2000;
}

void Uuid4_Generate( CDate * date, uint8_t * serialNumber, uint8_t * uuidBin)
{
    //assert(uuidBin != NULL);
    union { unsigned char b[UUID_NUM_OF_BYTES]; uint64_t word[2]; } s;

    uint8_t seed[UUID_NUM_OF_BYTES];
    generateSeed(date, serialNumber, seed);

    s.word[0] = xorshift128plus(seed);
    s.word[1] = xorshift128plus(seed);

    memcpy(uuidBin, s.b, sizeof(s));
}

void Uuid4_BinToString( const uint8_t *uuidBin, uint8_t *uuidString)
{
    //assert(uuidBin != NULL);
    //assert(uuidString != NULL);

    static const char *template = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx";
    static const char *chars = "0123456789abcdef";

    const char *p;
    p = template;
    int i = 0;
    
    while (*p)
    {
        int n;
        n = uuidBin[i >> 1];
        n = (i & 1) ? (n >> 4) : (n & 0xf);
        switch (*p)
        {
        case 'x'  : *uuidString = chars[n];              i++;  break;
        case 'y'  : *uuidString = chars[(n & 0x3) + 8];  i++;  break;
        default   : *uuidString = *p;
        }
        uuidString++, p++;
    }
    *uuidString = '\0';
}

void __si_generate_uuid4( char * uuid4)
{
	struct timeval tv;
	struct timezone tzone;
	gettimeofday( &tv, &tzone);
	struct tm *timeinfo = gmtime( &tv.tv_sec);
	
	uint8_t uuidValue[16];
    
	CDate date;
    date.dostime.second = timeinfo->tm_sec;
    date.dostime.minute = timeinfo->tm_min;
    date.dostime.hour = timeinfo->tm_hour;

    date.dosdate.day = timeinfo->tm_mday;
    date.dosdate.month = (timeinfo->tm_mon) + 1;
    date.dosdate.year = (timeinfo->tm_year) + 1900;
	
	__siCore->UUID4SerialNumber++;
	uint8_t serialNumber[11] = "0128000001";
	memcpy( serialNumber, &__siCore->UUID4SerialNumber, 8);
	
	Uuid4_Generate( &date, serialNumber, uuidValue);
	Uuid4_BinToString( uuidValue, uuid4);
}


int __si__copy( const char * src, char * dst, int dst_str_len)
{
	if(!src || !dst || dst_str_len == 0) 
	{
		return -1;
	}
	
	int srclen = strlen(src);
	
	if( dst_str_len < srclen) 
	{
		memcpy( dst, src, srclen);
		dst[ srclen ] = '\0';
		return 1;
	} 
	else 
	{
		memcpy( dst, src, (dst_str_len-1));
		dst[ dst_str_len ] = '\0';
		return 0;
	}
}

void __si_strncpy( char * dest, char * src, int len)
{
	if( len > 0) {
		memcpy( dest, src, len);
	} 
	dest[len] = '\0';	
}

void __si_strcpy( char * dest, char * src)
{
	int len = strlen( src);
	__si_strncpy( dest, src, len);
}

int __si_memcmp( char * src1, char * src2, int len)
{
	if(!src1) return -1;
	if(!src2) return -2;	
	if( strlen(src1) != len) return -3;
	if( strlen(src2) != len) return -4;
	
	return memcmp( src1, src2, len);
}

void *__si_ascii_to_hex(char *in, int in_len, void *out, int out_len)
{
    int i = 0, j = 0, k = 0, hex;
    uint8_t *out_p = out;

    while(i < in_len && j < out_len) {
        if (!isspace(in[i])) {
            hex = isdigit(in[i]) ? in[i] - '0' : 
                islower(in[i]) ? in[i] - 'a' + 10 : in[i] - 'A' + 10;
            if ((k & 0x1) == 0) {
                out_p[j] = (hex << 4);
            } else {
                out_p[j] |= hex;
                j++;
            }
            k++;
        }
        i++;
    }

    return out;
}

void *__si_hex_to_ascii(void *in, int in_len, void *out, int out_len)
{
    char *p;
    int i = 0, l, off = 0;

    p = out;
    p[0] = 0;

    l = (in_len - off) > out_len ? out_len : in_len - off;
    for (i = 0; i < l; i++) {
        p += sprintf(p, "%02x", ((char*)in)[off+i] & 0xff);
    }

    return out;
}

// oAUSFSession = (SI_AUSF_Session *)strtoll( &authCtxId[10], NULL, 16);
uint8_t * __si_strToPointer( u_char * strP)
{
	return (uint8_t *) strtoll( strP, NULL, 16);
}

// pool 22-05-2021

void __si_pool_add( si_sirik_pool_item_t * mItem, int lm)
{
	if( mItem->isReleased == 0)
	{
		si_sirik_pool_t * pool = mItem->parent;
		
		if( lm) 
		{
			pthread_mutex_lock( &pool->mLock);
			pool->Used++;
		}
		
		if(!pool->Head)
		{
			pool->Head = pool->Current = mItem;
		}
		else
		{
			pool->Current->Next = mItem;
			pool->Current = mItem;
		}
		
		mItem->isReleased = 1;
		pool->Available++;

		if( lm) 
		{
			pthread_mutex_unlock( &pool->mLock);
		}	
	}
}

int __si_pool_create_index( si_sirik_pool_t * pool)
{
	if( pool->Extend == 1)
	{
		printf("__si_pool: cannot create index on Extend Enabled\n");
		return 0;
	}
	
	pool->indexDB = (si_sirik_pool_item_t**)malloc(pool->Total * sizeof(si_sirik_pool_item_t*));
	si_sirik_pool_item_t * mItem = pool->Head;
	
	int i = 0;
	while( mItem)
	{
		pool->indexDB[i] = mItem;
		//printf( "pool i=%d %p\n", i, pool->indexDB[i]);
		mItem = mItem->Next;
		i++;
	}
	
	return 1;
}

void __si_pool_create_members( si_sirik_pool_t * pool, uint32_t count, int lm)
{
	if( lm) 
	{
		pthread_mutex_lock( &pool->mLock);
	}
	
	int i = 0;
	uint8_t * mPtr = malloc( count * ( sizeof(si_sirik_pool_item_t) + pool->Sz ));
	uint8_t * mItem = NULL;
	
	for( i = 0; i < count; i++)
	{
		mItem = mPtr;
		memset( mItem, 0, sizeof(si_sirik_pool_item_t));
		
		((si_sirik_pool_item_t *)mItem)->parent = pool;
		((si_sirik_pool_item_t *)mItem)->index = pool->Total;
		((si_sirik_pool_item_t *)mItem)->Next = NULL;
		__si_pool_add( (si_sirik_pool_item_t *)mItem, 0);
		pool->Total++;
		
		//printf( "%p %d %d\n", mPtr, sizeof(si_sirik_pool_item_t), pool->Sz);
		
		mPtr += (sizeof(si_sirik_pool_item_t) + pool->Sz);
	}

	if( lm) 
	{
		pthread_mutex_unlock( &pool->mLock);
	}	
}

si_sirik_pool_t * __si_pool_create( char * name, size_t objSize, uint32_t count, uint32_t extend)
{
	if( objSize == 0 || count == 0) return NULL;
	
	si_sirik_pool_t * pool = (si_sirik_pool_t *)malloc( sizeof(si_sirik_pool_t));
	memset( pool, 0, sizeof( si_sirik_pool_t));
	
	pthread_mutex_init( &pool->mLock, NULL);
	pool->Extend = extend;
	pool->Available = 0;
	pool->Total = 0;
	pool->Head = 0;
	pool->Current = 0;
	pool->Sz = objSize;
	pool->Used = 0;
	strcpy( pool->name, name);
	
	//__si_log( SI_APP_LOG, 0, SI_LOG_DEBUG, "created pool for pname=%s %p count=%u <%s|%s|%d>", pool->name, pool, count, __FILE__, __FUNCTION__, __LINE__);
	
	__si_pool_create_members( pool, count, 0);
	
	return pool;
}

uint8_t * __si_pool_allocate( si_sirik_pool_t * pool)
{
	pthread_mutex_lock( &pool->mLock);
	si_sirik_pool_item_t * mItem = pool->Head;
	
	if(!mItem)
	{
		if( pool->Extend == 0)
		{	
			//__si_log( SI_APP_LOG, 0, SI_LOG_DEBUG, "Pool=%p NOT-Extended Avail=%u Tot=%u <%s|%s|%d>", pool, pool->Available, pool->Total, __FILE__, __FUNCTION__, __LINE__);
			pthread_mutex_unlock( &pool->mLock);
			return NULL;
		}
		else
		{
			__si_pool_create_members( pool, 512, 0);
			//__si_log( SI_APP_LOG, 0, SI_LOG_DEBUG, "Pool=%p Extended Avail=%u Tot=%u <%s|%s|%d>", pool, pool->Available, pool->Total, __FILE__, __FUNCTION__, __LINE__);
			mItem = pool->Head;
		}
	}
	
	pool->Head = mItem->Next;
	mItem->Next = NULL;
	mItem->isReleased = 0;
	pool->Available--;
	
	pthread_mutex_unlock( &pool->mLock);
	//__si_log( SI_APP_LOG, 0, SI_LOG_DEBUG, "Pool=%p Allocated=%p index=%u Avail=%u Tot=%u <%s|%s|%d>", pool, mItem, mItem->index, pool->Available, pool->Total, __FILE__, __FUNCTION__, __LINE__);
	return (uint8_t *) (mItem) + sizeof(si_sirik_pool_item_t);
}

void __si_pool_release( uint8_t * item)
{
	si_sirik_pool_item_t * mItem = (si_sirik_pool_item_t *)(item-sizeof(si_sirik_pool_item_t));
	
	//si_sirik_pool_t * pool = mItem->parent;
	//__si_log( SI_APP_LOG, 0, SI_LOG_DEBUG, "Pool=%p Released=%p index=%u Avail=%u Tot=%u <%s|%s|%d>", pool, mItem, mItem->index, pool->Available, pool->Total, __FILE__, __FUNCTION__, __LINE__);
	
	__si_pool_add( mItem, 1);
}

uint8_t * __si_pool__find( si_sirik_pool_t * pool, uint32_t index)
{
	if( index >=0 && index < pool->Total)
	{
		si_sirik_pool_item_t * mItem = pool->indexDB[index];
		
		if( mItem)
		{
			return (uint8_t *) (mItem) + sizeof(si_sirik_pool_item_t);
		}
	}
	return NULL;
}

uint32_t __si_pool_index( uint8_t * item)
{
	si_sirik_pool_item_t * mItem = (si_sirik_pool_item_t *)(item-sizeof(si_sirik_pool_item_t));
	return mItem->index;
}



uint32_t __si_pool_fsm_index( uint8_t * item, uint32_t fsmTCount)
{
	return ( __si_pool_index( item) % fsmTCount);
}

void __si_pool_plog( si_sirik_pool_t * siPool)
{
	if( siPool)
	{	
		__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%-29s   Total=%-08u   Available=%-08u   Used=%-08lu", siPool->name, siPool->Total, siPool->Available, siPool->Used);	
	}
}
// ----------------------

void __si_buff__init()
{
	if(!__siCore->si_buffPool)
	{	
		__siCore->si_buffPool = __si_pool_create( "si_buffPool,sirik_core.c", sizeof(__si_buff_t), 1000, 1);
	}	
}

__si_buff_t * __si_buff__alloc( int msize)
{
	__si_buff_t * si_buff = (__si_buff_t *) __si_pool_allocate( __siCore->si_buffPool);
	
	si_buff->at 	= 1;
	si_buff->head 	= __si_allocM( msize);
	si_buff->data 	= si_buff->head;
	si_buff->pos  	= 0;
	return si_buff;
}


__si_buff_t * __si_buff__alloc2( u_char * data, uint32_t len)
{
	__si_buff_t * si_buff = (__si_buff_t *) __si_pool_allocate( __siCore->si_buffPool);
	
	si_buff->at 	= 2;
	si_buff->head 	= data;
	si_buff->data 	= si_buff->head;
	si_buff->len 	= len;
	si_buff->pos  	= 0;
	return si_buff;	
}

uint8_t * __si_buff__get_head( __si_buff_t * buff)
{
	return buff->head;
}

uint16_t __si_buff__get_len( __si_buff_t * buff)
{
	return buff->pos;
}


uint8_t * __si_buff__get_datapointer( __si_buff_t * buff)
{
	return (uint8_t *)buff->data;
}

uint8_t * __si_buff__get_current_datapointer( __si_buff_t * buff)
{
	return (uint8_t *)&buff->data[buff->pos];
}

void __si_buff__free( __si_buff_t * si_buff)
{
	if( si_buff->at == 1) {
		__si_freeM( si_buff->head);
		si_buff->head = si_buff->data = NULL;
	}
	__si_pool_release( (uint8_t *) si_buff);
}


void __si_buff__reserve( __si_buff_t * si_buff, int pos)
{
	si_buff->data += pos;
}

void __si_buff__copy( __si_buff_t * si_buff, char * buff, int len)
{
	memcpy( &si_buff->data[si_buff->pos], buff, len);
	si_buff->pos += len;
}

void __si_buff__pull( __si_buff_t * si_buff, int pos, int setlength)
{
	//printf( "__si_buff_t=%lu  si_buff=%p  %s|%d\n", sizeof(__si_buff_t), si_buff, __FILE__, __LINE__);
	
	si_buff->data -= pos;
	
	if( setlength == 1) 
	{
		//printf( "1 __si_buff_t=%lu  len=%u  pos=%u  %s|%d\n", sizeof(__si_buff_t), si_buff->len, pos, __FILE__, __LINE__);	
		si_buff->len += pos;
		//printf( "2 __si_buff_t=%lu  len=%u  pos=%u  %s|%d\n", sizeof(__si_buff_t), si_buff->len, pos, __FILE__, __LINE__);	
	}
}

int __si_buff__enc_uint64( __si_buff_t * si_buff, uint64_t val)
{
	si_buff->data[si_buff->pos++] = (val >> 56) & 0xFF;
	si_buff->data[si_buff->pos++] = (val >> 48) & 0xFF;
	si_buff->data[si_buff->pos++] = (val >> 40) & 0xFF;
	si_buff->data[si_buff->pos++] = (val >> 32) & 0xFF;
	si_buff->data[si_buff->pos++] = (val >> 24) & 0xFF;
	si_buff->data[si_buff->pos++] = (val >> 16) & 0xFF;
	si_buff->data[si_buff->pos++] = (val >> 8) & 0xFF;
	si_buff->data[si_buff->pos++] = val & 0xFF;	
	return 1;
}

int __si_buff__enc_uint32( __si_buff_t * si_buff, uint32_t val)
{
	si_buff->data[si_buff->pos++] = (val >> 24) & 0xFF;
	si_buff->data[si_buff->pos++] = (val >> 16) & 0xFF;
	si_buff->data[si_buff->pos++] = (val >> 8) & 0xFF;
	si_buff->data[si_buff->pos++] = val & 0xFF;	
	return 1;
}

int __si_buff__enc_uint16( __si_buff_t * si_buff, uint16_t val)
{
	si_buff->data[si_buff->pos++] = (val >> 8) & 0xFF;
	si_buff->data[si_buff->pos++] = val & 0xFF;		
	return 1;
}

int __si_buff__enc_uint8( __si_buff_t * si_buff, uint8_t val)
{
	si_buff->data[si_buff->pos++] = val & 0xFF;		
	return 1;
}



int __si_buff__enc_at_uint64( int pos, __si_buff_t * si_buff, uint64_t val)
{
	si_buff->data[ pos + 0] = (val >> 56) & 0xFF;
	si_buff->data[ pos + 1] = (val >> 48) & 0xFF;
	si_buff->data[ pos + 2] = (val >> 40) & 0xFF;
	si_buff->data[ pos + 3] = (val >> 32) & 0xFF;
	si_buff->data[ pos + 4] = (val >> 24) & 0xFF;
	si_buff->data[ pos + 5] = (val >> 16) & 0xFF;
	si_buff->data[ pos + 6] = (val >> 8) & 0xFF;
	si_buff->data[ pos + 7] = val & 0xFF;	
	return 1;
}

int __si_buff__enc_at_uint32( int pos, __si_buff_t * si_buff, uint32_t val)
{
	si_buff->data[ pos + 0] = (val >> 24) & 0xFF;
	si_buff->data[ pos + 1] = (val >> 16) & 0xFF;
	si_buff->data[ pos + 2] = (val >> 8) & 0xFF;
	si_buff->data[ pos + 3] = val & 0xFF;	

	return 1;
}

int __si_buff__enc_at_uint16( int pos, __si_buff_t * si_buff, uint16_t val)
{
	si_buff->data[ pos + 0] = (val >> 8) & 0xFF;
	si_buff->data[ pos + 1] = val & 0xFF;	
	return 1;
}

int __si_buff__enc_at_uint8( int pos, __si_buff_t * si_buff, uint8_t val)
{
	si_buff->data[ pos ] = val & 0xFF;
	return 1;
}

int __si_buff__dec_uint8( __si_buff_t * si_buff, uint8_t * val)
{
	unsigned char * buffer = (unsigned char *)&si_buff->data[si_buff->pos];
	*val = buffer[0];
	si_buff->pos += 1;
	return 1;
}

int __si_buff__dec_uint16( __si_buff_t * si_buff, uint16_t * val)
{
	unsigned char * buffer = (unsigned char *)&si_buff->data[si_buff->pos];
	*val = (buffer[0] << 8) + buffer[1];
	si_buff->pos += 2;
	return 1;
}

int __si_buff__dec_uint32( __si_buff_t * si_buff, uint32_t * val)
{
	unsigned char * buffer = (unsigned char *)&si_buff->data[si_buff->pos];
	*val = (buffer[0] << 24) + (buffer[1] << 16) + (buffer[2] << 8) + buffer[3];
	si_buff->pos += 4;
	return 1;
}

int __si_buff__dec_uint64( __si_buff_t * si_buff, uint64_t * val)
{
	unsigned char * buffer = (unsigned char *)&si_buff->data[si_buff->pos];
	
	*val = ((unsigned long)buffer[0] << 56) + ((unsigned long)buffer[1] << 48) + ((unsigned long)buffer[2] << 40) + ((unsigned long)buffer[3] << 32) 
				+ (buffer[4] << 24) + (buffer[5] << 16) + (buffer[6] << 8) + buffer[7];
	
	si_buff->pos += 8;
	return 1;
}

int __si_memcpy( char * dst, uint16_t dlen, char * src, uint16_t slen)
{
	if(!dst) return 0;
	if(!src) return 0;
	
	if( slen == 0) {
		slen = strlen(src);
	}
	
	if( dlen == 0 || slen == 0)
		return 0;
	
	if( slen > dlen) 
	{
		memcpy( dst, src, dlen);
		dst[dlen] = 0;
		return dlen;
	} 
	else 
	{
		memcpy( dst, src, slen);
		dst[slen] = 0;
		return slen;
	}
}

int __si_memcmp2( char * str1, uint16_t str1_len, char * str2, uint16_t str2_len)
{
	if(!str1) return -1;
	if(!str2) return -2;
	
	if( str1_len == 0) {
		str1_len = strlen(str1);
	}
	
	if( str2_len == 0) {
		str2_len = strlen(str2);
	}
	
	if( str1_len == 0 || str2_len == 0)
		return -3;

	if( str1_len != str2_len)
		return -4;
	
	int i = 0;
	while( i < str2_len )
	{
		if( str1[i] != str2[i])
		{
			return -1;
		}
		
		i++;
	}
	
	return 0;
	//return memcmp( str1, str2, str1_len);
}


void __si__perfcounter_init( __si_perfcounter_t * pCounter, char * name)
{
	memset( pCounter, 0, sizeof(__si_perfcounter_t));
	memcpy( pCounter->Name, name, strlen(name));
	pthread_mutex_init( &pCounter->lock, NULL);
}

void __si__perfcounter_count( __si_perfcounter_t * pCounter, SI_ExecTime * execTime, int bError)
{
	pCounter->Count++;
	if( bError) {
		pCounter->Error++;
	}
	__si_EndExecTime( execTime);
	
	
	pthread_mutex_lock( &pCounter->lock);

	switch( execTime->lapsed.tv_sec)
	{
		case 0:
			pCounter->ProcessInZeroSeconds++;
			break;			
		case 1:
			pCounter->ProcessInOneSecond++;
			break;			
		case 2:
			pCounter->ProcessInTwoSeconds++;
			break;			
		case 3:
			pCounter->ProcessInThreeSeconds++;
			break;			
		case 4:
			pCounter->ProcessInFourSeconds++;
			break;			
		case 5:
			pCounter->ProcessInFiveSeconds++;
			break;			
		default:
			pCounter->ProcessInAboveFiveSeconds++;
			break;
	}

	pthread_mutex_unlock( &pCounter->lock);	
}

void __si__perfcounter_log( __si_perfcounter_t * pCounter)
{
	__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%-50s lastCount=%-010lu | CCount=%-010lu | TCount=%-010lu | lastError=%-010lu | CError=%-010lu | TError=%-010lu | %lu|%lu|%lu|%lu|%lu|%lu|%lu", 
		pCounter->Name, 
		pCounter->lastCount, pCounter->Count-pCounter->lastCount, pCounter->Count, 
		pCounter->lastErrorCount, pCounter->Error-pCounter->lastErrorCount, pCounter->Error,
		pCounter->ProcessInZeroSeconds,
		pCounter->ProcessInOneSecond,
		pCounter->ProcessInTwoSeconds,
		pCounter->ProcessInThreeSeconds,
		pCounter->ProcessInFourSeconds,
		pCounter->ProcessInFiveSeconds,
		pCounter->ProcessInAboveFiveSeconds
	);
	
	pCounter->lastCount = pCounter->Count;
	pCounter->lastErrorCount = pCounter->Error;
}

void __si__per_log_pending_queuecount( char * name, void * queue)
{
	SI_CoreQueue * objQueue = (SI_CoreQueue *)queue;
	int CurrentProcessed = objQueue->TotalProcessed - objQueue->LastProcessed;
	
	__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%-30s     Processed %-5d TotalProcessed %-8ld PendingQueueCount %-4d Total %-8ld KeepAlive %-6d MPS %d", 
		name, CurrentProcessed, objQueue->TotalProcessed, objQueue->CurrentQueueCount, objQueue->TotalQueued, objQueue->KeepAlive, objQueue->MPS);
	
	objQueue->LastProcessed = objQueue->TotalProcessed;
}

void __si__per_log_pending_fsmqueuecount( char * name, void * queue)
{
	SI_CoreFSMQueue * fsmQueue = (SI_CoreFSMQueue *)queue;
	//__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%-50s PendingQueueCount=%d TotalQueued=%ld", name, objQueue->CurrentQueueCount, objQueue->TotalQueued);

	int i = 0;
	int CurrentProcessed = 0;
	
	for( i = 0; i < fsmQueue->ThreadCount; i++)
	{
		CurrentProcessed = fsmQueue->coreQueue[i]->TotalProcessed - fsmQueue->coreQueue[i]->LastProcessed;
		//SI_CoreQueue * objQueue = fsmQueue->coreQueue[i];
		
		__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%-30s  %-2d Processed %-5d TotalProcessed %-8ld PendingQueueCount %-4d Total %-8ld KeepAlive %-6d", 
			name, i, CurrentProcessed, fsmQueue->coreQueue[i]->TotalProcessed, fsmQueue->coreQueue[i]->CurrentQueueCount, fsmQueue->coreQueue[i]->TotalQueued, fsmQueue->coreQueue[i]->KeepAlive);
		
		fsmQueue->coreQueue[i]->LastProcessed = fsmQueue->coreQueue[i]->TotalProcessed;
	}
}

int __si__queuecount( void * queue)
{
	return ((SI_CoreQueue *)queue)->CurrentQueueCount;
}

void * __si_loadtestinfo_run( void * args)
{
	__si_loadtestitem_t * lt_item = (__si_loadtestitem_t *) args;
	__si_loadtestinfo_t * m_loadtest = lt_item->Parent;

	uint64_t msgCounter = 0;
	uint64_t totalMessages = 0;
	
	while(1)
	{
		while( msgCounter < m_loadtest->RequestPerSecond)
		{
			m_loadtest->executor( msgCounter, totalMessages, lt_item);
			
			msgCounter++;
			totalMessages++;
			
			if( totalMessages >= m_loadtest->MaxMessagesPerThread)
			{
				//printf("inner break %lu %lu\n", totalMessages, m_loadtest->MaxMessagesPerThread);
				break;
			}
		}
		
		if( totalMessages >= m_loadtest->MaxMessagesPerThread)
		{
			//printf("outer break %lu %lu\n", totalMessages, m_loadtest->MaxMessagesPerThread);
			break;
		}
		
		msgCounter = 0;
		__si_nanosleep( m_loadtest->SleepTime);
	}
	
	//printf("executor exit\n");
	return NULL;
}

uint8_t * __si_loadtest__getFuncTestData( __si_loadtestitem_t * testItem)
{
	__si_test_config_t * testConfig = (__si_test_config_t *)testItem->testConfig;
	return testConfig->jsonObject;
}

__si_loadtestinfo_t * __si_loadtest_create( int noOfThreads, fp_loadtest_executor executor, uint32_t RequestPerSecond, uint64_t MaxMessagesPerThread, uint32_t SleepTime, uint8_t * context)
{
	if( noOfThreads == 0 || RequestPerSecond == 0 || MaxMessagesPerThread == 0 || SleepTime == 0 || executor == 0)
		return NULL;
	
	__si_loadtestinfo_t * m_loadtest = (__si_loadtestinfo_t *) malloc(sizeof(__si_loadtestinfo_t));
	memset( m_loadtest, 0, sizeof(__si_loadtestinfo_t));
	
	m_loadtest->RequestPerSecond = RequestPerSecond;
	m_loadtest->MaxMessagesPerThread = MaxMessagesPerThread;
	m_loadtest->SleepTime = SleepTime;
	m_loadtest->executor = executor;
	m_loadtest->items = (__si_loadtestitem_t **)malloc( sizeof(__si_loadtestitem_t*) * noOfThreads );
	m_loadtest->context = context;
	pthread_mutex_init( &m_loadtest->contextLock, NULL);
	
	
	int i = 0;
	for( i = 0; i < noOfThreads; i++)
	{
		m_loadtest->items[i] = (__si_loadtestitem_t *)malloc( sizeof(__si_loadtestitem_t));
		memset( m_loadtest->items[i], 0, sizeof(__si_loadtestitem_t));
		m_loadtest->items[i]->Parent = m_loadtest; 
		m_loadtest->items[i]->index = i;
		m_loadtest->items[i]->context = NULL;
	}		

	for( i = 0; i < noOfThreads; i++)
	{	
		__si_create_pthread2( __si_loadtestinfo_run, m_loadtest->items[i], "si-loadtst");
	}
	
	return m_loadtest;
}

void __si_loadtest_response_recived( __si_loadtestitem_t * testItem)
{
	if( testItem->Parent->TestCaseExecutionType == 1 || testItem->Parent->TestCaseExecutionType == 2)
	{
		pthread_mutex_lock( &testItem->testConfig->ResponseCountLock);
		
			testItem->testConfig->ResponseCount++;
			
			if( testItem->Parent->TestCaseExecutionType == 2) {
				testItem->Parent->ResponseCount++;
			}
		
		pthread_mutex_unlock( &testItem->testConfig->ResponseCountLock);
		
		// __si_log( SI_APP_LOG, 0, SI_LOG_DEBUG, "Released %p Available=%u Total=%u  <%s|%s|%d>", testItem, 
			// testItem->Parent->testItemPool->Available, testItem->Parent->testItemPool->Total, 
			// __FILE__, __FUNCTION__, __LINE__);
		
		__si_pool_release( (uint8_t *)testItem);
		
		pthread_mutex_lock( &testItem->Parent->CallSemPostLock);
		if( testItem->Parent->CallSemPost > 0)
		{	
			sem_post( &testItem->Parent->sem_lock);
			testItem->Parent->CallSemPost--;
		}
		pthread_mutex_unlock( &testItem->Parent->CallSemPostLock);
		
	}
}

void __si_loadtest_exec2( void * vpItem, int index)
{
	__si_loadtestitem_t * testItem = (__si_loadtestitem_t *)vpItem;
	testItem->index = index;
	
	
	if( testItem->testConfig->executor > 0)
	{
		testItem->testConfig->executor( testItem->ReqNo, testItem->testConfig->TotalCount, testItem);
	}
	else if( testItem->Parent->executor > 0)
	{
		testItem->Parent->executor( testItem->ReqNo, testItem->testConfig->TotalCount, testItem);
	}
	else
	{
		__si_loadtest_response_recived( testItem);
	}
}

void * __si_loadtestinfo_run2(void * args)
{
	__si_loadtestinfo_t * loadtestinfo = (__si_loadtestinfo_t *) args;
	__si_loadtestitem_t * testItem = NULL;
	
	__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "TestCaseExecutionType=%d testConfigCount=%d  %s|%d", 
		loadtestinfo->TestCaseExecutionType, loadtestinfo->testConfigCount, __FILE__, __LINE__);

	//__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "device-info:[%s|%d] <core|%d>", sEncodedStr, sts, __LINE__);
	
	//printf("Starts After 1 Seconds  %s|%d\n", __FILE__, __LINE__);
	
	if( loadtestinfo->Delay > 0) 
	{
		printf("starting load in %d secs.\n", loadtestinfo->Delay);
		//sleep( loadtestinfo->Delay);
		int j = 0;
		unsigned char dots[10];
		memset( dots, 0, sizeof(dots));
		
		for( j = 0; j < loadtestinfo->Delay; j++) 
		{
			usleep( 999999);
			memset( dots, 0, sizeof(dots));
			memset( dots, '.' , j + 1);  
			
			printf( "\r%s", dots);
			fflush( stdout);
		}
		
		printf("\n");
	} 
	else 
	{
		printf("starting load in %d secs.\n", 1);		
		sleep( 1);
	}
	
	if( loadtestinfo->TestCaseExecutionType == 1)
	{
		int i = 0;
		int z = 0;
		int j = 0;
		int rr = 0;
		__si_test_config_t * tstConfig = NULL;
		
		for( i = 0; i < loadtestinfo->testConfigCount; i++)
		{
			tstConfig = loadtestinfo->testConfig[i];
			
			for( rr = 0; rr < (tstConfig->Repeat + 1); rr++)
			{
				tstConfig->RequestCount = 0;
				tstConfig->ResponseCount = 0;

				printf( "running test-case, %s ", tstConfig->APIName);
				
				if( tstConfig->Delay > 0)
				{
					int jj = 0;
					printf( " - delayed execution on - for %d secs  ", tstConfig->Delay);
					fflush( stdout);
					
					for( jj = 0; jj < tstConfig->Delay; jj++) 
					{
						usleep( 999999);
						printf( ".");
						fflush( stdout);
					}
				}
				printf( "\n");
				
				
				if( loadtestinfo->ontestcasebegin > 0)
				{
					loadtestinfo->ontestcasebegin( loadtestinfo, tstConfig);
				}
				
				//__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "API-NAME=%s TPS=%d %s|%d", tstConfig->APIName, tstConfig->TPS, __FILE__, __LINE__);
				
				while( tstConfig->RequestCount < tstConfig->TotalCount)
				{
					if( (tstConfig->RequestCount - tstConfig->ResponseCount) < tstConfig->Concurrent)
					{
						testItem = (__si_loadtestitem_t *) __si_pool_allocate( loadtestinfo->testItemPool);
						
						if(!testItem)
							continue;
						
						// __si_log( SI_APP_LOG, 0, SI_LOG_DEBUG, "Allocated %p Available=%u Total=%u  <%s|%s|%d>", testItem, 
							// loadtestinfo->testItemPool->Available, loadtestinfo->testItemPool->Total, 
							// __FILE__, __FUNCTION__, __LINE__);
						
						testItem->testConfig 	= tstConfig;
						testItem->Parent 		= loadtestinfo;
						
						pthread_mutex_lock( &testItem->testConfig->RequestCountLock);
						testItem->ReqNo 		= tstConfig->RequestCount;					
						// push item to execute test
						__si_core_queue_item( loadtestinfo->queue, testItem);
						tstConfig->RequestCount++;
						pthread_mutex_unlock( &testItem->testConfig->RequestCountLock);
						
						if( tstConfig->TPS > 0)
						{
							z++;
							if( z >= tstConfig->TPS)
							{
								// __si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "Sleeping now API-NAME=%s TPS=%d SleepTime=%u M-CNT=%u REQ-CNT=%u RSP-CNT=%u  %s|%d", 
									// tstConfig->APIName, tstConfig->TPS, tstConfig->SleepTime, tstConfig->RequestCount-j, 
									// tstConfig->RequestCount, tstConfig->ResponseCount,
									// __FILE__, __LINE__);
								
								__si_nanosleep( tstConfig->SleepTime);
								z = 0;
								j = tstConfig->RequestCount;
							}
						}
					} 
					else 
					{
						pthread_mutex_lock( &loadtestinfo->CallSemPostLock);
						loadtestinfo->CallSemPost++;
						pthread_mutex_unlock( &loadtestinfo->CallSemPostLock);
						
						sem_wait( &loadtestinfo->sem_lock);
					}
				}
				
				while( tstConfig->ResponseCount < tstConfig->RequestCount)
				{
					printf( "waiting for api=%s .. sent-request=%d received-responses=%d\n" , tstConfig->APIName,
						tstConfig->RequestCount, tstConfig->ResponseCount);
					
					usleep( 999999);
					fflush( stdout);
				}
				
				printf( "Completed load for API=%s  %s|%d\n\n", tstConfig->APIName, __FILE__, __LINE__);
			}
		}
	}
	else if(loadtestinfo->TestCaseExecutionType == 2)
	{
		int i = 0;
		int j = 0;
		int z = 0;
		long totReqCount = 0;
		
		for( i = 0; i < loadtestinfo->testConfigCount; i++)
		{
			totReqCount += loadtestinfo->testConfig[i]->TotalCount;
		}
		
		printf("TestCaseExecutionType=%d totReqCount=%ld PoolTotal=%d  %s|%d\n", 
			loadtestinfo->TestCaseExecutionType, totReqCount, loadtestinfo->testItemPool->Total, __FILE__, __LINE__);
		
		__si_test_config_t * tstConfig = NULL;
		
		i = 0;
		
		while( i < totReqCount)
		{
			for( j = 0; j < loadtestinfo->testConfigCount; j++)
			{	
				__si_test_config_t * tstConfig = loadtestinfo->testConfig[j];

				if( loadtestinfo->ontestcasebegin > 0)
				{
					loadtestinfo->ontestcasebegin( loadtestinfo, tstConfig);
				}
				

				if( tstConfig->RequestCount >= tstConfig->TotalCount)
					continue;

				if( (loadtestinfo->RequestCount - loadtestinfo->ResponseCount) < loadtestinfo->Concurrent)
				{
					testItem = (__si_loadtestitem_t *) __si_pool_allocate( loadtestinfo->testItemPool);
					
					if(!testItem)
						continue;
					
					testItem->testConfig 	= tstConfig;
					testItem->Parent 		= loadtestinfo;

					printf("%-50s Total=%-4d RequestCount=%d ResponseCount=%d LT-m=%d LT-c=%d LT-rqc=%d LT-rsc=%d  %s|%d\n", 
						tstConfig->APIName, tstConfig->TotalCount, tstConfig->RequestCount, tstConfig->ResponseCount, 
						(loadtestinfo->RequestCount - loadtestinfo->ResponseCount), loadtestinfo->Concurrent, 
						loadtestinfo->RequestCount, loadtestinfo->ResponseCount, 
						__FILE__, __LINE__);

					pthread_mutex_lock( &loadtestinfo->RequestCountLock);
					
					testItem->ReqNo 		= loadtestinfo->RequestCount;		
					// push item to execute test		
					__si_core_queue_item( loadtestinfo->queue, testItem);		
					loadtestinfo->RequestCount++;
					tstConfig->RequestCount++;
					
					pthread_mutex_unlock( &loadtestinfo->RequestCountLock);

					
					
				}
				else
				{
					pthread_mutex_lock( &loadtestinfo->CallSemPostLock);
					loadtestinfo->CallSemPost++;
					pthread_mutex_unlock( &loadtestinfo->CallSemPostLock);
					
					printf("sem_wait %s|%d\n", __FILE__, __LINE__);
					sem_wait( &loadtestinfo->sem_lock);
				}
				
				/*
				if( (loadtestinfo->RequestCount - loadtestinfo->ResponseCount) < loadtestinfo->Concurrent)
				{
					testItem = (__si_loadtestitem_t *) __si_pool_allocate( loadtestinfo->testItemPool);
					
					if(!testItem)
						continue;
					
					testItem->testConfig 	= tstConfig;
					testItem->Parent 		= loadtestinfo;
					
					
					
					pthread_mutex_lock( &loadtestinfo->RequestCountLock);
					testItem->ReqNo 		= loadtestinfo->RequestCount;					
					__si_core_queue_item( loadtestinfo->queue, testItem);
					loadtestinfo->RequestCount++;
					tstConfig->RequestCount++;
					pthread_mutex_unlock( &loadtestinfo->RequestCountLock);
					
					if( loadtestinfo->TPS > 0)
					{
						z++;
						if( z >= loadtestinfo->TPS)
						{
							printf("Sleeping now API-NAME=%s TPS=%d SleepTime=%u M-CNT=%u REQ-CNT=%u RSP-CNT=%u  %s|%d\n", 
								tstConfig->APIName, loadtestinfo->TPS, loadtestinfo->SleepTime, loadtestinfo->RequestCount-j, 
								loadtestinfo->RequestCount, loadtestinfo->ResponseCount,
								__FILE__, __LINE__);
							__si_nanosleep( loadtestinfo->SleepTime);
							z = 0;
							j = loadtestinfo->RequestCount;
						}
					}
				}
				else 
				{
					pthread_mutex_lock( &loadtestinfo->CallSemPostLock);
					loadtestinfo->CallSemPost++;
					pthread_mutex_unlock( &loadtestinfo->CallSemPostLock);
					
					sem_wait( &loadtestinfo->sem_lock);
				}
				*/
				
				
			}
			i++;
		}
		
		while( loadtestinfo->ResponseCount < loadtestinfo->RequestCount)
		{
			printf("waiting for responses TReqCnt=%d TRspCnt=%d \n", loadtestinfo->ResponseCount , loadtestinfo->RequestCount);
			usleep( 555555);
		}
		printf( "\nCompleted load-E2 [%d|%d] TC=%ld %s|%d\n", loadtestinfo->RequestCount, loadtestinfo->ResponseCount, totReqCount, __FILE__, __LINE__);
	}
	
	return NULL;
}
	

int __si_loadtest_create2( int noOfThreads, __si_loadtestinfo_t * loadtestinfo)
{
	loadtestinfo->CallSemPost = 0;
	sem_init( &loadtestinfo->sem_lock, 0, 0);
	pthread_mutex_init( &loadtestinfo->contextLock, NULL);

	pthread_mutex_init( &loadtestinfo->RequestCountLock, NULL);
	pthread_mutex_init( &loadtestinfo->ResponseCountLock, NULL);
	pthread_mutex_init( &loadtestinfo->CallSemPostLock, NULL);
	
	//printf("locks initalized\n");
	
	__si_test_config_t * testConfig = NULL;
	int testConfigCount2 = loadtestinfo->testConfigCount;
	
	int i = 0;
	for( i = 0; i < testConfigCount2; i++)
	{
		testConfig = loadtestinfo->testConfig[i];
		
		pthread_mutex_init( &testConfig->RequestCountLock, NULL);
		pthread_mutex_init( &testConfig->ResponseCountLock, NULL);
		
		if( loadtestinfo->Concurrent < testConfig->Concurrent)
		{
			loadtestinfo->Concurrent = testConfig->Concurrent;
		}
	}

	loadtestinfo->testItemPool = __si_pool_create( "testItemPool,sirik_core.c", sizeof(__si_loadtestitem_t), loadtestinfo->Concurrent, 0);
	printf("creating load-test queue noOfThreads=%d Concurrent=%d %s|%d\n", noOfThreads, loadtestinfo->Concurrent, __FILE__, __LINE__);
	__si_core_create_queue( &loadtestinfo->queue, __si_loadtest_exec2, noOfThreads, loadtestinfo->Concurrent * 2);
	printf("creating load-test threads  %s|%d\n", __FILE__, __LINE__);
	__si_create_pthread2( __si_loadtestinfo_run2, loadtestinfo, "si-2loadtst");
	
	return 1;
}

// strPlmn must be 6 bytes
// plmn must be 3 bytes
void __si_str_to_plmn( char * strPlmn, char * plmn )
{
	uint32_t uplmn = 0;
	uplmn = strtol( strPlmn, NULL, 16);
	
	plmn[0] = ((uplmn >> 16) & 0xFF);
	plmn[1] = ((uplmn >> 8) & 0xFF);
	plmn[2] = ((uplmn) & 0xFF);
}

void __si_plmn_to_str( char * strPlmn, char * plmn )
{
	sprintf( strPlmn, "%02X%02X%02X", plmn[0] & 0xFF, plmn[1] & 0xFF, plmn[2] & 0xFF);
}

int __si_ip_get_version( char * ipAddr )
{
	if( __si_indexOf( ipAddr, strlen(ipAddr), '.') > 0)
	{
		return 4;
	}
	else if( __si_indexOf( ipAddr, strlen(ipAddr), ':') >= 0)
	{
		return 6;
	}
	return -1;
}



uint32_t __si_hash_string__djb2( uint8_t * str)
{
	uint32_t hash = 5381;
    uint8_t c;
    
	while ((c = *str++))
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
    
	return hash;
}

uint32_t __si_hash_string__fnv( uint8_t * key, int len)
{
	uint32_t h = 3323198485;
	h ^= 2166136261UL;
    const uint8_t* data = (const uint8_t*)key;
    for(int i = 0; i < len; i++)
    {
        h ^= data[i];
        h *= 16777619;
    }
    return h;
}

//       __si_hash_string__murmur32  
uint32_t __si_hash_string__murmur32( uint8_t * str)
{
	uint32_t h = 3323198485;
	for (; *str; ++str) 
	{
        h ^= *str;
        h *= 0x5bd1e995;
        h ^= h >> 15;
    }
    return h;
}

uint64_t __si_hash_string__murmur64( uint8_t * key)
{
	uint64_t h = 525201411107845655;
	for (;*key;++key) 
	{
		h ^= *key;
		h *= 0x5bd1e9955bd1e995;
		h ^= h >> 47;
	}
	return h;
}


uint32_t __si_hash_string__krv2( uint8_t * s)
{
	uint32_t hashval = 0;
    for (hashval = 0; *s != '\0'; s++)
        hashval = *s + 31*hashval;
    return hashval;
}

uint32_t __si_hash_string__jenkins( uint8_t * str, int len)
{
	uint32_t hash, i;
    for(hash = i = 0; i < len; ++i)
    {
        hash += str[i];
        hash += (hash << 10);
        hash ^= (hash >> 6);
    }
    hash += (hash << 3);
    hash ^= (hash >> 11);
    hash += (hash << 15);
    return hash;
}

uint32_t __si_hash_string__crc32b( uint8_t * str)
{
	unsigned int byte, crc, mask;
    int i = 0, j;
    crc = 0xFFFFFFFF;
    while (str[i] != 0) {
        byte = str[i];
        crc = crc ^ byte;
        for (j = 7; j >= 0; j--) {
            mask = -(crc & 1);
            crc = (crc >> 1) ^ (0xEDB88320 & mask);
        }
        i = i + 1;
    }
    return ~crc;
}

uint32_t __si__rotl32( uint32_t x, int32_t bits)
{
	return x<<bits | x>>(32-bits);
}

uint32_t __si_hash_string__coffin( uint8_t * input)
{
	uint32_t result = 0x55555555;
    while (*input) { 
        result ^= *input++;
        result = __si__rotl32(result, 5);
    }
    return result;
}

uint32_t __si_hash_string__x17( uint8_t * key, int len)
{
	uint32_t h = 3323198485;
	const uint8_t * data = (const uint8_t*)key;
    for (int i = 0; i < len; ++i)
    {
        h = 17 * h + (data[i] - ' ');
    }
    return h ^ (h >> 16);
}

__si_linear_hash_table_t * __si_linear_hash_table__create( uint8_t Type, uint8_t KeyLen, uint32_t capacity)
{
	__si_linear_hash_table_t * hashTable = (__si_linear_hash_table_t *)malloc( sizeof(__si_linear_hash_table_t));
	memset( hashTable, 0, sizeof(__si_linear_hash_table_t));
	
	pthread_mutex_init( &hashTable->Lock, NULL);
	hashTable->KeyLen = KeyLen;
	hashTable->ToalRowCount = capacity;
	hashTable->UsedRowCount = 0;
	hashTable->table = (__si_linear_hash_row_t **) malloc( sizeof(__si_linear_hash_row_t*) * capacity);
	
	uint8_t * rows = malloc( sizeof(__si_linear_hash_row_t) * capacity);
	
	int i = 0;
	for( i = 0; i < capacity; i++)
	{
		hashTable->table[i] = (__si_linear_hash_row_t*) rows;
		
		hashTable->table[i]->Head 		= NULL;
		hashTable->table[i]->Current 	= NULL;
		hashTable->table[i]->Count		= 0;
		pthread_mutex_init( &hashTable->table[i]->Lock, NULL);
		
		rows += sizeof(__si_linear_hash_row_t);
	}
	
	return hashTable;
}


__si_linear_hash_col_t * __si_linear_hash_table__col( __si_linear_hash_table_t * table, __si_linear_hash_row_t * row, void * data)
{
	__si_linear_hash_col_t * h_col = (__si_linear_hash_col_t *)__si_allocM( sizeof(__si_linear_hash_col_t));
	memset( h_col, 0, sizeof(__si_linear_hash_col_t));
	
	h_col->Next = NULL;
	h_col->Prev = NULL;
	h_col->key = 0;
	h_col->val = data;
	
	if(!row->Head) 
	{
		row->Head = row->Current = h_col;
	} 
	else 
	{
		h_col->Prev = row->Current;
		
		row->Current->Next = h_col;
		row->Current = h_col;
	}
	row->Count++;

	return h_col;
}

uint8_t __si_linear_hash_table__add_int32( __si_linear_hash_table_t * table, int32_t key, void * data)
{
	uint32_t index = ( key % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = __si_linear_hash_table__col( table, row, data);
	col->key = (uint8_t*)__si_allocM( 4);
	*((int32_t*)col->key) = key;
	
	pthread_mutex_unlock( &row->Lock);
	
	return 0;
}

uint8_t __si_linear_hash_table__add_uint32( __si_linear_hash_table_t * table, uint32_t key, void * data)
{
	uint32_t index = ( key % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = __si_linear_hash_table__col( table, row, data);
	col->key = (uint8_t*)__si_allocM( 4);
	*((uint32_t*)col->key) = key;
	
	pthread_mutex_unlock( &row->Lock);

	return 0;
}

uint8_t __si_linear_hash_table__add_int64( __si_linear_hash_table_t * table, int64_t key, void * data)
{
	uint32_t index = ( key % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = __si_linear_hash_table__col( table, row, data);
	col->key = (uint8_t*)__si_allocM( 8);
	*((int64_t*)col->key) = key;
	
	pthread_mutex_unlock( &row->Lock);
	return 0;
}

uint8_t __si_linear_hash_table__add_uint64( __si_linear_hash_table_t * table, uint64_t key, void * data)
{
	uint32_t index = ( key % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = __si_linear_hash_table__col( table, row, data);
	col->key = (uint8_t*)__si_allocM( 8);
	*((uint64_t*)col->key) = key;
	
	pthread_mutex_unlock( &row->Lock);
	
	return 0;
}

uint8_t __si_linear_hash_table__add_string( __si_linear_hash_table_t * table, char * key, int keylen, void * data)
{
	if( keylen >= table->KeyLen) return -1;
	
	uint32_t hashKey = __si_hash_string__murmur32( key);
	
	uint32_t index = ( hashKey % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = __si_linear_hash_table__col( table, row, data);

	col->key = (uint8_t*)__si_allocM( table->KeyLen);
	memset( col->key, 0, table->KeyLen);
	
	if( keylen < table->KeyLen) {
		memcpy( col->key, key, keylen);
	} else {
		memcpy( col->key, key, table->KeyLen);
	}
	
	pthread_mutex_unlock( &row->Lock);
	
	return 0;
}


void __si_linear_hash_table__del_col( __si_linear_hash_col_t * col, __si_linear_hash_row_t * row)
{
	__si_linear_hash_col_t * prevCol = NULL;
	__si_linear_hash_col_t * nextCol = NULL;
	
	if( col->Prev)
	{
		prevCol = col->Prev;
	}
	
	if( col->Next)
	{
		nextCol = col->Next;
	}
	
	col->Prev = NULL; 
	col->Next = NULL; 
	
	if( prevCol)
	{
		prevCol->Next = nextCol;
	}
	
	if( nextCol)
	{
		nextCol->Prev = prevCol;
	}
	
	if( row->Head == col)
		row->Head = col->Next;

	if( row->Current == col)
		row->Current = col->Next;
	
	row->Count--;
	__si_freeM( (uint8_t *)col->key);
	__si_freeM( (uint8_t *)col);
	col->key = NULL;
	col = NULL;
}

uint8_t __si_linear_hash_table__del_int32( __si_linear_hash_table_t * table, int32_t key)
{
	uint32_t index = ( key % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = row->Head;
	
	while( col)
	{
		if( *((int32_t*)col->key) == key)
		{
			__si_linear_hash_table__del_col( col, row);
			
			pthread_mutex_unlock( &row->Lock);
			return 1;
		}
		col = col->Next;
	}
	pthread_mutex_unlock( &row->Lock);
	
	return 0;
}

uint8_t __si_linear_hash_table__del_uint32( __si_linear_hash_table_t * table, uint32_t key)
{
	uint32_t index = ( key % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = row->Head;
	
	while( col)
	{
		if( *((uint32_t*)col->key) == key)
		{
			__si_linear_hash_table__del_col( col, row);
			
			pthread_mutex_unlock( &row->Lock);
			return 1;
		}
		col = col->Next;
	}
	pthread_mutex_unlock( &row->Lock);
	
	return 0;
}

uint8_t __si_linear_hash_table__del_int64( __si_linear_hash_table_t * table, int64_t key)
{
	uint32_t index = ( key % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = row->Head;
	
	while( col)
	{
		if( *((int64_t*)col->key) == key)
		{
			__si_linear_hash_table__del_col( col, row);
			
			pthread_mutex_unlock( &row->Lock);
			return 1;
		}
		col = col->Next;
	}
	pthread_mutex_unlock( &row->Lock);
	
	return 0;
}

uint8_t __si_linear_hash_table__del_uint64( __si_linear_hash_table_t * table, uint64_t key)
{
	uint32_t index = ( key % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = row->Head;
	
	while( col)
	{
		if( *((uint64_t*)col->key) == key)
		{
			__si_linear_hash_table__del_col( col, row);
			
			pthread_mutex_unlock( &row->Lock);
			return 1;
		}
		col = col->Next;
	}
	pthread_mutex_unlock( &row->Lock);
	
	return 0;
}

uint8_t __si_linear_hash_table__del_string( __si_linear_hash_table_t * table, char * key, int keylen)
{
	uint32_t hashKey = __si_hash_string__murmur32( key);

	uint32_t index = ( hashKey % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = row->Head;
	while( col)
	{
		if( __si_memcmp2( col->key, keylen, key, keylen) == 0)
		{
			__si_linear_hash_table__del_col( col, row);
			pthread_mutex_unlock( &row->Lock);
			return 1;
		}
		col = col->Next;
	}
	pthread_mutex_unlock( &row->Lock);
	return 0;
}

uint8_t __si_linear_hash_table__fnd_int32( __si_linear_hash_table_t * table, int32_t key, void ** data)
{
	uint32_t index = ( key % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];

	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = row->Head;
	
	while( col)
	{
		if( *((int32_t*)col->key) == key)
		{
			*data = col->val;
			pthread_mutex_unlock( &row->Lock);
			return 1;
		}
		
		col = col->Next;
	}
	pthread_mutex_unlock( &row->Lock);

	return 0;
}

uint8_t __si_linear_hash_table__fnd_uint32( __si_linear_hash_table_t * table, uint32_t key, void ** data)
{
	uint32_t index = ( key % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];

	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = row->Head;
	
	while( col)
	{
		if( *((uint32_t*)col->key) == key)
		{
			*data = col->val;
			pthread_mutex_unlock( &row->Lock);
			return 1;
		}
		
		col = col->Next;
	}
	pthread_mutex_unlock( &row->Lock);
	
	return 0;
}

uint8_t __si_linear_hash_table__fnd_int64( __si_linear_hash_table_t * table, int64_t key, void ** data)
{
	uint32_t index = ( key % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = row->Head;
	while( col)
	{
		if( *((uint32_t*)col->key) == key)
		{
			*data = col->val;
			pthread_mutex_unlock( &row->Lock);
			return 1;
		}
		col = col->Next;
	}
	pthread_mutex_unlock( &row->Lock);
	
	return 0;
}

uint8_t __si_linear_hash_table__fnd_uint64( __si_linear_hash_table_t * table, uint64_t key, void ** data)
{
	uint32_t index = ( key % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = row->Head;
	while( col)
	{
		if( *((uint64_t*)col->key) == key)
		{
			*data = col->val;
			pthread_mutex_unlock( &row->Lock);
			return 1;
		}
		col = col->Next;
	}
	pthread_mutex_unlock( &row->Lock);
	
	return 0;
}

uint8_t __si_linear_hash_table__fnd_string( __si_linear_hash_table_t * table, char * key, int keylen, void ** data)
{
	uint32_t hashKey = __si_hash_string__murmur32( key);

	uint32_t index = ( hashKey % table->ToalRowCount);
	__si_linear_hash_row_t * row = table->table[index];
	
	pthread_mutex_lock( &row->Lock);
	__si_linear_hash_col_t * col = row->Head;
	while( col)
	{
		if( __si_memcmp2( col->key, keylen, key, keylen) == 0)
		{
			*data = col->val;
			pthread_mutex_unlock( &row->Lock);
			return 1;
		}
		col = col->Next;
	}
	pthread_mutex_unlock( &row->Lock);
	return 0;
}




/*
	//Usage
	
	__init_sirik_core();				// Initialize Core
	__si_init_logger("./logs/");		// Set Logs Path		
*/












