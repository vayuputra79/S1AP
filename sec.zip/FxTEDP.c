#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <semaphore.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>
#include <unistd.h>
#include <signal.h>
#include <limits.h>
#include <poll.h>
#include <sys/epoll.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <error.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <net/if.h> 
#include <resolv.h>

#include "sirik_core.h"
#include "sirik_socket.h"
#include "FxDataPlane.h"

typedef struct FxMSAE FxMSAE_t;


// SAU -> Simultionous Active Users
#pragma pack(4)
typedef struct FxSAEFlow
{
	uint32_t DstIP;
	uint16_t DstPort;
	uint16_t SrcPort;
	uint32_t TCPSeqNo;
	uint64_t SentPackets;
	uint64_t SentBytes;
	uint64_t ReceivedPackets;
	uint64_t ReceivedBytes;
} FxSAEFlow_t;


#pragma pack(4)
typedef struct FxSAE
{
	struct FxSAE * Prev;
	struct FxSAE * Next;

	//struct FxSAE * UE_Prev;
	struct FxSAE * UE_Next;
	
	uint32_t UPF_Teid;
	uint32_t RAN_Teid;
	uint32_t UPF_IP;
	uint32_t UEIP;
	uint32_t PDUSessionId;
	
	uint32_t PacketsToSend;
	uint32_t SentPackets;
	time_t 	 PacketDuration;
	uint32_t SendType;
	uint32_t Action;

	uint32_t InPacket;
	uint32_t GTPSeqNo;
	uint32_t LastFlowId;
	uint32_t QosFlowIdentifier;
	
	
	FxSAEFlow_t Flows[5];
	
	uint32_t Attached;
	
} FxSAE_t;


#pragma pack(4)
typedef struct FxMSAE
{
	FxSAE_t * PacketHead;
	FxSAE_t * PacketCurrent;
	FxSAE_t * PacketLast;
	pthread_mutex_t packetLock;
	
	uint64_t Tick;
	uint64_t SentPacketsInSecond;
	uint64_t LastSentPacketsInSecond;
	
	uint64_t TotalSentPacketsInSecond;
	// uint64_t SentBytesInSecond;
	// uint64_t TotalSentBytesInSecond;
	
	uint32_t ActiveSessions;
	uint32_t TotalSessions;
	
} FxMSAE_t;


#pragma pack(4)
typedef struct FxTEDP
{
	int SAETotalCount;
	int SAETotalAvailable;
	
	
	FxSAE_t * SAEHead;
	FxSAE_t * SAECurrent;
	
	FxSAE_t * UE_SAEHead;
	FxSAE_t * UE_SAECurrent;

	
	SI_PowerTable * saeTable;
	uint32_t RAN_IP;
	pthread_mutex_t saeLock;
	
	FxSAE_t * PacketHead;
	FxSAE_t * PacketCurrent;
	FxSAE_t * PacketLast;
	pthread_mutex_t packetLock;
	
	FxMSAE_t MSAE[20];
	
	int CoreCount;
	uint64_t SentPackets;
	uint64_t SentBytes;
	uint64_t ReceivedPackets;
	uint64_t ReceivedBytes;
	
	uint32_t FlowCount;
	uint32_t DelayPacket;
	uint32_t DebugPacket;
	uint32_t LogUEStats;
	
	//Packets Per Second Per Core
	uint64_t PPSPC;
	
} FxTEDP_t;

FxTEDP_t * __fxTEDP = NULL;

void FxTEDP___on_accept( SI_Socket * siSocketChild, SI_Socket * siSocketParent)
{
	//printf("%s|%s|%d\n", __FILE__, __FUNCTION__, __LINE__);
	__si_log( SI_APP_LOG, 0, SI_LOG_DEBUG, "FxTEDP___on_accept  <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
}


void FxTEDP___on_close( SI_Socket * siSocketChild)
{
	//printf("%s|%s|%d\n", __FILE__, __FUNCTION__, __LINE__);
	__si_log( SI_APP_LOG, 0, SI_LOG_DEBUG, "FxTEDP___on_close  <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
}

void FxTEDP___handle_StopDataTraffic( FxDataPlaneRequest * request);
void FxTEDP___handle_StopAllDataTraffic( FxDataPlaneRequest * request);
void FxTEDP___handle_StartDataTraffic( FxDataPlaneRequest * request);

void __si_socket_engine_tcp_release_used_buffer( SI_Socket * siSocket);

void FxTEDP___on_buffer( SI_Socket * siSocketChild)
{
	//printf("%s|%s|%d\n", __FILE__, __FUNCTION__, __LINE__);
	
	if( siSocketChild->BufferLength == 0)
	{
		//printf("BufferLength=%d returning...\n", siSocketChild->BufferLength);
		__si_log( SI_APP_LOG, 0, SI_LOG_CRITICAL, "buffer size received length is zero %d, dropping buffer  <%s|%s|%d>", siSocketChild->BufferLength, __FILE__, __FUNCTION__, __LINE__);	
		return;
	}
	
	FxDataPlaneMessageHeader header;
	int i = 0;
	
	while(1)
	{
		header.MessageLength = 0;
		__si_socket_engine_tcp_get_sample_buffer( siSocketChild, (char *) &header, sizeof(FxDataPlaneMessageHeader));

		if( header.MessageLength == 0 && siSocketChild->BufferLength > 0)
		{
			printf("1-invalid message-header-length=%d  buffer-header-length=%d  %s|%d\n", header.MessageLength, siSocketChild->BufferLength, __FILE__, __LINE__);
			__si_log( SI_APP_LOG, 0, SI_LOG_CRITICAL, "invalid message-header-length=%d  buffer-header-length=%d  <%s|%s|%d>", header.MessageLength, siSocketChild->BufferLength, __FILE__, __FUNCTION__, __LINE__);
			exit(0);
		}

		//if( siSocketChild->BufferLength < header.MessageLength && siSocketChild->BufferLength > 0 || siSocketChild->BufferLength == 0)
		if( siSocketChild->BufferLength < header.MessageLength)
		{
			__si_log( SI_CMN_LOG, 0, SI_LOG_DEBUG, "InSufficent for Segment=%d BufferLength expected=%u received=%u <%s|%s|%d>", i, header.MessageLength, siSocketChild->BufferLength, __FILE__, __FUNCTION__, __LINE__);
			return;
			//break;
		}

		
		
		//printf("BufferLength=%u \n", siSocketChild->BufferLength);

		if( header.MessageLength > 10000)
		{
			printf("buffer size exceeded, received length %d\n", header.MessageLength);
			__si_log( SI_APP_LOG, 0, SI_LOG_CRITICAL, "buffer size exceeded, received length %d  <%s|%s|%d>", header.MessageLength, __FILE__, __FUNCTION__, __LINE__);	
			exit(0);
		}

		uint8_t * msg = __si_allocM( header.MessageLength);
		__si_socket_engine_tcp_get_buffer( siSocketChild, msg, header.MessageLength);
		__si_socket_engine_tcp_release_used_buffer( siSocketChild);
		
		((FxDataPlaneMessageHeader *)msg)->siSocket = (uint8_t *) siSocketChild;
		

		
		// printf( "Buf-Len=%d Msg-Len=%d Msg-Type=%d  i=%d  %s|%d\n", 
			// siSocketChild->BufferLength, header.MessageLength, header.MessageType, i, __FILE__, __LINE__);

		
		switch( header.MessageType)
		{
			case FxTEDP__MT__STOP_DATA_TRAFFIC_REQUEST:
				__si_core_queue( msg, (queue_handler) FxTEDP___handle_StopDataTraffic);
				break;
			case FxTEDP__MT__STOP_ALL_DATA_TRAFFIC_REQUEST:
				__si_core_queue( msg, (queue_handler) FxTEDP___handle_StopAllDataTraffic);
				break;
			case FxTEDP__MT__START_DATA_TRAFFIC_REQUEST:
				__si_core_queue( msg, (queue_handler) FxTEDP___handle_StartDataTraffic);
				break;
			default:
				__si_freeM( (uint8_t *) msg);
				break;
		}

		//usleep( 999999);
		i++;
	}
	
}



void FxTEDP___handle_StopDataTraffic( FxDataPlaneRequest * request)
{
	SI_Socket * siSocket = (SI_Socket *)request->Header.siSocket;
	__si_log( SI_APP_LOG, 0, SI_LOG_DEBUG, "StopDataTraffic UEId=%u PDUSessionId=%u <%s|%s|%d>", request->UEId, request->PDUSessionId, __FILE__, __FUNCTION__, __LINE__);	

	int senBytes = 0;
	if( senBytes <= 0)
	{
		__si_log( SI_APP_LOG, 0, SI_LOG_CRITICAL, "Error Sending Response senBytes=%d  <%s|%s|%d>", senBytes, __FILE__, __FUNCTION__, __LINE__);
	}
	__si_freeM( (uint8_t *) request);
}


void FxTEDP___handle_StopAllDataTraffic( FxDataPlaneRequest * request)
{
	SI_Socket * siSocket = (SI_Socket *)request->Header.siSocket;
	__si_log( SI_APP_LOG, 0, SI_LOG_DEBUG, "StopAllDataTraffic  <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);	

	int senBytes = 0;
	if( senBytes <= 0)
	{
		__si_log( SI_APP_LOG, 0, SI_LOG_CRITICAL, "Error Sending Response senBytes=%d  <%s|%s|%d>", senBytes, __FILE__, __FUNCTION__, __LINE__);
	}
	__si_freeM( (uint8_t *) request);
}


void FxTEDP___handle_StartDataTraffic( FxDataPlaneRequest * request)
{
	SI_Socket * siSocket = (SI_Socket *)request->Header.siSocket;
	
	char sUPFIP[30];
	char sRANIP[30];
	char sUEIP[30];

	memset( sUPFIP, 0, sizeof(sUPFIP));
	memset( sRANIP, 0, sizeof(sRANIP));
	memset( sUEIP, 0, sizeof(sUEIP));
	
	__si_core_convert_inttoipv4_2( htonl(request->UPFIP), sUPFIP);
	__si_core_convert_inttoipv4_2( htonl(request->RANIP), sRANIP);
	__si_core_convert_inttoipv4_2( htonl(request->UEIP), sUEIP);
	

	__si_log( SI_APP_LOG, 0, SI_LOG_DEBUG, "StartDataTraffic UEId=%lu PDUSessionId=%u UPFTeid=%u RANTeid=%u UPFIP=%u,%s RANIP=%u,%s UEIP=%u,%s  Action=%u NoOfPacketsToSend=%u Duration=%u PacketsPerSecond=%u PCapFileIndex=%u IMSI=%s  <%s|%s|%d>", 
		request->UEId, request->PDUSessionId, request->UPFTeid, 
		request->RANTeid, request->UPFIP, sUPFIP,
		request->RANIP, sRANIP, request->UEIP, sUEIP,
		request->Action, request->NoOfPacketsToSend, request->Duration, 
		request->PacketsPerSecond, request->PCapFileIndex, request->IMSI,
	__FILE__, __FUNCTION__, __LINE__);	

	//printf("Duration=%d\n", request->Duration);

	// char upfIp[30];
	// char ranIp[30];
	// memset( upfIp, 0, sizeof(upfIp));
	// memset( ranIp, 0, sizeof(ranIp));
	
	// __si_core_convert_inttoipv4_2( request->UPFIP, upfIp);	
	// __si_core_convert_inttoipv4_2( request->RANIP, ranIp);

	// printf("Received Request MessageNo=%u MessageType=%u MessageLength=%u UPF-Teid=%u RAN-Teid=%u UPF-IP=%s RAN-IP=%s\n", 
		// request->Header.MessageNo, request->Header.MessageType, 
		// request->Header.MessageLength, request->UPFTeid, 
		// request->RANTeid, upfIp, ranIp);

	uint32_t index = 0;
	
	if( __fxTEDP->CoreCount > 0)
	{
		index = request->UEIP % __fxTEDP->CoreCount;
	}

	if( FxTEDP__ACTION_STOP_ALL_PACKETS == request->Action)
	{
		if( __fxTEDP->CoreCount > 0)
		{
			pthread_mutex_lock( &__fxTEDP->MSAE[index].packetLock);
			
			FxSAE_t * saeitem = __fxTEDP->MSAE[index].PacketHead;

			while( saeitem)
			{
				//To Stop All Packets Nullify Information

				saeitem->SendType 		= 0;
				saeitem->PacketDuration = 0;
				saeitem->PacketsToSend 	= 0;
				saeitem->SentPackets	= 0;
				
				saeitem = saeitem->Next;
			}
			
			pthread_mutex_unlock( &__fxTEDP->MSAE[index].packetLock);
		}
		else
		{
			pthread_mutex_lock( &__fxTEDP->packetLock);
			
			FxSAE_t * saeitem = __fxTEDP->PacketHead;
			
			while( saeitem)
			{
				//To Stop All Packets Nullify Information

				saeitem->SendType 		= 0;
				saeitem->PacketDuration = 0;
				saeitem->PacketsToSend 	= 0;
				saeitem->SentPackets	= 0;
				
				saeitem = saeitem->Next;
			}
			
			pthread_mutex_unlock( &__fxTEDP->packetLock);
		}
		
		
		
		FxDataPlaneResponse response;
		memset( &response, 0, sizeof(FxDataPlaneResponse));

		response.Header.MessageNo		= request->Header.MessageNo;
		response.Header.MessageType		= FxTEDP__MT__START_DATA_TRAFFIC_RESPONSE;
		response.Header.MessageLength 	= sizeof(FxDataPlaneResponse);
		response.UEId					= request->UEId;
		response.ResponseStatus			= 1;
		
		int senBytes = siSocket->Send( siSocket, (char *)&response, response.Header.MessageLength, 0);
		if( senBytes <= 0)
		{
			__si_log( SI_APP_LOG, 0, SI_LOG_CRITICAL, "Error Sending Response senBytes=%d  <%s|%s|%d>", senBytes, __FILE__, __FUNCTION__, __LINE__);
		}
		__si_freeM( (uint8_t *) request);
	
		return;
	}
	else if( FxTEDP__ACTION_STOP_PACKETS == request->Action)
	{
		char key0[4];
		//memset( key0, 0, 20);
		//sprintf( key0, "%u-%u", request->UEIP, request->PDUSessionId);	//each session will have unique ip
		memcpy( key0, (char *)&request->UEIP, 4);
		//printf("key0=%s\n", key0);
		FxSAE_t * saeItem0 = NULL;
		__si_power_table_fnd( __fxTEDP->saeTable, key0, 4, (uint8_t **) &saeItem0);
		
		if( saeItem0)
		{
			saeItem0->SendType = 0;
			saeItem0->SentPackets = 0;
			saeItem0->PacketDuration = 0;
			saeItem0->PacketsToSend = 0;
		}
		
		__si_freeM( (uint8_t *) request);
		return;
	}
	
	if( request->NoOfPacketsToSend == 0 && request->Duration == 0)
	{
		__si_log( SI_APP_LOG, 0, SI_LOG_CRITICAL, "Supported NoOfPacketsToSend or Duration, both got zero <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
		return;
	}


	pthread_mutex_lock( &__fxTEDP->saeLock);

	char key[4];
	//memset( key, 0, 20);
	//sprintf( key, "%u-%u", request->UEIP, request->PDUSessionId);
	memcpy( key, (char *)&request->UEIP, 4);
	
	//__si_print_buffer( key, 4);
	//printf("key=%s %d\n", key, request->UEIP);
	
	FxSAE_t * saeItem = NULL;
	__si_power_table_fnd( __fxTEDP->saeTable, key, 4, (uint8_t **) &saeItem);
	
	int j = 0;
	
	if(saeItem)
	{
		saeItem->PacketsToSend	+= request->NoOfPacketsToSend;
	}
	else
	{
		if( __fxTEDP->SAEHead)
		{
			saeItem = __fxTEDP->SAEHead;
			//memset( saeItem, 0, sizeof(FxSAE_t));
			
			saeItem->Prev 				= NULL;
			saeItem->UE_Next 			= NULL;
			saeItem->UPF_Teid			= request->UPFTeid;
			saeItem->RAN_Teid			= request->RANTeid;
			saeItem->UPF_IP				= request->UPFIP;
			saeItem->PDUSessionId 		= request->PDUSessionId;	
			saeItem->UEIP				= request->UEIP;
			saeItem->PacketsToSend		= request->NoOfPacketsToSend;
			saeItem->SentPackets		= 0;
			saeItem->InPacket 			= 0;
			saeItem->GTPSeqNo 			= 0;
			saeItem->LastFlowId 		= 0;
			saeItem->Attached			= 0;
			saeItem->QosFlowIdentifier	= 0;
			saeItem->Action				= 0;
			saeItem->SendType			= 0;
			saeItem->PacketDuration		= 0;
			saeItem->Next				= NULL;

	
	

			for( j = 0; j < __fxTEDP->FlowCount; j++)
			{
				//saeItem->Flows[j].DstIP 	= __si_core_getU32RANDRange( 0x0A0A0A0A, 0xC0C0C0C0);
				//saeItem->Flows[j].DstIP 	= htonl( __si_core_getU32RANDRange( j + 1, j + 2)) + (1 + j);
				saeItem->Flows[j].DstIP 	= htonl( j + 1) + (1 + j);
				saeItem->Flows[j].DstPort	= __si_core_getU16RANDRange( 6000, 10000);
				saeItem->Flows[j].SrcPort	= __si_core_getU16RANDRange( 6000, 10000);
				saeItem->Flows[j].TCPSeqNo  = 0;
				saeItem->Flows[j].SentPackets = 0;
				saeItem->Flows[j].SentBytes = 0;
				saeItem->Flows[j].ReceivedPackets = 0;
				saeItem->Flows[j].ReceivedBytes = 0;
			}
	
			__fxTEDP->SAETotalAvailable--;
			__fxTEDP->SAEHead = saeItem->Next;
			saeItem->Next = NULL;
			
			if(!__fxTEDP->UE_SAEHead)
			{
				__fxTEDP->UE_SAEHead = __fxTEDP->UE_SAECurrent = saeItem;
			}
			else
			{
				__fxTEDP->UE_SAECurrent->UE_Next = saeItem;
				__fxTEDP->UE_SAECurrent = saeItem;
			}
			
			
			__si_power_table_add( __fxTEDP->saeTable, key, 4, (uint8_t *)saeItem);
			
			//validated after doing key is based in UEIP
			//printf( "before NULL saeItem=%p\n", saeItem);
			//saeItem = NULL;
			//__si_power_table_fnd( __fxTEDP->saeTable, key, 4, (uint8_t **) &saeItem);
			//printf( "find saeItem=%p\n", saeItem);
		}
	}
	
	
	
	if(!saeItem)
	{
		__si_log( SI_APP_LOG, 0, SI_LOG_CRITICAL, "UE Pool Exausted <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
		return;
	}
	
	if( request->Action == FxTEDP__ACTION_SEND_GTP_ICMP_PACKET)
	{
		saeItem->QosFlowIdentifier = request->QosFlowIdentifier;
		//printf("QosFlowIdentifier=%u\n", saeItem->QosFlowIdentifier);
	}
	
	// saeItem->PacketDuration = 0;
	saeItem->Action = request->Action;

	if( request->NoOfPacketsToSend > 0)
	{
		saeItem->SendType 		= 1;
		saeItem->SentPackets	= 0;
		saeItem->PacketsToSend	= request->NoOfPacketsToSend;
		saeItem->PacketDuration = 0;
	}
	else if( request->Duration > 0) 
	{
		saeItem->SendType = 2;
		saeItem->PacketDuration = time(NULL) + request->Duration;
		saeItem->PacketsToSend = 0;
	}
	else
	{
		saeItem->SendType 		= 0;
		saeItem->PacketDuration = 0;
		saeItem->PacketsToSend 	= 0;	
		saeItem->SentPackets	= 0;		
	}
	
	// printf("SendType=%u NoOfPacketsToSend=%u PacketDuration=%ld\n", 
		// saeItem->SendType, request->NoOfPacketsToSend, saeItem->PacketDuration);
	
	pthread_mutex_unlock( &__fxTEDP->saeLock);

	// printf("IMSI=%s PacketsToSend=%u|%u PacketDuration=%u|%ld Action=%u\n", 
		// request->IMSI, request->NoOfPacketsToSend, saeItem->PacketsToSend, 
		// request->Duration, saeItem->PacketDuration, saeItem->Action);


	if( __fxTEDP->CoreCount == 0)
	{
		pthread_mutex_lock( &__fxTEDP->packetLock);
		
		if( saeItem->Attached == 0)
		{
			if(!__fxTEDP->PacketHead)
			{
				__fxTEDP->PacketHead = __fxTEDP->PacketCurrent = saeItem;
			}
			else
			{
				saeItem->Prev = __fxTEDP->PacketCurrent;

				__fxTEDP->PacketCurrent->Next = saeItem;
				__fxTEDP->PacketCurrent = saeItem;
			}
			saeItem->Attached = 1;
		}
		
		pthread_mutex_unlock( &__fxTEDP->packetLock);
	}
	else
	{
		pthread_mutex_lock( &__fxTEDP->MSAE[index].packetLock);
		
		if( saeItem->Attached == 0)
		{
			if(!__fxTEDP->MSAE[index].PacketHead)
			{
				__fxTEDP->MSAE[index].PacketHead = __fxTEDP->MSAE[index].PacketCurrent = saeItem;
			}
			else
			{
				saeItem->Prev = __fxTEDP->MSAE[index].PacketCurrent;

				__fxTEDP->MSAE[index].PacketCurrent->Next = saeItem;
				__fxTEDP->MSAE[index].PacketCurrent = saeItem;
			}
			
			//__fxTEDP->MSAE[index].ActiveSessions++;
			__fxTEDP->MSAE[index].TotalSessions++;
			saeItem->Attached = 1;
		}
		
		pthread_mutex_unlock( &__fxTEDP->MSAE[index].packetLock);
	}
	
	FxDataPlaneResponse response;
	memset( &response, 0, sizeof(FxDataPlaneResponse));

	response.Header.MessageNo		= request->Header.MessageNo;
	response.Header.MessageType		= FxTEDP__MT__START_DATA_TRAFFIC_RESPONSE;
	response.Header.MessageLength 	= sizeof(FxDataPlaneResponse);
	response.UEId					= request->UEId;
	response.ResponseStatus			= 1;
	
	int senBytes = siSocket->Send( siSocket, (char *)&response, response.Header.MessageLength, 0);
	if( senBytes <= 0)
	{
		__si_log( SI_APP_LOG, 0, SI_LOG_CRITICAL, "Error Sending Response senBytes=%d  <%s|%s|%d>", senBytes, __FILE__, __FUNCTION__, __LINE__);
	}
	__si_freeM( (uint8_t *) request);
}


uint32_t FxTEDP__GetSessionCount( int coreIndex)
{
	if( coreIndex < 20)
	{
		return __fxTEDP->MSAE[ coreIndex].TotalSessions;
	}

	return 0;
}

void FxTEDP__GetPacketInfo( uint8_t ** sPtr, uint32_t * upfTeid, uint32_t * ranTeid, 
	uint32_t * upfip, uint32_t * flowId, uint32_t * gtpSeqNo, uint32_t * tcpSeqNo, 
	uint32_t * srcip, uint32_t * dstip, uint16_t * srcport, uint16_t * dstport, uint8_t * protocol)
{

	FxSAE_t * saeItem = NULL;
	
	pthread_mutex_lock( &__fxTEDP->packetLock);
	if(__fxTEDP->PacketLast) {
		__fxTEDP->PacketLast = __fxTEDP->PacketLast->Next;
	}
	if(!__fxTEDP->PacketLast) {
		__fxTEDP->PacketLast = __fxTEDP->PacketHead;
	}
	saeItem = __fxTEDP->PacketLast;
	pthread_mutex_unlock( &__fxTEDP->packetLock);

	if(saeItem)
	{
		*sPtr 		= (uint8_t *)saeItem;
		*upfTeid 	= saeItem->UPF_Teid;
		*ranTeid 	= saeItem->RAN_Teid;
		*upfip 		= saeItem->UPF_IP;
		
		if( saeItem->LastFlowId >= __fxTEDP->FlowCount)
		{
			saeItem->LastFlowId = 0;
		}
		
		*flowId 	= saeItem->LastFlowId;
		*gtpSeqNo 	= saeItem->GTPSeqNo;
		*tcpSeqNo	= saeItem->Flows[*flowId].TCPSeqNo;
		*srcip		= saeItem->UEIP;
		*dstip		= saeItem->Flows[*flowId].DstIP;
		*dstport	= saeItem->Flows[*flowId].DstPort;
		*srcport	= saeItem->Flows[*flowId].SrcPort;
		
		*protocol	= 6;
		
		if( saeItem->Action == 6) {
			*protocol	= 1;
		}

		saeItem->LastFlowId++;
	}
}


void FxTEDP__GetPacketInfo2( uint8_t ** sPtr, uint32_t * upfTeid, uint32_t * ranTeid, 
	uint32_t * upfip, uint32_t * flowId, uint32_t * gtpSeqNo, uint32_t * tcpSeqNo, 
	uint32_t * srcip, uint32_t * dstip, uint16_t * srcport, uint16_t * dstport, uint8_t * protocol, uint8_t * qosFlowId, uint32_t coreId)
{

	FxSAE_t * saeItem = NULL;
	
	if( __fxTEDP->CoreCount > 0)
	{
		pthread_mutex_lock( &__fxTEDP->MSAE[coreId].packetLock);
		if(__fxTEDP->MSAE[coreId].PacketLast) {
			__fxTEDP->MSAE[coreId].PacketLast = __fxTEDP->MSAE[coreId].PacketLast->Next;
		}
		if(!__fxTEDP->MSAE[coreId].PacketLast) {
			__fxTEDP->MSAE[coreId].PacketLast = __fxTEDP->MSAE[coreId].PacketHead;
		}
		saeItem = __fxTEDP->MSAE[coreId].PacketLast;
		pthread_mutex_unlock( &__fxTEDP->MSAE[coreId].packetLock);
	}
	else
	{
		pthread_mutex_lock( &__fxTEDP->packetLock);
		if(__fxTEDP->PacketLast) {
			__fxTEDP->PacketLast = __fxTEDP->PacketLast->Next;
		}
		if(!__fxTEDP->PacketLast) {
			__fxTEDP->PacketLast = __fxTEDP->PacketHead;
		}
		saeItem = __fxTEDP->PacketLast;
		pthread_mutex_unlock( &__fxTEDP->packetLock);
	}

	if(saeItem)
	{
		time_t timeVal_1 = time(NULL);

		if( saeItem->SendType == 0 || (saeItem->SentPackets >= saeItem->PacketsToSend && saeItem->SendType == 1) || (timeVal_1 >= saeItem->PacketDuration && saeItem->SendType == 2))
		{
			*sPtr = NULL;
			return;
		}
		
		*sPtr 		= (uint8_t *)saeItem;
		*upfTeid 	= saeItem->UPF_Teid;
		*ranTeid 	= saeItem->RAN_Teid;
		*upfip 		= saeItem->UPF_IP;
		
		if( saeItem->LastFlowId >= __fxTEDP->FlowCount)
		{
			saeItem->LastFlowId = 0;
		}
		
		*flowId 	= saeItem->LastFlowId;
		*gtpSeqNo 	= saeItem->GTPSeqNo;
		*tcpSeqNo	= saeItem->Flows[*flowId].TCPSeqNo;
		*srcip		= saeItem->UEIP;
		*dstip		= saeItem->Flows[*flowId].DstIP;
		*dstport	= saeItem->Flows[*flowId].DstPort;
		*srcport	= saeItem->Flows[*flowId].SrcPort;
		
		*protocol	= 6;
		
		if( saeItem->Action == 6) {
			*protocol	= 1;
		}
		
		if( __fxTEDP->DelayPacket > 0)
		{
			int secs = ( __fxTEDP->DelayPacket > 5) ? 5 : __fxTEDP->DelayPacket;
			int i = 0;
			
			for( i = 0; i < secs; i++)
			{
				usleep( 999999);
			}
		}

		
		if( __fxTEDP->DebugPacket > 0)
		{
			char sUEIP[30];
			char sDSTIP[30];
			
			memset( sUEIP, 0, sizeof(sUEIP));
			memset( sDSTIP, 0, sizeof(sDSTIP));
			
			__si_core_convert_inttoipv4_2( htonl( saeItem->UEIP), sUEIP);	
			__si_core_convert_inttoipv4_2( htonl( *dstip), sDSTIP);

			__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "Packet  %-20s   %-20s   %-4d   %-4d   %-4d   %-4d   %-4d", 
				sUEIP, sDSTIP, *srcport , *dstport, saeItem->SendType, saeItem->PacketsToSend, saeItem->SentPackets);
		}

		saeItem->LastFlowId++;
		
		
		
		if( __fxTEDP->PPSPC > 0)
		{
			if( __fxTEDP->MSAE[coreId].SentPacketsInSecond > __fxTEDP->PPSPC)
			{
				usleep( 999999);				
				__fxTEDP->MSAE[coreId].SentPacketsInSecond = 0;
			}
		} 
		else if( __fxTEDP->MSAE[coreId].Tick != __si_core_get_server_timer_tick())
		{
			__fxTEDP->MSAE[coreId].LastSentPacketsInSecond = __fxTEDP->MSAE[coreId].SentPacketsInSecond;
			__fxTEDP->MSAE[coreId].SentPacketsInSecond = 0;
			__fxTEDP->MSAE[coreId].Tick = __si_core_get_server_timer_tick();
		}
		
		__fxTEDP->MSAE[coreId].SentPacketsInSecond++;
		__fxTEDP->MSAE[coreId].TotalSentPacketsInSecond++;
		
	}
}


void FxTEDP__UpdatePacketInfo( uint8_t * sPtr, uint32_t flowId, uint32_t pktlen)
{
	if(!sPtr) return;
	
	FxSAE_t * saeItem = (FxSAE_t *)sPtr;

	saeItem->GTPSeqNo++;
	saeItem->Flows[flowId].TCPSeqNo += pktlen;
	saeItem->Flows[flowId].SentPackets++;
	saeItem->Flows[flowId].SentBytes += pktlen;


	saeItem->SentPackets++;
	//time_t timeVal_1 = time(NULL);
	
	//printf( "timeVal_1=%ld < saeItem->PacketDuration=%ld\n", timeVal_1, saeItem->PacketDuration);

	// printf("SendType=%d SentPackets=%u PacketsToSend=%u PacketDuration=%lu timeVal_1=%lu \n", 
		// saeItem->SendType, saeItem->SentPackets, saeItem->PacketsToSend, 
		// saeItem->PacketDuration, timeVal_1);
	
	/*
	
	if( saeItem->SendType == 0 || (saeItem->SentPackets >= saeItem->PacketsToSend && saeItem->SendType == 1) || (timeVal_1 >= saeItem->PacketDuration && saeItem->SendType == 2))
	{
		
		pthread_mutex_lock( &__fxTEDP->packetLock);

		if( saeItem->Prev)
		{
			saeItem->Prev->Next = saeItem->Next;
		}
		
		if( __fxTEDP->PacketLast == saeItem)
		{
			__fxTEDP->PacketLast = saeItem->Next;
		}
		
		if( __fxTEDP->PacketCurrent == saeItem)
		{
			__fxTEDP->PacketCurrent = saeItem->Prev;
			
			if( __fxTEDP->PacketCurrent)
			{
				__fxTEDP->PacketCurrent->Next = NULL;
			}
		}		
		
		if( __fxTEDP->PacketHead == saeItem)
		{
			__fxTEDP->PacketHead = __fxTEDP->PacketHead->Next;
		}
		
		pthread_mutex_unlock( &__fxTEDP->packetLock);
		
		
		
		saeItem->InPacket = 0;
		saeItem->Prev = NULL;
		saeItem->Next = NULL;
		
		
		pthread_mutex_lock( &__fxTEDP->saeLock);
		if(!__fxTEDP->SAEHead)
		{
			__fxTEDP->SAEHead = __fxTEDP->SAECurrent = saeItem;
		}
		else
		{
			__fxTEDP->SAECurrent->Next = saeItem;
			__fxTEDP->SAECurrent = saeItem;
		}
		pthread_mutex_unlock( &__fxTEDP->saeLock);
	}
	*/
	//printf("PacketHead=%p  PacketsToSend=%u SentPackets=%d\n", __fxTEDP->PacketHead, saeItem->PacketsToSend, saeItem->SentPackets);
	
}

void FxTEDP__UpdateReceivedPacket( uint32_t ueip, uint32_t dstip, uint16_t srcport, uint16_t dstport, uint32_t pktlen)
{
	__fxTEDP->ReceivedPackets++;
	__fxTEDP->ReceivedBytes += pktlen;
	
	FxSAE_t * saeItem = NULL;
	__si_power_table_fnd( __fxTEDP->saeTable, (char*)&ueip, 4, (uint8_t **) &saeItem);	
	
	if( saeItem)
	{
		int j = 0;
		
		for( j = 0; j < __fxTEDP->FlowCount; j++)
		{
			// saeItem->Flows[j].DstIP 	= __si_core_getU32RANDRange( 0x0A0A0A0A, 0xC0C0C0C0);
			// saeItem->Flows[j].DstPort	= __si_core_getU16RANDRange( 6000, 10000);
			// saeItem->Flows[j].SrcPort	= __si_core_getU16RANDRange( 6000, 10000);
			// saeItem->Flows[j].TCPSeqNo  = 0;
		
			if( dstip == saeItem->Flows[j].DstIP && saeItem->Flows[j].DstPort == dstport && saeItem->Flows[j].SrcPort == srcport)
			{
				saeItem->Flows[j].ReceivedPackets++;
				saeItem->Flows[j].ReceivedBytes += pktlen;
				break;
			}
		}
	}
}

void FxTEDP__UpdatePacketInfo2( uint8_t * sPtr, uint32_t flowId, uint32_t pktlen, uint32_t coreId)
{
	if(!sPtr) return;
	
	FxSAE_t * saeItem = (FxSAE_t *)sPtr;

	saeItem->GTPSeqNo++;
	saeItem->Flows[flowId].TCPSeqNo += pktlen;
	saeItem->Flows[flowId].SentBytes += pktlen;
	saeItem->Flows[flowId].SentPackets++;
	
	saeItem->SentPackets++;
	__fxTEDP->SentPackets++;
	__fxTEDP->SentBytes += pktlen;
		
	//time_t timeVal_1 = time(NULL);
	
	//printf( "timeVal_1=%ld < saeItem->PacketDuration=%ld\n", timeVal_1, saeItem->PacketDuration);

	//printf("SendType=%d SentPackets=%u PacketsToSend=%u PacketDuration=%lu timeVal_1=%lu \n", 
	//	saeItem->SendType, saeItem->SentPackets, saeItem->PacketsToSend, saeItem->PacketDuration, timeVal_1);
	
	/*
	if( saeItem->SendType == 0 || (saeItem->SentPackets >= saeItem->PacketsToSend && saeItem->SendType == 1) || (timeVal_1 >= saeItem->PacketDuration && saeItem->SendType == 2))
	{
		if( __fxTEDP->CoreCount > 0)
		{
			pthread_mutex_lock( &__fxTEDP->MSAE[coreId].packetLock);

			if( saeItem->Prev)
			{
				saeItem->Prev->Next = saeItem->Next;
			}
			
			if( __fxTEDP->MSAE[coreId].PacketLast == saeItem)
			{
				__fxTEDP->MSAE[coreId].PacketLast = saeItem->Next;
			}
			
			if( __fxTEDP->MSAE[coreId].PacketCurrent == saeItem)
			{
				__fxTEDP->MSAE[coreId].PacketCurrent = saeItem->Prev;
				
				if( __fxTEDP->MSAE[coreId].PacketCurrent)
				{
					__fxTEDP->MSAE[coreId].PacketCurrent->Next = NULL;
				}
			}		
			
			if( __fxTEDP->MSAE[coreId].PacketHead == saeItem)
			{
				__fxTEDP->MSAE[coreId].PacketHead = __fxTEDP->MSAE[coreId].PacketHead->Next;
			}
			
			pthread_mutex_unlock( &__fxTEDP->MSAE[coreId].packetLock);
		}
		else
		{
			pthread_mutex_lock( &__fxTEDP->packetLock);

			if( saeItem->Prev)
			{
				saeItem->Prev->Next = saeItem->Next;
			}
			
			if( __fxTEDP->PacketLast == saeItem)
			{
				__fxTEDP->PacketLast = saeItem->Next;
			}
			
			if( __fxTEDP->PacketCurrent == saeItem)
			{
				__fxTEDP->PacketCurrent = saeItem->Prev;
				
				if( __fxTEDP->PacketCurrent)
				{
					__fxTEDP->PacketCurrent->Next = NULL;
				}
			}		
			
			if( __fxTEDP->PacketHead == saeItem)
			{
				__fxTEDP->PacketHead = __fxTEDP->PacketHead->Next;
			}
			
			pthread_mutex_unlock( &__fxTEDP->packetLock);
		}
		
		
		saeItem->InPacket = 0;
		saeItem->Prev = NULL;
		saeItem->Next = NULL;
		
		pthread_mutex_lock( &__fxTEDP->saeLock);
		if(!__fxTEDP->SAEHead)
		{
			__fxTEDP->SAEHead = __fxTEDP->SAECurrent = saeItem;
		}
		else
		{
			__fxTEDP->SAECurrent->Next = saeItem;
			__fxTEDP->SAECurrent = saeItem;
		}
		pthread_mutex_unlock( &__fxTEDP->saeLock);

	}
	*/

	//printf("PacketHead=%p  PacketsToSend=%u SentPackets=%d\n", __fxTEDP->PacketHead, saeItem->PacketsToSend, saeItem->SentPackets);
	
}


void * FxTEDP__LoadSimulator( void * args)
{
	uint8_t * sPtr 		= NULL;
	uint32_t upfTeid 	= 0;
	uint32_t ranTeid 	= 0;
	uint32_t upfip 		= 0;
	uint32_t flowId 	= 0;
	uint32_t gtpSeqNo 	= 0;
	uint32_t tcpSeqNo 	= 0;
	uint32_t srcip		= 0;
	uint32_t dstip		= 0;
	uint16_t srcport	= 0;
	uint16_t dstport	= 0;
	uint8_t protocol	= 0;
	uint8_t qosFlowId	= 0;
	uint32_t coreId		= 0;
	
	char cUEIP[20];
	char cUPFIP[20];
	
	while(1)
	{
		FxTEDP__GetPacketInfo2( &sPtr, &upfTeid, &ranTeid, &upfip, &flowId, &gtpSeqNo, &tcpSeqNo, &srcip, &dstip, &srcport, &dstport, &protocol, &qosFlowId, coreId);
		
		if( sPtr)
		{
			memset( cUEIP, 0, sizeof(cUEIP));
			memset( cUPFIP, 0, sizeof(cUPFIP));
			
			__si_core_convert_inttoipv4_2( htonl(srcip), cUEIP);
			__si_core_convert_inttoipv4_2( htonl(upfip), cUPFIP);
			
			printf("sPtr=%p srcip=%u,%s upfTeid=%u ranTeid=%u upfip=%u,%s flowId=%u gtpSeqNo=%u tcpSeqNo=%u %s|%d\n", 
				sPtr, srcip, cUEIP, upfTeid, ranTeid, upfip, cUPFIP, flowId, gtpSeqNo, tcpSeqNo, __FUNCTION__, __LINE__);
			
			FxTEDP__UpdatePacketInfo2( sPtr, flowId, 100, coreId);
		}

		sPtr 		= NULL;
		upfTeid 	= 0;
		ranTeid 	= 0;
		upfip 		= 0;
		flowId 		= 0;
		gtpSeqNo 	= 0;
		tcpSeqNo 	= 0;		
		
		//usleep( 999999);
	}
}


void FxTEDP__WriteUEStats()
{
	if( __fxTEDP->UE_SAEHead)
	{
		__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%-20s   %-20s   %-4s   %-4s   %-10s   %-10s   %s   %s   %s   %s   %s", 
			"UEIP", "DSTIP", "sprt", "dprt", 
			"sent-pkts", "recv-pkts", "s-vol", "r-vol", "l-type", 
			"pkt-to-send", "sent-pkts");		
		
		char sUEIP[30];
		char sDSTIP[30];
		FxSAE_t * saeitem = __fxTEDP->UE_SAEHead;
		
		int i = 0;
		char SentData[20];
		char RecvData[20];
		
		while( saeitem)
		{
			memset( sUEIP, 0, sizeof(sUEIP));
			__si_core_convert_inttoipv4_2( htonl( saeitem->UEIP), sUEIP);
			
			for( i = 0; i < __fxTEDP->FlowCount; i++)
			{
				memset( sDSTIP, 0, sizeof(sDSTIP));
				memset( SentData, 0, sizeof(SentData));
				memset( RecvData, 0, sizeof(RecvData));
				
				__si_core_convert_inttoipv4_2( htonl( saeitem->Flows[i].DstIP), sDSTIP);
				
				if( saeitem->Flows[i].SentBytes > 0)
				{
					if( saeitem->Flows[i].SentBytes < 1000)
					{
						sprintf( SentData, "%lu bytes", saeitem->Flows[i].SentBytes);
					}
					else if( saeitem->Flows[i].SentBytes >= 1000 && saeitem->Flows[i].SentBytes < (1000 * 1000))
					{
						sprintf( SentData, "%lu kbits", saeitem->Flows[i].SentBytes / 1000 );
					}
					else if( saeitem->Flows[i].SentBytes >= (1000 * 1000) && saeitem->Flows[i].SentBytes < (1000 * 1000 * 1000))
					{
						sprintf( SentData, "%lu mbits", saeitem->Flows[i].SentBytes / (1000 * 1000) );
					}
					else if( saeitem->Flows[i].SentBytes >= (1000 * 1000 * 1000))
					{
						sprintf( SentData, "%lu mbits", saeitem->Flows[i].SentBytes / (1000 * 1000 * 1000) );
					}
				}


				if( saeitem->Flows[i].ReceivedBytes > 0)
				{
					if( saeitem->Flows[i].ReceivedBytes < 1000)
					{
						sprintf( SentData, "%lu bytes", saeitem->Flows[i].ReceivedBytes);
					}
					else if( saeitem->Flows[i].ReceivedBytes >= 1000 && saeitem->Flows[i].ReceivedBytes < (1000 * 1000))
					{
						sprintf( SentData, "%lu kbits", saeitem->Flows[i].ReceivedBytes / 1000 );
					}
					else if( saeitem->Flows[i].ReceivedBytes >= (1000 * 1000) && saeitem->Flows[i].ReceivedBytes < (1000 * 1000 * 1000))
					{
						sprintf( SentData, "%lu mbits", saeitem->Flows[i].ReceivedBytes / (1000 * 1000) );
					}
					else if( saeitem->Flows[i].ReceivedBytes >= (1000 * 1000 * 1000))
					{
						sprintf( SentData, "%lu mbits", saeitem->Flows[i].ReceivedBytes / (1000 * 1000 * 1000) );
					}
				}
				
				__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%-20s   %-20s   %-4d   %-4d   %-10ld   %-10ld   %s   %s   %d   %d   %d", 
					sUEIP, sDSTIP, saeitem->Flows[i].SrcPort, saeitem->Flows[i].DstPort, 
					saeitem->Flows[i].SentPackets, saeitem->Flows[i].ReceivedPackets, SentData, RecvData, saeitem->SendType, 
					saeitem->PacketsToSend, saeitem->SentPackets);
			}
			
			saeitem = saeitem->UE_Next;
		}
		
		__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "----------------------------------------------------------------------------------------------");
	}
}


uint64_t gSentPackets = 0;
uint64_t gSentBytes = 0;	

uint64_t gLastSentPackets = 0;
uint64_t gLastSentBytes = 0;

uint64_t gCurrentSentPackets = 0;
uint64_t gCurrentSentBytes = 0;	

uint64_t gReceivedPackets = 0;
uint64_t gReceivedBytes = 0;	

uint64_t gLastReceivedPackets = 0;
uint64_t gLastReceivedBytes = 0;

uint64_t gCurrentReceivedPackets = 0;
uint64_t gCurrentReceivedBytes = 0;

	
void FxTEDP__PerfLog( int writeCoreStats)
{
	gSentPackets = __fxTEDP->SentPackets;
	gSentBytes = __fxTEDP->SentBytes;

	gCurrentSentPackets = gSentPackets - gLastSentPackets;
	gCurrentSentBytes = gSentBytes - gLastSentBytes;
	
	gReceivedPackets = __fxTEDP->ReceivedPackets;
	gReceivedBytes = __fxTEDP->ReceivedBytes;
	
	gCurrentReceivedPackets = gReceivedPackets - gLastReceivedPackets;
	gCurrentReceivedBytes = gReceivedBytes - gLastReceivedBytes;
		
	__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "Configured-Cores=%d SAUs=%d", __fxTEDP->CoreCount, 
		__si_power_table_get_item_count(__fxTEDP->saeTable));
	
	__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "Current Sent  Packets=%-15lu Bytes=%-15lu MB=%-10lu  GB=%-10lu", 
		gCurrentSentPackets, gCurrentSentBytes, (gCurrentSentBytes/1024)/1024, ((gCurrentSentBytes/1024)/1024)/1024);

	__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "Total   Sent  Packets=%-15lu Bytes=%-15lu MB=%-10lu  GB=%-10lu", 
		gSentPackets, gSentBytes, (gSentBytes/1024)/1024, ((gSentBytes/1024)/1024)/1024);
		
	__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "Current Recv  Packets=%-15lu Bytes=%-15lu MB=%-10lu  GB=%-10lu", 
		gCurrentReceivedPackets, gCurrentReceivedBytes, (gCurrentReceivedBytes/1024)/1024, ((gCurrentReceivedBytes/1024)/1024)/1024);
		
	__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "Last    Sent  Packets=%-15lu Bytes=%-15lu MB=%-10lu  GB=%-10lu", 
		gReceivedPackets, gReceivedBytes, (gReceivedBytes/1024)/1024, ((gReceivedBytes/1024)/1024)/1024);
		

	gLastSentPackets = gSentPackets;
	gLastSentBytes = gSentBytes;
	
	gLastReceivedPackets = gReceivedPackets;
	gLastReceivedBytes = gReceivedBytes;

	if( __fxTEDP->CoreCount > 0 && writeCoreStats == 1)
	{
		int iCC = 0;
		for( iCC = 0; iCC < __fxTEDP->CoreCount; iCC++)
		{
			__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "Core %d  Packets %-15lu  %-15lu", 
				iCC, __fxTEDP->MSAE[iCC].SentPacketsInSecond, __fxTEDP->MSAE[iCC].TotalSentPacketsInSecond );
		}
	}
		
}

void * FxTEDP__PerfCounter( void * args)
{
	uint64_t SentPackets = 0;
	uint64_t SentBytes = 0;	
	
	uint64_t LastSentPackets = 0;
	uint64_t LastSentBytes = 0;

	uint64_t CurrentSentPackets = 0;
	uint64_t CurrentSentBytes = 0;	
	
	
	uint64_t ReceivedPackets = 0;
	uint64_t ReceivedBytes = 0;	
	
	uint64_t LastReceivedPackets = 0;
	uint64_t LastReceivedBytes = 0;
	
	uint64_t CurrentReceivedPackets = 0;
	uint64_t CurrentReceivedBytes = 0;
	
	char date[30];
	
	int iCounter 	= 0;
	int iCC 		= 0;
	
	while(1)
	{
		SentPackets = __fxTEDP->SentPackets;
		SentBytes = __fxTEDP->SentBytes;

		CurrentSentPackets = SentPackets - LastSentPackets;
		CurrentSentBytes = SentBytes - LastSentBytes;
		
		ReceivedPackets = __fxTEDP->ReceivedPackets;
		ReceivedBytes = __fxTEDP->ReceivedBytes;
		
		CurrentReceivedPackets = ReceivedPackets - LastReceivedPackets;
		CurrentReceivedBytes = ReceivedBytes - LastReceivedBytes;
		
		
		__si_makeDBTimeStamp( date);
		__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "%s  Configured-Cores=%d SAUs=%d", date, __fxTEDP->CoreCount, 
			__si_power_table_get_item_count(__fxTEDP->saeTable));
		
		__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "Current Sent  Packets=%-15lu Bytes=%-15lu MB=%-10lu  GB=%-10lu", 
			CurrentSentPackets, CurrentSentBytes, (CurrentSentBytes/1024)/1024, ((CurrentSentBytes/1024)/1024)/1024);

		__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "Total   Sent  Packets=%-15lu Bytes=%-15lu MB=%-10lu  GB=%-10lu", 
			SentPackets, SentBytes, (SentBytes/1024)/1024, ((SentBytes/1024)/1024)/1024);
			
		__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "Current Recv  Packets=%-15lu Bytes=%-15lu MB=%-10lu  GB=%-10lu", 
			CurrentReceivedPackets, CurrentReceivedBytes, (CurrentReceivedBytes/1024)/1024, ((CurrentReceivedBytes/1024)/1024)/1024);
			
		__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "Last    Sent  Packets=%-15lu Bytes=%-15lu MB=%-10lu  GB=%-10lu", 
			ReceivedPackets, ReceivedBytes, (ReceivedBytes/1024)/1024, ((ReceivedBytes/1024)/1024)/1024);
			

		__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "-----------------------------------------------------------------------------------------");
		//printf( "-----------------------------------------------------------------------------------------\n");
			
		LastSentPackets = SentPackets;
		LastSentBytes = SentBytes;
		
		LastReceivedPackets = ReceivedPackets;
		LastReceivedBytes = ReceivedBytes;
		
		if( __fxTEDP->LogUEStats > 0) 
		{
			if( iCounter == __fxTEDP->LogUEStats)
			{
				FxTEDP__WriteUEStats();
				iCounter = 0;
			}
		} 
		else 
		{
			iCounter = 0;
		}
		
		
		if( __fxTEDP->CoreCount > 0)
		{
			for( iCC = 0; iCC < __fxTEDP->CoreCount; iCC++)
			{
				__si_log( SI_PER_LOG, 0, SI_LOG_DEBUG, "Core %d  Packets=%-15lu  %-15lu", 
					iCC, __fxTEDP->MSAE[iCC].SentPacketsInSecond, __fxTEDP->MSAE[iCC].TotalSentPacketsInSecond );
			}
		}

		
		sleep(1);
		iCounter++;
	}

	return NULL;
}


void FxTEDP__LogUEStats( int log)
{
	if( __fxTEDP)
	{
		if( __fxTEDP->LogUEStats <= 300)
		{
			__fxTEDP->LogUEStats = log;
		}
	}
}


void FxTEDP__PPSPC( uint64_t ppspc)
{
	if( __fxTEDP)
	{
		__fxTEDP->PPSPC = ppspc;
	}
}

void FxTEDP__DelayPacket( int delay)
{
	if( __fxTEDP)
	{
		__fxTEDP->DelayPacket = delay;
	}
}


void FxTEDP__DebugPacket( int debug)
{
	if( __fxTEDP)
	{
		__fxTEDP->DebugPacket = debug;
	}
}


void FxTEDP__SetMaxFlowCount( int flowCount)
{
	if( __fxTEDP)
	{
		if( flowCount > 0 && flowCount < 6)
		{
			__fxTEDP->FlowCount = flowCount;
		}
	}
}

void FxTEDP__Init( char * ip, int port, int coreCount, int startPerf)
{
	if(!__fxTEDP)
	{
		//__init_sirik_core();				// Initialize Core
		//__si_init_logger("./dplogs/");	// Set Logs Path
		__si_socket_engine_init();

		__fxTEDP = (FxTEDP_t*)malloc( sizeof(FxTEDP_t)); 
		__fxTEDP->SAETotalCount 		= 1000000;  //Simultionous Active Users
		__fxTEDP->SAETotalAvailable 	= 1000000;
		__fxTEDP->SAEHead = NULL;
		__fxTEDP->SAECurrent = NULL;
		__fxTEDP->UE_SAEHead = NULL;
		__fxTEDP->UE_SAECurrent = NULL;
		__fxTEDP->FlowCount	= 0;
		__fxTEDP->DelayPacket = 0;
		__fxTEDP->DebugPacket = 0;
		__fxTEDP->LogUEStats = 0;
	
		__fxTEDP->saeTable = __si_power_table_create();
		__fxTEDP->RAN_IP = 0;
		__fxTEDP->CoreCount = coreCount;
		pthread_mutex_init( &__fxTEDP->saeLock, NULL);


		__fxTEDP->SentPackets = 0;
		__fxTEDP->SentBytes = 0;
		__fxTEDP->ReceivedPackets = 0;
		__fxTEDP->ReceivedBytes = 0;
		
		__fxTEDP->PacketHead = NULL;
		__fxTEDP->PacketCurrent = NULL;
		__fxTEDP->PacketLast = NULL;
		__fxTEDP->FlowCount = 5;
		pthread_mutex_init( &__fxTEDP->packetLock, NULL);

		FxSAE_t * saeItem = NULL;
		
		if( coreCount > 0)
		{
			if( coreCount > 20)
			{
				printf("Max Core Count is 20\n");
				exit(0);
			}
			
			//uint8_t * dPtrX = malloc(sizeof(FxSAE_t) * coreCount);
			
			int z = 0;
			
			while( z < coreCount)
			{
				__fxTEDP->MSAE[z].PacketHead				= NULL;
				__fxTEDP->MSAE[z].PacketCurrent				= NULL;
				__fxTEDP->MSAE[z].PacketLast				= NULL;
				__fxTEDP->MSAE[z].LastSentPacketsInSecond	= 0;
				__fxTEDP->MSAE[z].SentPacketsInSecond		= 0;
				__fxTEDP->MSAE[z].TotalSentPacketsInSecond	= 0;
				__fxTEDP->MSAE[z].ActiveSessions			= 0;
				__fxTEDP->MSAE[z].TotalSessions				= 0;
				//__fxTEDP->MSAE[z].SentBytesInSecond		= 0;
				//__fxTEDP->MSAE[z].TotalSentBytesInSecond	= 0;
				__fxTEDP->MSAE[z].Tick						= __si_core_get_server_timer_tick();
				pthread_mutex_init( &__fxTEDP->MSAE[z].packetLock, NULL);
				
				
				z++;
			}
		}
	
		uint8_t * dPtr = malloc(sizeof(FxSAE_t) * __fxTEDP->SAETotalCount);
	
		if(!dPtr)
		{
			printf("memory allocation failed\n");
			exit(0);
		}
	
		int i = 0;
		saeItem = NULL;
		
		for( i = 0; i < __fxTEDP->SAETotalCount; i++)
		{
			saeItem = (FxSAE_t*)dPtr;
			memset( saeItem, 0, sizeof(FxSAE_t));
			
			if(!__fxTEDP->SAEHead)
			{
				__fxTEDP->SAEHead = __fxTEDP->SAECurrent = saeItem;
			}
			else
			{
				__fxTEDP->SAECurrent->Next = saeItem;
				__fxTEDP->SAECurrent = saeItem;
			}
			
			dPtr += sizeof(FxSAE_t);
		}
		
		
	
		SI_Socket * siSocket = NULL;
		siSocket =__si_socketEngine->CreateServerSocket( ip, 4, 1, port, 0, "", "");

		siSocket->OnAccept 			= FxTEDP___on_accept;
		siSocket->OnClose 			= FxTEDP___on_close;
		siSocket->OnBufferReceive	= FxTEDP___on_buffer;
		__si_socketEngine->Start( siSocket);
		
		
		if( startPerf == 1)
		{
			__si_create_pthread2( FxTEDP__PerfCounter, NULL, "tedpperf");
		}
		
		
		__si_log( SI_APP_LOG, 0, SI_LOG_CRITICAL, "FxTestEngineDataPlane-1 Started on ADDR=%s:%d Cores=%d  <%s|%s|%d>", ip, port, coreCount, __FILE__, __FUNCTION__, __LINE__);
		
		
		#if MAINAPP
			__si_create_pthread2( FxTEDP__LoadSimulator, NULL, "test");
			printf( "TEDP Started in Simulator-Mode with core-count=%u SAECount=%u\n", coreCount, __fxTEDP->SAETotalCount);
		#else
			printf( "TEDP Started in Lib-Mode with core-count=%u SAECount=%u\n", coreCount, __fxTEDP->SAETotalCount);
		#endif
	}
}


// NEW
// gcc -g3 -shared -fPIC -o libsicore.so ../../../sirik_core.c ../../../lib_endpoint/sirik_socket.c -I../../../ -DCORE_LIC -DSCTP_SUPPORT -lsctp
// gcc -g3 -shared -o libTEDP.so -fPIC FxTEDP.c -I../../../ -I../../../lib_endpoint/ -lpthread -Wl,-rpath .
// gcc -g3 -o FxTEDP FxTEDP.c libsicore.so -I../../../ -I../../../lib_endpoint/ -lpthread -DMAINAPP   -Wl,-rpath .

// OLD
// gcc -g3 -shared -o libTEDP.so -fPIC FxTEDP.c -I../../../ -I../../../lib_endpoint/ ../../../sirik_core.c ../../../lib_endpoint/sirik_socket.c -lpthread
// gcc -g3 -o FxTEDP FxTEDP.c -I../../../ -I../../../lib_endpoint/ ../../../sirik_core.c ../../../lib_endpoint/sirik_socket.c -lpthread -DMAINAPP
#if MAINAPP
int main( int argc, char* argv[])
{
	// printf( "hex=%s int=%d  %d\n", __si_core_convert_inttoipv4( 0x00000001), 0x00000001, 0x1);
	// exit(0);
	
	// uint32_t  index = 0;
	// int i = 0;
	
	// for( i = 0; i < 10; i++)
	// {
		// printf("Number Index=%u for Numb=%u Of Total=%u\n", (123 + i) % 5, (123 + i), 5 );
	// }
	
	printf( "FxTestEngineDataPlane\n");
	__init_sirik_core();				// Initialize Core
	__si_init_logger("./dplogs/");		// Set Logs Path	
	FxTEDP__Init( "192.160.1.5", 9359, 1, 1);
	
	// time_t timeVal_1 = time(NULL);
	// time_t timeVal_2 = time(NULL) + 10;
	
	// printf("timeVal_1=%ld timeVal_2=%ld\n", timeVal_1, timeVal_2);

	// while( timeVal_1 < timeVal_2)
	// {
		// usleep(999999);
		// timeVal_1 = time(NULL);
		// printf("timeVal_1=%ld timeVal_2=%ld\n", timeVal_1, timeVal_2);		
	// }
	
	
	printf( "FxTestEngineDataPlane started.\n");
	printf( "-----------------------------------------------------------------------------------------\n");
	
	while(1)
	{
		usleep(999999);
	}
	
	return 0;
}
#endif