#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <semaphore.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>
#include <unistd.h>
#include <signal.h>
#include <limits.h>
#include <poll.h>
#include <sys/epoll.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <error.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <net/if.h> 
#include <resolv.h>
#include <ifaddrs.h>

#if TLS_SOCKET_SUPPORT
	#include "openssl/ssl.h"
	#include "openssl/err.h"
#endif

#if SCTP_SUPPORT
	#include <netinet/sctp.h>
#endif

#if USR_SCTP_SUPPORT
	#include <usrsctp.h>
#endif

#include <poll.h>
#include <sys/epoll.h>

#include "sirik_core.h"
#include "sirik_socket.h"

#define		EPOLL_MAXEVENTS				10

SI_SocketEngine * __si_socketEngine;


SI_SocketBuffer * __si_socket_engine_allocate_socket_buffer()
{
	pthread_mutex_lock( &__si_socketEngine->BufferPoolLock);
	
	SI_SocketBuffer * socketBuffer = __si_socketEngine->BufferPoolHead;
	
	if( !socketBuffer)
	{
		__si_socket_engine_create_socket_buffer( 1500, 0);
		socketBuffer = __si_socketEngine->BufferPoolHead;
	}
	
	if( socketBuffer)
	{
		__si_socketEngine->BufferPoolHead = socketBuffer->Next;
		
		socketBuffer->pos = 0;
		socketBuffer->len = 0;
		socketBuffer->isReleased = 0;
		socketBuffer->siSocket = NULL;
		socketBuffer->Next = NULL;
		
		__si_socketEngine->UsedBufferPoolCount++;
		__si_socketEngine->AvailableBufferPoolCount--;
	}
	
	pthread_mutex_unlock( &__si_socketEngine->BufferPoolLock);
	
	return socketBuffer;
}

void __si_socket_engine_release_socket_buffer( SI_SocketBuffer * socketBuffer)
{
	if( socketBuffer->isReleased == 0)
	{
		__si_socket_engine_add_socket_buffer_to_pool( socketBuffer, 1);
	}
}

void __si_socket_engine_create_socket_buffer( int size, int inlockMode)
{
	if( size == 0 ) return;
	
	if(inlockMode)
	{
		pthread_mutex_lock( &__si_socketEngine->BufferPoolLock);
	}
	
	uint8_t * _fblock = calloc( size, sizeof( SI_SocketBuffer));
	
	if(!_fblock)
	{
		printf("calloc failed %s|%d\n", __FILE__, __LINE__);
		return;
	}
	
	int i = 0;
	SI_SocketBuffer * socketBuffer = NULL;
	
	for( i = 0; i < size; i++)
	{	
		//SI_SocketBuffer * socketBuffer = (SI_SocketBuffer *) __si_malloc( sizeof( SI_SocketBuffer));
		//__si_malloc2( sizeof( SI_SocketBuffer), (uint8_t **) &socketBuffer);
		
		socketBuffer = (SI_SocketBuffer *) _fblock;
		socketBuffer->Next = NULL;
		
		__si_socket_engine_add_socket_buffer_to_pool( socketBuffer, 0);
		__si_socketEngine->TotalBufferPoolCount++;
		
		_fblock += sizeof( SI_SocketBuffer);
	}
	
	if(inlockMode)
	{
		pthread_mutex_unlock( &__si_socketEngine->BufferPoolLock);
	}
}

void __si_socket_engine_add_socket_buffer_to_pool( SI_SocketBuffer * socketBuffer, int inlockMode)
{
	if(inlockMode)
	{
		pthread_mutex_lock( &__si_socketEngine->BufferPoolLock);
	}
	
	if(!__si_socketEngine->BufferPoolHead)
	{
		__si_socketEngine->BufferPoolHead = __si_socketEngine->BufferPoolCurrent = socketBuffer;
	}
	else
	{
		__si_socketEngine->BufferPoolCurrent->Next = socketBuffer;
		__si_socketEngine->BufferPoolCurrent = socketBuffer;
	}
	
	socketBuffer->isReleased = 1;
	__si_socketEngine->AvailableBufferPoolCount++;
	
	if(inlockMode)
	{
		pthread_mutex_unlock( &__si_socketEngine->BufferPoolLock);
	}
}

// sctp
void __si_socket_engine_add_sctp_socket_buffer_to_pool( SI_SocketSCTPBuffer * socketBuffer, int inlockMode)
{
	if(inlockMode)
	{
		pthread_mutex_lock( &__si_socketEngine->SctpBufferPoolLock);
	}

	if(!__si_socketEngine->SctpBufferPoolHead)
	{
		__si_socketEngine->SctpBufferPoolHead = __si_socketEngine->SctpBufferPoolCurrent = socketBuffer;
	}
	else
	{
		__si_socketEngine->SctpBufferPoolCurrent->Next = socketBuffer;
		__si_socketEngine->SctpBufferPoolCurrent = socketBuffer;
	}
	
	__si_socketEngine->SctpAvailableBufferPoolCount++;
	
	if(inlockMode)
	{
		pthread_mutex_unlock( &__si_socketEngine->SctpBufferPoolLock);
	}	
}

void __si_socket_engine_create_sctp_socket_buffer( int size, int inlockMode)
{
	if(inlockMode)
	{
		pthread_mutex_lock( &__si_socketEngine->SctpBufferPoolLock);
	}
	
	int i = 0;
	SI_SocketSCTPBuffer * socketBuffer = NULL;
	
	for( i = 0; i < size; i++)
	{	
		__si_malloc2( sizeof( SI_SocketSCTPBuffer), (uint8_t **) &socketBuffer);
		socketBuffer->Next = NULL;
		
		__si_socket_engine_add_sctp_socket_buffer_to_pool( socketBuffer, 0);
		__si_socketEngine->SctpTotalBufferPoolCount++;
	}
	
	if(inlockMode)
	{
		pthread_mutex_unlock( &__si_socketEngine->SctpBufferPoolLock);
	}	
}

void __si_socket_engine_release_sctp_socket_buffer( SI_SocketSCTPBuffer * socketBuffer)
{
	if( socketBuffer->isReleased == 0)
	{
		__si_socket_engine_add_sctp_socket_buffer_to_pool( socketBuffer, 1);
	}
}

SI_SocketSCTPBuffer * __si_socket_engine_allocate_sctp_socket_buffer()
{
	pthread_mutex_lock( &__si_socketEngine->SctpBufferPoolLock);
	
	SI_SocketSCTPBuffer * socketBuffer = __si_socketEngine->SctpBufferPoolHead;
	
	if( !socketBuffer)
	{
		__si_socket_engine_create_sctp_socket_buffer( 500, 0);
		socketBuffer = __si_socketEngine->SctpBufferPoolHead;
	}
	
	if( socketBuffer)
	{
		__si_socketEngine->SctpBufferPoolHead = socketBuffer->Next;
		
		socketBuffer->pos = 0;
		socketBuffer->len = 0;
		socketBuffer->isReleased = 0;
		socketBuffer->siSocket = NULL;
		socketBuffer->Next = NULL;
		socketBuffer->siThread = NULL;
		
		__si_socketEngine->SctpUsedBufferPoolCount++;
		__si_socketEngine->SctpAvailableBufferPoolCount--;
	}
	
	pthread_mutex_unlock( &__si_socketEngine->SctpBufferPoolLock);
	
	return socketBuffer;
}

// udp
void __si_socket_engine_add_socket_udp_buffer_to_pool( SI_SocketUdpBuffer * socketBuffer, int inlockMode)
{
	if(inlockMode)
	{
		pthread_mutex_lock( &__si_socketEngine->UdpBufferPoolLock);
	}
	
	if(!__si_socketEngine->UdpBufferPoolHead)
	{
		__si_socketEngine->UdpBufferPoolHead = __si_socketEngine->UdpBufferPoolCurrent = socketBuffer;
	}
	else
	{
		__si_socketEngine->UdpBufferPoolCurrent->Next = socketBuffer;
		__si_socketEngine->UdpBufferPoolCurrent = socketBuffer;
	}
	
	socketBuffer->isReleased = 1;
	__si_socketEngine->UdpAvailableBufferPoolCount++;
	
	if(inlockMode)
	{
		pthread_mutex_unlock( &__si_socketEngine->UdpBufferPoolLock);
	}
}

void __si_socket_engine_release_socket_udp_buffer( SI_SocketUdpBuffer * socketBuffer)
{
	if( socketBuffer->isReleased == 0)
	{
		__si_socket_engine_add_socket_udp_buffer_to_pool( socketBuffer, 1);
	}
}

void __si_socket_engine_create_udp_socket_buffer( int size, int inlockMode)
{
	if(inlockMode)
	{
		pthread_mutex_lock( &__si_socketEngine->UdpBufferPoolLock);
	}
	
	int i = 0;
	SI_SocketUdpBuffer * socketBuffer = NULL;
	
	for( i = 0; i < size; i++)
	{	
		__si_malloc2( sizeof( SI_SocketUdpBuffer), (uint8_t **) &socketBuffer);
		socketBuffer->Next = NULL;
		
		__si_socket_engine_add_socket_udp_buffer_to_pool( socketBuffer, 0);
		__si_socketEngine->UdpTotalBufferPoolCount++;
	}
	
	if(inlockMode)
	{
		pthread_mutex_unlock( &__si_socketEngine->UdpBufferPoolLock);
	}
}

SI_SocketUdpBuffer * __si_socket_engine_allocate_socket_udp_buffer()
{
	pthread_mutex_lock( &__si_socketEngine->UdpBufferPoolLock);
	
	SI_SocketUdpBuffer * socketBuffer = __si_socketEngine->UdpBufferPoolHead;
	
	if( !socketBuffer)
	{
		__si_socket_engine_create_udp_socket_buffer( 1500, 0);
		socketBuffer = __si_socketEngine->UdpBufferPoolHead;
	}
	
	if( socketBuffer)
	{
		__si_socketEngine->UdpBufferPoolHead = socketBuffer->Next;
		
		socketBuffer->pos = 0;
		socketBuffer->len = 0;
		socketBuffer->isReleased = 0;
		socketBuffer->siSocket = NULL;
		socketBuffer->Next = NULL;
		
		__si_socketEngine->UdpUsedBufferPoolCount++;
		__si_socketEngine->UdpAvailableBufferPoolCount--;
	}
	
	pthread_mutex_unlock( &__si_socketEngine->UdpBufferPoolLock);
	
	return socketBuffer;
}

uint32_t __si_socket__get_sin6_scope_id( uint8_t * ipv6)
{
	uint32_t sin6_scope_id = 0;
	
	struct ifaddrs *ifaddr, *ifa;
	int family, s;
	char host[100];
	
	if (getifaddrs(&ifaddr) == -1)
	{
		perror("getifaddrs");
		exit(0);
	}
	
	for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next)
	{
		if (ifa->ifa_addr == NULL)
			continue;
		
		if( ifa->ifa_addr->sa_family == AF_INET6)
		{
			struct sockaddr_in6 * sa_in6 = (struct sockaddr_in6 *)ifa->ifa_addr;
			//printf( "sin6_scope_id=%u ", sa_in6->sin6_scope_id);
			//__si_print_buffer( (char *)sa_in6->sin6_addr.s6_addr, 16);
			
			if( memcmp( sa_in6->sin6_addr.s6_addr, ipv6, 16) == 0)
			{
				sin6_scope_id = sa_in6->sin6_scope_id;
				break;
			}
		}
	}
	
	freeifaddrs( ifaddr);
	return sin6_scope_id;
}

int __isTrail = 0;

void __si_socket_fv()
{
	__isTrail = 0;
}

#define DEFAULT_TARGET stdout;
static FILE *debug_target = NULL;

void __si_socket_engine__sctp_debug_printf( const char * format, ...)
{
	va_list ap;
	char charbuf[1024];
	static struct timeval time_main;
	struct timeval time_now;
	struct timeval time_delta;

	if (debug_target == NULL) {
		debug_target = DEFAULT_TARGET;
	}

	if (time_main.tv_sec == 0  && time_main.tv_usec == 0) {
		gettimeofday(&time_main, NULL);
	}

	gettimeofday(&time_now, NULL);
	timersub(&time_now, &time_main, &time_delta);

	va_start(ap, format);
	if (vsnprintf(charbuf, 1024, format, ap) < 0) {
		charbuf[0] = '\0';
	}
	va_end(ap);

	fprintf(debug_target, "[S][%u.%03u] %s", (unsigned int) time_delta.tv_sec, (unsigned int) time_delta.tv_usec / 1000, charbuf);
	fflush(debug_target);
}



si_fp_socket_is_ip_allowed m_is_ip_allowed = NULL;

void  __si_socket_engine__set_is_ip_allowed_cb( si_fp_socket_is_ip_allowed p_is_ip_allowed)
{
	m_is_ip_allowed = p_is_ip_allowed;
}

void * __si_socket_engine_udp_start_server_socket( void * args)
{
	SI_Socket * siSocket = (SI_Socket *) args;
	
	int iPort = siSocket->IPPort;
	int serverSocket = 0;
	struct sockaddr_in cli_addr;
	struct sockaddr_in6 cli_addr6;
	
	
	
	if( siSocket->TransportType == SIRIK_TRANSPORT_TYPE_UDP)
	{
		if( siSocket->IPVersion == SIRIK_IP_VERSION_4) 
		{	
			serverSocket = socket( AF_INET, SOCK_DGRAM, IPPROTO_UDP);
		} 
		else 
		{
			serverSocket = socket( AF_INET6, SOCK_DGRAM, IPPROTO_UDP);
		}		
	}
	
	if( serverSocket <= 0)
	{
		printf("UDP Host Server Socket Creation Failed (Host Process) for Port=%d\n", iPort);
		exit(1);
	}
	
	siSocket->fd = serverSocket;
	
	printf("start udp server for port %d ipversion=%d fd=%d  (%s|%s|%d) \n", siSocket->IPPort, siSocket->IPVersion, siSocket->fd, __FUNCTION__, __FILE__, __LINE__);
	
	int yes = 1;

	if( setsockopt( serverSocket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1)
	{
		printf("UCP setsockopt SO_REUSEADDR failed\n");
		exit(1);
	}

	if( siSocket->IPVersion == SIRIK_IP_VERSION_4)
	{	
		struct sockaddr_in serverAddr;
		memset( &serverAddr, 0, sizeof( struct sockaddr_in));
		serverAddr.sin_family = AF_INET;
		serverAddr.sin_port = htons(iPort);
		
		if( strlen( siSocket->IPAddresses[0].IPAddress) == 0) {
			serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
		} else {
			serverAddr.sin_addr.s_addr = inet_addr( siSocket->IPAddresses[0].IPAddress);
		}
		
		if( bind( serverSocket, (struct sockaddr *) &serverAddr, sizeof(struct sockaddr)) != 0)
		{
			printf("Server Bind Failed for UDP-V4 Server Socket = %d Server-IP=%s Port = %d\n", serverSocket, siSocket->IPAddresses[0].IPAddress, iPort);
			exit(1);
		}
		else
		{
			printf("Server Bind Success for UDP-V4 Server Socket = %d Server-IP=%s Port = %d\n", serverSocket, siSocket->IPAddresses[0].IPAddress, iPort);
		}
	}
	else
	{
		struct sockaddr_in6 serverAddr6;
		memset( &serverAddr6, 0, sizeof( struct sockaddr_in6));
		serverAddr6.sin6_family = AF_INET6;
		serverAddr6.sin6_port = htons(iPort);
		serverAddr6.sin6_addr = in6addr_any;

		if( bind( serverSocket, (struct sockaddr *) &serverAddr6, sizeof(struct sockaddr_in6)) != 0)
		{
			perror("bind failed\n");
			printf("Server Bind Failed for UDP-V6 Server Socket = %d Server/Port = %d\n", serverSocket, iPort);
			exit(1);
		}		
	}

	struct pollfd fds;	
	fds.fd     = serverSocket;
	fds.events = POLLIN;

	long int iRequestNo = 0;
	int n = 0, flags = 0, ret;
	
	SI_SocketUdpBuffer * udpBuffer = NULL;

	//printf("Server Started for UDP-V4 Server Socket = %d Server-IP=%s Port = %d\n", serverSocket, siSocket->IPAddresses[0].IPAddress, iPort);


	while(1)
	{
		ret = poll( &fds, 1, 1000);
		
		if( ret <= 0)
		{
			continue;
		}
		
		if( ret > 0)
		{
			udpBuffer = __si_socket_engine_allocate_socket_udp_buffer();
			udpBuffer->pos = 0;
			
			//printf("sizes = sockaddr_in=%ld sockaddr_in6=%ld\n", sizeof(struct sockaddr_in), sizeof(struct sockaddr_in6));
			// printf("Server Started for UDP-V%d Server Socket = %d Server-IP=%s Port = %d\n", 
				// siSocket->IPVersion, serverSocket, siSocket->IPAddresses[0].IPAddress, iPort);
			
			if( siSocket->IPVersion == SIRIK_IP_VERSION_4)
			{
				udpBuffer->clientlen = sizeof(struct sockaddr_in);
				//memset( &udpBuffer->clientaddr, 0, sizeof(struct sockaddr_in));
				udpBuffer->len = recvfrom( serverSocket, udpBuffer->buff, SIRIK_SOCKET_UDP_BUFFER_SIZE, 0, (struct sockaddr *) &udpBuffer->clientaddr, &udpBuffer->clientlen);
				
				//printf("fd=%d clientaddr=%p clientlen=%d\n", serverSocket, &udpBuffer->clientaddr, udpBuffer->clientlen);
			}
			else
			{
				udpBuffer->clientlen = sizeof(struct sockaddr_in6);
				//memset( &udpBuffer->clientaddr6, 0, sizeof(struct sockaddr_in6));
				udpBuffer->len = recvfrom( serverSocket, udpBuffer->buff, SIRIK_SOCKET_UDP_BUFFER_SIZE, 0, (struct sockaddr *) &udpBuffer->clientaddr6, &udpBuffer->clientlen);
				
				/*
				int z = 0;
				for( z = 0; z < 16; z++)
				{
					printf( "%02X-", udpBuffer->clientaddr6.sin6_addr.s6_addr[z] & 0xFF);
				}
				printf("\n");
				
				char sIpv6addr[17];
				memcpy( sIpv6addr, udpBuffer->clientaddr6.sin6_addr.s6_addr, 16);
				sIpv6addr[16] = 0;
				
				printf("fd=%d clientaddr6=%p clientlen=%d port=%d addr=%s\n", serverSocket, &udpBuffer->clientaddr6, udpBuffer->clientlen, 
					udpBuffer->clientaddr6.sin6_port, sIpv6addr );
				
				__si_socket_engine_udp_send_response( serverSocket, (struct sockaddr *)&udpBuffer->clientaddr6, udpBuffer->clientlen, udpBuffer->buff, udpBuffer->len);
				*/
			}
			
			//printf("Packet Received UDP-V4 Server Socket = %d Server-IP=%s Port = %d\n", serverSocket, siSocket->IPAddresses[0].IPAddress, iPort);
			
			
			if( udpBuffer->len > 0) 
			{
				//printf( "recv data=%s %d\n", udpBuffer->buff, udpBuffer->len);
				
				if( siSocket->OnUdpPacketReceive > 0)
				{
					udpBuffer->siSocket = siSocket;
					__si_core_queue( (uint8_t *) udpBuffer, (queue_handler) siSocket->OnUdpPacketReceive);
				}
				else
				{
					__si_socket_engine_release_socket_udp_buffer( udpBuffer);
				}
			} 
			else 
			{
				__si_socket_engine_release_socket_udp_buffer( udpBuffer);
			}
		}
	}
}

void __si_socket_engine_sctp_handle_event( void * buf, SI_Socket * siSocket)
{
	#if SCTP_SUPPORT
    struct sctp_assoc_change *sac;
    struct sctp_send_failed  *ssf;
    struct sctp_paddr_change *spc;
    struct sctp_remote_error *sre;
    union sctp_notification  *snp;
    char    addrbuf[INET6_ADDRSTRLEN];
    const char   *ap;
    struct sockaddr_in  *sin;
    struct sockaddr_in6  *sin6;

    snp = buf;
	
	switch (snp->sn_header.sn_type) 
	{
		case SCTP_ASSOC_CHANGE:
			/*
			sac = &snp->sn_assoc_change;
			printf("^^^ assoc_change: state=%hu, error=%hu, instr=%hu outstr=%hu\n", 
				sac->sac_state, 
				sac->sac_error,
				sac->sac_inbound_streams, 
				sac->sac_outbound_streams
			);
			*/
			break;
		case SCTP_SEND_FAILED:
			/*
			ssf = &snp->sn_send_failed;
			printf("^^^ sendfailed: len=%hu err=%d\n", 
					ssf->ssf_length,
					ssf->ssf_error
			);	
			*/
			break;
		case SCTP_PEER_ADDR_CHANGE:
			spc = &snp->sn_paddr_change;
			if (spc->spc_aaddr.ss_family == AF_INET) 
			{
				sin = (struct sockaddr_in *)&spc->spc_aaddr;
				ap = inet_ntop( AF_INET, &sin->sin_addr, addrbuf, INET6_ADDRSTRLEN);
			} 
			else 
			{
				sin6 = (struct sockaddr_in6 *)&spc->spc_aaddr;
				ap = inet_ntop(AF_INET6, &sin6->sin6_addr, addrbuf, INET6_ADDRSTRLEN);
			}
			//printf("^^^ intf_change: %s state=%d, error=%d\n", ap, spc->spc_state, spc->spc_error);
			break;
		case SCTP_REMOTE_ERROR:
			sre = &snp->sn_remote_error;
			//printf( "^^^ remote_error: err=%hu len=%hu\n", ntohs( sre->sre_error), ntohs( sre->sre_length));
			break;
		case SCTP_SHUTDOWN_EVENT:
			//printf("^^^ shutdown event\n");
			break;
		default:
			//printf("unknown type: %hu\n", snp->sn_header.sn_type);
        break;
	}
	
	#endif
}

#define SIRIK_SOCKET_ENGINE_MAX_EPOLL_EVENTS 	20

void __si_socket_engine_sctp_epoll__close_socket( SI_Socket * siSocket)
{
	if( siSocket->isConnected == 1)
	{	
		printf("closing sctp socket  %s|%d\n", __FILE__, __LINE__);
		
		close( siSocket->fd);
		shutdown( siSocket->fd, 2);
		
		siSocket->isConnected = 0;
		
		if( siSocket->epollThread)
		{
			pthread_mutex_lock( &siSocket->epollThread->epollSocketFdCountLock);
			siSocket->epollThread->epollSocketFdCount--;
			pthread_mutex_unlock( &siSocket->epollThread->epollSocketFdCountLock);		
		
			//printf( "siSocket=%p  epollSocketFdCount=%d  %s|%d\n",  siSocket, siSocket->epollThread->epollSocketFdCount, __FILE__, __LINE__);
		}
		
		
		if( siSocket->OnClose > 0)
		{
			siSocket->OnClose( siSocket);
		}
		
		siSocket->epollThread = NULL;
		siSocket->isActive = 0;
		siSocket->isFree = 1;
	}
}

int __si_socket_engine_sctp_epoll_read__handle_notification( SI_Socket * siSocket, SI_SocketSCTPBuffer * sctpBuffer)
{
	#if SCTP_SUPPORT
	
	union sctp_notification  *snp = (union sctp_notification *)sctpBuffer->buff;
	
	if(snp)
	{
		switch( snp->sn_header.sn_type)
		{
			case SCTP_ASSOC_CHANGE:
				{
					struct sctp_assoc_change * sac = &snp->sn_assoc_change;

					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_ASSOC_CHANGE Event Received sac_assoc_id=%d  sac_outbound_streams=%d  sac_inbound_streams=%d <%s|%s|%d>", 
						sac->sac_assoc_id, sac->sac_outbound_streams, sac->sac_inbound_streams, __FILE__, __FUNCTION__, __LINE__);

					siSocket->peer_max_o_streams = sac->sac_outbound_streams;
					siSocket->peer_max_i_streams = sac->sac_inbound_streams;
				}
				break;
			case SCTP_PEER_ADDR_CHANGE:
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_PEER_ADDR_CHANGE Notified <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
				}
				break;
			case SCTP_SHUTDOWN_EVENT:
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_SHUTDOWN_EVENT Notified, closing connection <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
					__si_socket_engine_sctp_epoll__close_socket( siSocket);
				}
				break;
			case SCTP_SEND_FAILED:
				{
					struct sctp_send_failed * fev = &snp->sn_send_failed;
					
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_SEND_FAILED_EVENT Event Received ssf_assoc_id=%d closing connection  <%s|%s|%d>", 
						fev->ssf_assoc_id, __FILE__, __FUNCTION__, __LINE__);					
					
					__si_socket_engine_sctp_epoll__close_socket( siSocket);
				}
				break;
			case SCTP_REMOTE_ERROR:
				{
					struct sctp_remote_error * ree = &snp->sn_remote_error;
					
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_REMOTE_ERROR Event Received sre_assoc_id=%d closing=%d  <%s|%s|%d>", 
								ree->sre_assoc_id,  siSocket->fd, __FILE__, __FUNCTION__, __LINE__);
					
					__si_socket_engine_sctp_epoll__close_socket( siSocket);
				}
				break;
			// case 32776:
				// return 0;
				// break;
			default:
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "Unknown Event Received %d with len=%d  <%s|%s|%d>", 
						snp->sn_header.sn_type, sctpBuffer->len, __FILE__, __FUNCTION__, __LINE__);
					
					siSocket->UnknownSCTPEventCount++;
					
					if( siSocket->UnknownSCTPEventCount > 10)
					{
						__si_socket_engine_sctp_epoll__close_socket( siSocket);
					}
				}
				break;
		}
	}

	#endif
	return 1;
}


void __si_socket_engine_sctp_epoll_read_data( SI_SocketThread * socketThread, struct epoll_event * event)
{
	#if SCTP_SUPPORT
	
	SI_Socket * siSocket = ( SI_Socket *) event->data.ptr;
	if(!siSocket) return;
	if( siSocket->isConnected == 0) return;
	
	SI_SocketSCTPBuffer * sctpBuffer = NULL;

	int flags = 0, n = 0;
	struct sctp_sndrcvinfo sinfo;
	
	
	while(1)
	{
		printf("started sctp recv thread\n");
		
		sctpBuffer = __si_socket_engine_allocate_sctp_socket_buffer();
		if(!sctpBuffer) return;

		memset( &sinfo, 0, sizeof(struct sctp_sndrcvinfo));
		sctpBuffer->pos = 0;

		//printf("waiting here\n");
		n = sctp_recvmsg( siSocket->fd, sctpBuffer->buff, sizeof( sctpBuffer->buff), (struct sockaddr *)NULL, 0, &sinfo, &flags);
		sctpBuffer->len = n;
		
		//printf("EAGAIN=%d sinfo_flags=%d errno=%d n=%d  %s|%d\n", EAGAIN, sinfo.sinfo_flags, errno, n, __FILE__, __LINE__);
		//sleep(1);
		
		if( errno == EBADF /* 9 - Bad File Descriptor */ && n == -1)
		{
			__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
			__si_socket_engine_sctp_epoll__close_socket( siSocket);
			//printf("exit 1\n");
			break;
		}
		
		if( n > 0)
		{
			if( flags & MSG_NOTIFICATION )
			{
				//printf("received sctp flags & MSG_NOTIFICATION  siSocket=%p flags=%d MSG_NOTIFICATION=%d MSG_EOR=%d\n", siSocket, flags, MSG_NOTIFICATION, MSG_EOR);
				
				__si_socket_engine_sctp_epoll_read__handle_notification( siSocket, sctpBuffer);
				__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
			}
			else
			{
				//printf("received sctp siSocket=%p  n=%d  %s|%d\n", siSocket, n, __FILE__, __LINE__);
				
				siSocket->UnknownSCTPEventCount = 0;
				
				sctpBuffer->ppid = ntohl( sinfo.sinfo_ppid);
				sctpBuffer->streamId = sinfo.sinfo_stream;
				sctpBuffer->siThread = socketThread;
				sctpBuffer->siSocket = siSocket; 
				socketThread->TotalReads++;
				siSocket->ReceivedMessages++;
				
				__si_core_queue_item_force( __si_socketEngine->queueSctpSocketBufferPoolObject, sctpBuffer, 1);
			}
		}
		else if( errno == EAGAIN /* 11 */)
		{
			__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
			//printf("exit 2\n");
			break;
		}
		else
		{
			__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
		}

	}
	
	#endif
}


void * __si_socket_engine_sctp_start_epoll_read_thread( void * args)
{
	#if SCTP_SUPPORT
	
	SI_SocketThread * socketThread = (SI_SocketThread *) args;

	
	int n, i;
	struct epoll_event events[ SIRIK_SOCKET_ENGINE_MAX_EPOLL_EVENTS ];
	
	while(1)
	{
		n = epoll_wait( socketThread->epoll_fd, events, SIRIK_SOCKET_ENGINE_MAX_EPOLL_EVENTS, 1000);
		
		if( n <= 0)
		{
			continue;
		}

		//printf("received epoll_wait n=%d  %s|%d\n", n, __FILE__, __LINE__);
		
		for (i = 0; i < n; i++)
		{
			if ( events[i].events & EPOLLIN )
			{
				//printf("received epoll EPOLLIN\n");
				__si_socket_engine_sctp_epoll_read_data( socketThread, &events[i]);
			}
			else if( events[i].events & EPOLLET)
			{
				__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP EPOLLET  %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);
				//printf("received epoll EPOLLET\n");
			}
			else if( events[i].events & EPOLLHUP)
			{
				__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP EPOLLHUP  %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);
				//printf("received epoll EPOLLHUP\n");
			}
			else if( events[i].events & EPOLLERR)
			{
				__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP EPOLLERR  %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);
				//printf("received epoll EPOLLERR\n");
			}
			else
			{
				__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP RECV NOT-SPECIFIC  %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);
				//printf("received epoll -\n");
			}
		}
	}
	
	#endif
	return NULL;
}

void * __si_socket_engine_sctp_start_read_thread( void * args)
{
	#if SCTP_SUPPORT
	
	SI_SocketThread * oThreadHead = (SI_SocketThread *) args;
	
	struct pollfd fds;	
	int ret, flags, n;
	struct sctp_sndrcvinfo sinfo = {0};
	SI_SocketSCTPBuffer * sctpBuffer = NULL;
	int iReConnectCounter = 0;
	int bFirstTime = 1;
	
	while(1)
	{
		/*
			isHost, this is server, and client is connected , 
			and this is reading thread, waiting for signal and active connection to begin poll
		*/
		
		//printf("isHost=%d isActive=%d  %s|%s|%d\n", oThreadHead->isHost, oThreadHead->isActive, __FILE__, __FUNCTION__, __LINE__);
		
		if( oThreadHead->isHost == 1)
		{	
			sem_wait( &oThreadHead->sem_lock);
		}
		else
		{
			/*
				this is client try to connect to server if not connected to server
			*/
			
			if( oThreadHead->isActive == 0)
			{	
				if( bFirstTime == 0)
				{	
					for( iReConnectCounter = 0; iReConnectCounter < 5; iReConnectCounter++)
					{
						usleep( 999999);
					}
				}
				
				bFirstTime = 0;
				
				if( ( ( SI_Socket *) oThreadHead->usiSocket)->isConnected == 0 && ( ( SI_Socket *) oThreadHead->usiSocket)->disableClientAutoReConnect == 0)
				{
					__si_socket_engine_sctp_connect_socket( ( SI_Socket *) oThreadHead->usiSocket);
				}
			}
		}

		
		fds.fd     = oThreadHead->fd;
		//fds.events = POLLIN | POLLRDHUP | POLLERR | POLLHUP;
		fds.events = POLLIN;
		
		//printf("isHost=%d isActive=%d  %s|%s|%d\n", oThreadHead->isHost, oThreadHead->isActive, __FILE__, __FUNCTION__, __LINE__);
		int unknownNotification = 0;
		
		while( oThreadHead->isActive == 1)
		{
			ret = poll( &fds, 1, 1000);
			
			//printf("ret=%d %s|%s|%d\n", ret, __FILE__, __FUNCTION__, __LINE__);
			
			if( ret == 0)
			{
				continue;
			}

			if( ret < 0)
			{
				__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "closing sctp socket fd=%d ret=%d %s|%s|%d", oThreadHead->fd, ret, __FILE__, __FUNCTION__, __LINE__);
				
				close( oThreadHead->fd);
				shutdown( oThreadHead->fd, 2);
				oThreadHead->isActive = 0;
				
				if( oThreadHead->usiSocket)
				{	
					( ( SI_Socket *) oThreadHead->usiSocket)->isConnected = 0;
					
					if( ( ( SI_Socket *) oThreadHead->usiSocket)->OnClose > 0)
					{
						__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp closed socket fd=%d ret=%d calling OnClose %s|%s|%d", oThreadHead->fd, ret, __FILE__, __FUNCTION__, __LINE__);
						
						( ( SI_Socket *) oThreadHead->usiSocket)->OnClose( ( SI_Socket *) oThreadHead->usiSocket);
					}					
				}

				// printf("connection closed %s|%s|%d\n", __FILE__, __FUNCTION__, __LINE__);
				break;
			}

			if( ret > 0)
			{
				sctpBuffer = __si_socket_engine_allocate_sctp_socket_buffer();
				sctpBuffer->pos = 0;
				
				n = sctp_recvmsg( oThreadHead->fd, sctpBuffer->buff, sizeof( sctpBuffer->buff), (struct sockaddr *)NULL, 0, &sinfo, &flags);
				sctpBuffer->len = n;
				
				if( flags & MSG_NOTIFICATION ) 
				{
					union sctp_notification  *snp = (union sctp_notification *)sctpBuffer->buff;
					
					if(snp)
					{
						if( SCTP_ASSOC_CHANGE == snp->sn_header.sn_type)
						{
							struct sctp_assoc_change * sac = &snp->sn_assoc_change;

							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_ASSOC_CHANGE Event Received sac_assoc_id=%d  sac_outbound_streams=%d  sac_inbound_streams=%d <%s|%s|%d>", 
								sac->sac_assoc_id, sac->sac_outbound_streams, sac->sac_inbound_streams, __FILE__, __FUNCTION__, __LINE__);
						
							(( SI_Socket *) oThreadHead->usiSocket)->peer_max_o_streams = sac->sac_outbound_streams;
							(( SI_Socket *) oThreadHead->usiSocket)->peer_max_i_streams = sac->sac_inbound_streams;
						}
						else if( SCTP_PEER_ADDR_CHANGE == snp->sn_header.sn_type)
						{
							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_PEER_ADDR_CHANGE Notified <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
						}
						else if( SCTP_SHUTDOWN_EVENT == snp->sn_header.sn_type )
						{
							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_SHUTDOWN_EVENT Notified, closing connection <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
							
							close( oThreadHead->fd);
							shutdown( oThreadHead->fd, 2);
							oThreadHead->isActive = 0;
							
							if( oThreadHead->usiSocket)
							{	
								( ( SI_Socket *) oThreadHead->usiSocket)->isConnected = 0;
								
								if( ( ( SI_Socket *) oThreadHead->usiSocket)->OnClose > 0)
								{
									__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp closed socket fd=%d calling OnClose %s|%s|%d", oThreadHead->fd, __FILE__, __FUNCTION__, __LINE__);
									
									( ( SI_Socket *) oThreadHead->usiSocket)->OnClose( ( SI_Socket *) oThreadHead->usiSocket);
								}
							}
							
							// printf("connection closed %s|%s|%d\n", __FILE__, __FUNCTION__, __LINE__);
							break;							
						}
						//else if( SCTP_SEND_FAILED_EVENT == snp->sn_header.sn_type)
						else if( SCTP_SEND_FAILED == snp->sn_header.sn_type)	
						{
							//struct sctp_send_failed_event * fev = = &snp->sn_send_failed_event;
							struct sctp_send_failed * fev = &snp->sn_send_failed;
							
							//__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_SEND_FAILED_EVENT Event Received ssfe_assoc_id=%d. closing connection  <%s|%s|%d>", 
							//	fev->ssfe_assoc_id, __FILE__, __FUNCTION__, __LINE__);

							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_SEND_FAILED_EVENT Event Received ssf_assoc_id=%d closing connection  <%s|%s|%d>", 
								fev->ssf_assoc_id, __FILE__, __FUNCTION__, __LINE__);
							
							close( oThreadHead->fd);
							shutdown( oThreadHead->fd, 2);
							oThreadHead->isActive = 0;
							
							if( oThreadHead->usiSocket)
							{	
								( ( SI_Socket *) oThreadHead->usiSocket)->isConnected = 0;
								
								if( ( ( SI_Socket *) oThreadHead->usiSocket)->OnClose > 0)
								{
									__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp closed socket fd=%d calling OnClose %s|%s|%d", oThreadHead->fd, __FILE__, __FUNCTION__, __LINE__);
									
									( ( SI_Socket *) oThreadHead->usiSocket)->OnClose( ( SI_Socket *) oThreadHead->usiSocket);
								}
							}

						}
						else if( SCTP_REMOTE_ERROR == snp->sn_header.sn_type)
						{
							struct sctp_remote_error * ree = &snp->sn_remote_error;
							
							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_REMOTE_ERROR Event Received sre_assoc_id=%d closing=%d  <%s|%s|%d>", 
								ree->sre_assoc_id,  oThreadHead->fd, __FILE__, __FUNCTION__, __LINE__);							
						
							
							close( oThreadHead->fd);
							shutdown( oThreadHead->fd, 2);
							oThreadHead->isActive = 0;
							
							
							if( oThreadHead->usiSocket)
							{	
								( ( SI_Socket *) oThreadHead->usiSocket)->isConnected = 0;
								
								if( ( ( SI_Socket *) oThreadHead->usiSocket)->OnClose > 0)
								{
									( ( SI_Socket *) oThreadHead->usiSocket)->OnClose( ( SI_Socket *) oThreadHead->usiSocket);
								}
							}						
						}
						else 
						{
							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP MSG_NOTIFICATION - Event Received with event=%d, Closing Socket  <%s|%s|%d>", 
								snp->sn_header.sn_type, __FILE__, __FUNCTION__, __LINE__);
						
							unknownNotification++;
						}
							
						
						//SCTP_SEND_FAILED_EVENT
						//SCTP_NOTIFICATIONS_STOPPED_EVENT
						//SCTP_PARTIAL_DELIVERY_EVENT
						//SCTP_ADAPTATION_INDICATION
						//SCTP_REMOTE_ERROR
						
						/*
						else
						{
							printf("sctp notification type=%u\n", snp->sn_header.sn_type);
						}
						*/
						
						if( unknownNotification > 10)
						{
							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP unknownNotification=%d exceeded closing=%d  <%s|%s|%d>", 
								unknownNotification,  oThreadHead->fd, __FILE__, __FUNCTION__, __LINE__);							
						
							
							close( oThreadHead->fd);
							shutdown( oThreadHead->fd, 2);
							oThreadHead->isActive = 0;
							
							
							if( oThreadHead->usiSocket)
							{	
								( ( SI_Socket *) oThreadHead->usiSocket)->isConnected = 0;
								
								if( ( ( SI_Socket *) oThreadHead->usiSocket)->OnClose > 0)
								{
									( ( SI_Socket *) oThreadHead->usiSocket)->OnClose( ( SI_Socket *) oThreadHead->usiSocket);
								}
							}							
							
							unknownNotification = 0;
							__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
							break;
						}
					}
					
					
					__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
				}
				else
				{
					if( (ret == 1 && n == 0) || n < 0)
					{
						__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP error ret=%d n=%d, closing connection <%s|%s|%d>", ret, n, __FILE__, __FUNCTION__, __LINE__);
						
						__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
						close( oThreadHead->fd);
						shutdown( oThreadHead->fd, 2);
						oThreadHead->isActive = 0;
						
						if( oThreadHead->usiSocket)
						{	
							( ( SI_Socket *) oThreadHead->usiSocket)->isConnected = 0;
							
							if( ( ( SI_Socket *) oThreadHead->usiSocket)->OnClose > 0)
							{
								( ( SI_Socket *) oThreadHead->usiSocket)->OnClose( ( SI_Socket *) oThreadHead->usiSocket);
							}							
						}
							
						// printf("connection closed %s|%s|%d\n", __FILE__, __FUNCTION__, __LINE__);
						break;
					}
					
					unknownNotification = 0;
					
					if( n > 0)
					{
						//__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "stream %d, PPID %d.: received-bytes: %d <%s|%s|%d>", sinfo.sinfo_stream, ntohl( sinfo.sinfo_ppid), n, __FILE__, __FUNCTION__, __LINE__);

						SI_Socket * siSocket = (SI_Socket *) oThreadHead->usiSocket;

						sctpBuffer->ppid = ntohl( sinfo.sinfo_ppid);
						sctpBuffer->streamId = sinfo.sinfo_stream;
						sctpBuffer->siThread = oThreadHead;
						sctpBuffer->siSocket = siSocket; 
						oThreadHead->TotalReads++;
						siSocket->ReceivedMessages++;

						//printf("message received from siSocket=%p transportEng=%p\n", siSocket, siSocket->transportEng);
						
						//printf("received data from socket-fd=%d sid=%d\n", siSocket->fd, sctpBuffer->streamId);
						
						//2020-07-03 commented, why we need this?
						/*
						pthread_mutex_lock( &siSocket->BufferLock);
						
						if( !siSocket->SctpBufferHead)
						{
							siSocket->SctpBufferHead = siSocket->SctpBufferCurrent = sctpBuffer;
						}
						else
						{
							siSocket->SctpBufferCurrent->Next = sctpBuffer;
							siSocket->SctpBufferCurrent = sctpBuffer;
						}			

						siSocket->BufferPacketCount++;
						siSocket->BufferLength += sctpBuffer->len;
						
						pthread_mutex_unlock( &siSocket->BufferLock);
						*/
						
						//__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "Adding in Core-Queue <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
						
						////2020-07-03 commented, why we need this?, we will receive complete packet data, no skipping
						//Queue and process complete packet
						//__si_core_queue( (uint8_t *) siSocket, (queue_handler) siSocket->OnBufferReceive);
						
						//commented on 16-06-2021, as messages are not receiving in sequence
						//__si_core_queue( (uint8_t *) sctpBuffer, (queue_handler) siSocket->OnBufferReceive);
						__si_core_queue_item_force( __si_socketEngine->queueSctpSocketBufferPoolObject, sctpBuffer, 1);
						
						
						//__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "Added in Core-Queue <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
						
						
						/*
						if( siSocket->ReadInProgress == 0) 
						{
							__si_core_queue( (uint8_t *) siSocket, (queue_handler) siSocket->OnBufferReceive);
						} 
						else 
						{
							siSocket->ReadSignal++;
							
							if( siSocket->ReadSignal > 10000000) {
								siSocket->ReadSignal = 1;
							}
						}
						*/
					}
					else
					{
						__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
					}
					
				}
				
			}
		}
	}
	
	#endif
}


void __si_socket_get_lksctp_epoll_read_thread( SI_SocketThread ** oThreadHead)
{
	#if SCTP_SUPPORT
	
	pthread_mutex_lock( &__si_socketEngine->lkSctpThreadLock );
	
	if(!__si_socketEngine->lkEpollSctpThreadHead)
	{
		int i = 0;
		for( i = 0;i < __si_socketEngine->InitialSCTPEPollThreads; i++)
		{
			SI_SocketThread * socketThread = (SI_SocketThread *)malloc( sizeof(SI_SocketThread));
			memset( socketThread, 0, sizeof( SI_SocketThread));
			
			if(!__si_socketEngine->lkEpollSctpThreadHead)
			{
				__si_socketEngine->lkEpollSctpThreadHead = __si_socketEngine->lkEpollSctpThreadCurrent = socketThread;
			}
			else
			{
				__si_socketEngine->lkEpollSctpThreadCurrent->Next = socketThread;
				__si_socketEngine->lkEpollSctpThreadCurrent = socketThread;
			}

			socketThread->isHost = 1;
			socketThread->isActive = 1;
			socketThread->epoll_fd = epoll_create1(0);
			socketThread->is_epoll_thread = 1;
			socketThread->index = __si_socketEngine->EPollThreadsCount;
			socketThread->count = 0;
			socketThread->LastReads = 0;
			socketThread->LastTotalReads = 0;
			socketThread->TotalReads = 0;
			socketThread->epollSocketFdCount = 0;
			pthread_mutex_init( &socketThread->CountLock, NULL);			
			pthread_mutex_init( &socketThread->epollSocketFdCountLock, NULL);
			sem_init( &socketThread->sem_lock, 0, 0);
			__si_socketEngine->EPollThreadsCount++;
			
			__si_create_pthread2( __si_socket_engine_sctp_start_epoll_read_thread, socketThread, "si_r_socket");
		}
	}
	
	SI_SocketThread * selThread 	= __si_socketEngine->lkEpollSctpThreadHead;
	SI_SocketThread * threadHead 	= __si_socketEngine->lkEpollSctpThreadHead;
	int epollSocketFdCount = 0;
	
	while(threadHead)
	{
		pthread_mutex_lock( &threadHead->epollSocketFdCountLock);
			epollSocketFdCount = threadHead->epollSocketFdCount;
		pthread_mutex_unlock( &threadHead->epollSocketFdCountLock);
		
		if( epollSocketFdCount < selThread->epollSocketFdCount)
		{
			selThread = threadHead;
		}
		
		threadHead = threadHead->Next;
	}
	
	if( selThread) {
		*oThreadHead = selThread;
	} else {
		*oThreadHead = __si_socketEngine->lkEpollSctpThreadHead;
	}
	
	pthread_mutex_unlock( &__si_socketEngine->lkSctpThreadLock );
	
	#endif
}

void __si_socket_get_lksctp_read_thread( SI_SocketThread ** oThreadHead)
{
	#if SCTP_SUPPORT
	
	pthread_mutex_lock( &__si_socketEngine->lkSctpThreadLock );
	
	int bFound = 0;
	SI_SocketThread * threadHead = __si_socketEngine->lkSctpThreadHead;
	
	while(threadHead)
	{
		if( threadHead->isActive == 0)
		{
			*oThreadHead = threadHead;
			bFound = 1;
			break;
		}		
		
		threadHead = threadHead->Next;
	}
	
	if( bFound == 0)
	{
		//__si_malloc2( sizeof(SI_SocketThread), (uint8_t **) &threadHead);
		//threadHead = (SI_SocketThread *) __si_malloc( sizeof(SI_SocketThread));
		//__si_printMallocStats();	//TODO:CHECH
		threadHead = (SI_SocketThread *)malloc( sizeof(SI_SocketThread));
		memset( threadHead, 0, sizeof( SI_SocketThread));
		
		pthread_mutex_init( &threadHead->epollSocketFdCountLock, NULL);
		sem_init( &threadHead->sem_lock, 0, 0);
		threadHead->isHost = 1;
		
		if(!__si_socketEngine->lkSctpThreadHead)
		{
			__si_socketEngine->lkSctpThreadHead = __si_socketEngine->lkSctpThreadCurrent = threadHead;
		}
		else
		{
			__si_socketEngine->lkSctpThreadCurrent->Next = threadHead;
			__si_socketEngine->lkSctpThreadCurrent = threadHead;
		}
		
		__si_create_pthread2( __si_socket_engine_sctp_start_read_thread, threadHead, "si_r_socket");
		*oThreadHead = threadHead;
	}
	
	pthread_mutex_unlock( &__si_socketEngine->lkSctpThreadLock );
	
	#endif
}

void __si_socket_engine_sctp__close_client_connection( SI_Socket * siSocket)
{
	close( siSocket->fd);
	shutdown( siSocket->fd, 2);
}

void __si_socket_engine__set_sendlock( SI_Socket * siSocket, int i)
{
	siSocket->UseSendLock = i;
}


void __si_socket_engine___sctp_client_attach_to_poll( SI_Socket * siSocket);
void __si_socket_engine_add_socket_to_engine( SI_Socket * siSocket);

SI_Socket * __si_socket_engine_sctp_accept_client_socket( SI_Socket * parent, int fd, void * cli_addr, int cli_len)
{
	SI_Socket * siSocket = NULL;
	#if SCTP_SUPPORT
	
	int bFound = 0;
	pthread_mutex_lock( &parent->ChildLock);

	siSocket = parent->ChildHead;
	
	while( siSocket)
	{
		if( siSocket->isActive == 0 && siSocket->isFree == 1)
		{
			bFound = 1;
			break;
		}
		siSocket = siSocket->Next;
	}
	
	//printf("bFound=%d idle socket  %s|%d\n", bFound, __FILE__, __LINE__);
	
	if( bFound == 0)
	{
		__si_malloc2( sizeof( SI_Socket), (uint8_t **) &siSocket);
		memset( siSocket, 0, sizeof( SI_Socket));

		siSocket->GenId = 0;
		siSocket->id = parent->ChildSocketCount;
		siSocket->Parent = parent;
		siSocket->TransportType = parent->TransportType;
		siSocket->transportEng = NULL;
		siSocket->UseSendLock = 0;
		pthread_mutex_init( &siSocket->SendLock, NULL);
		
		pthread_mutex_init( &siSocket->BufferLock, NULL);	
		pthread_mutex_init( &siSocket->BufferReadLock, NULL);
		pthread_mutex_init( &siSocket->CloseLock, NULL);
	}		

	siSocket->UnknownSCTPEventCount = 0;
	siSocket->BeforeMessageSend = 0;
	siSocket->AfterMessageSent = 0;
	siSocket->ReceivedMessages = 0;
	siSocket->LastMessageSent = 0;
	siSocket->LastReceivedMessages = 0;
	siSocket->UseSendLock = parent->UseSendLock;
	siSocket->UseEPoll = parent->UseEPoll;
	siSocket->isListner = 0;
	
	siSocket->transportEng = NULL;
	siSocket->isHost = 1;
	siSocket->isStarted = 0;
	siSocket->fd = fd;
	int closeFd = 0;
	
	siSocket->cli_len = cli_len;
	memset( siSocket->ClientConnectionId, 0, sizeof(siSocket->ClientConnectionId));
	
	if( siSocket->cli_len == sizeof( struct sockaddr_in))
	{
		memcpy( &siSocket->cli_addr, cli_addr, siSocket->cli_len);
		
		char str[INET_ADDRSTRLEN];
		inet_ntop( AF_INET, &siSocket->cli_addr.sin_addr, str, INET_ADDRSTRLEN);
		siSocket->ai_family = AF_INET;
		
		sprintf( siSocket->ClientConnectionId, "%s-132-%d", str, ntohs( siSocket->cli_addr.sin_port));
	}
	else if( siSocket->cli_len == sizeof( struct sockaddr_in6))
	{
		memcpy( &siSocket->cli_addr6, cli_addr, siSocket->cli_len);
		
		char str[INET6_ADDRSTRLEN];
		inet_ntop( AF_INET6, &siSocket->cli_addr6.sin6_addr, str, INET6_ADDRSTRLEN);
		siSocket->ai_family = AF_INET6;
		
		sprintf( siSocket->ClientConnectionId, "%s-132-%d", str, ntohs(siSocket->cli_addr6.sin6_port));
	}
	
	//printf( "ClientConnectionId=%s\n", siSocket->ClientConnectionId);
	
	// siSocket->Send = __si_socket_engine_tcp_send_socket_data;
	// siSocket->Read = __si_socket_engine_tcp_read_socket_data;
	// siSocket->Close = __si_socket_engine_tcp_close_socket;	
	
	// struct sctp_initmsg peerinitmsg;
	// memset( &peerinitmsg, 0, sizeof( struct sctp_initmsg));
	// socklen_t optlen = sizeof( peerinitmsg);

	// if( getsockopt ( fd, IPPROTO_SCTP, SCTP_INITMSG, &peerinitmsg, &optlen) == 0)
	// {
		// __si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp client optlen=%u max-o-streams=%u max-i-streams=%u  %s|%s|%d", 
			// optlen, peerinitmsg.sinit_num_ostreams, peerinitmsg.sinit_max_instreams, __FILE__, __FUNCTION__, __LINE__);

		// if( peerinitmsg.sinit_num_ostreams > parent->max_o_streams)
		// {
			// siSocket->max_o_streams = parent->max_o_streams;
		// }
		// else
		// {
			// siSocket->max_o_streams = peerinitmsg.sinit_num_ostreams;
		// }

		// if( peerinitmsg.sinit_max_instreams > parent->max_i_streams)
		// {
			// siSocket->max_i_streams = parent->max_i_streams;
		// }
		// else
		// {
			// siSocket->max_i_streams = peerinitmsg.sinit_max_instreams;
		// }
	//}
	// else
	// {
		// siSocket->max_o_streams = parent->max_o_streams;
		// siSocket->max_i_streams = parent->max_i_streams;
	// }
	// __si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp client - max-o-streams=%u max-i-streams=%u  %s|%s|%d", 
			// siSocket->max_o_streams, siSocket->max_i_streams, __FILE__, __FUNCTION__, __LINE__);

	struct sctp_status ss;
	memset( &ss, 0, sizeof(struct sctp_status));
	socklen_t sz = sizeof(struct sctp_status);

	siSocket->peer_max_o_streams = 1;
	siSocket->peer_max_i_streams = 1;
	
	if(sctp_opt_info( fd, 0, SCTP_STATUS, &ss, &sz) == 0)
	{
		//printf("in-streams=%d out-streams=%d\n", ss.sstat_instrms, ss.sstat_outstrms);
		siSocket->peer_max_o_streams = ss.sstat_outstrms;
		siSocket->peer_max_i_streams = ss.sstat_instrms;
	}
	
	// struct sctp_status ss2;
	// memset( &ss2, 0, sizeof(struct sctp_status));
	// printf( "ss2 %d\n", sz);	
	          // //getsockopt ( fd, IPPROTO_SCTP, SCTP_INITMSG, &peerinitmsg, &optlen)
	// int ierror = getsockopt( fd, IPPROTO_SCTP, SCTP_STATUS, &ss2, &sz);
	
	// printf( "ierror=%d %d %d \n", ierror, ss2.sstat_outstrms, ss2.sstat_instrms);


	
	if( parent->OnAccept > 0)
	{
		parent->OnAccept( siSocket, parent);
	}
	
	if( parent->OnBufferReceive > 0)
	{
		siSocket->OnBufferReceive = parent->OnBufferReceive;
	}
	
	siSocket->OnCloseFired = 0;
	pthread_mutex_init( &siSocket->OnCloseLock, NULL);
	
	if( parent->OnClose > 0)
	{
		siSocket->OnClose = parent->OnClose;
	}
	
	if( bFound == 0)
	{	
		parent->ChildSocketCount++;
		
		if( !parent->ChildHead)
		{
			parent->ChildHead = parent->ChildCurrent = siSocket;
		}
		else
		{
			parent->ChildCurrent->Next = siSocket;
			parent->ChildCurrent = siSocket;
		}
	}
	
	if( closeFd == 0)
	{	
		siSocket->GenId++;
		siSocket->isFree = 0;			//Not Free (busy)
		siSocket->isActive = 1;
		siSocket->isConnected = 1;
	}
	
	pthread_mutex_unlock( &parent->ChildLock);
	
	if( closeFd == 0)
	{	
		// __si_socket_engine_attach_to_epoll( siSocket); 
		
		//printf("UseEPoll=%d  %s|%s|%d\n", siSocket->UseEPoll, __FILE__, __FUNCTION__, __LINE__);

		
		if( siSocket->StateFull == 0)			
		{
			SI_SocketThread * oThreadHead = NULL;
			
			if( siSocket->UseEPoll == 0)
			{
				__si_socket_get_lksctp_read_thread( &oThreadHead);

				oThreadHead->usiSocket = ( uint8_t *) siSocket;
				oThreadHead->fd = fd;
				oThreadHead->isActive = 1;
				oThreadHead->isHost = 1;
				memcpy( &oThreadHead->clientaddrbuff, (struct sockaddr *)&cli_addr, cli_len);
				oThreadHead->addrlen = cli_len;
				sem_post( &oThreadHead->sem_lock);
			}
			else if( siSocket->UseEPoll == 1)
			{
				__si_socket_get_lksctp_epoll_read_thread( &oThreadHead);
				
				pthread_mutex_lock( &oThreadHead->epollSocketFdCountLock);
				oThreadHead->epollSocketFdCount++;
				pthread_mutex_unlock( &oThreadHead->epollSocketFdCountLock);
				
				//printf( "siSocket=%p  epollSocketFdCount=%d  %s|%d\n",  siSocket, oThreadHead->epollSocketFdCount, __FILE__, __LINE__);
				

				siSocket->epollThread = oThreadHead;

				struct epoll_event event;
				memset( &event, 0, sizeof(struct epoll_event));
				
				event.data.fd = siSocket->fd;
				event.data.ptr = siSocket;
				
				event.events = EPOLLIN | EPOLLET | EPOLLHUP | EPOLLERR;
		
				siSocket->epoll_fd = oThreadHead->epoll_fd;
				int s = epoll_ctl ( oThreadHead->epoll_fd, EPOLL_CTL_ADD, siSocket->fd, &event);
		
				if (s == -1) 
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "attach failed for new tcp scoket sfd=%d to epoll index=%d with efd=%d (%s|%s|%d)", 
						siSocket->fd, oThreadHead->index, oThreadHead->epoll_fd, __FILE__, __FUNCTION__, __LINE__);
				}
				else
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "attached new tcp scoket sfd=%d to epoll index=%d with efd=%d (%s|%s|%d)", 
						siSocket->fd, oThreadHead->index, oThreadHead->epoll_fd, __FILE__, __FUNCTION__, __LINE__);
				}
				
			
			}
			else if( siSocket->UseEPoll == 2)
			{
				__si_socket_engine_add_socket_to_engine( siSocket);
				__si_socket_engine___sctp_client_attach_to_poll( siSocket);
			}
			
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "attached new sctp connection to read thread fd=%d pfd=%d port=%d genId=%d StateFull=%d", 
				siSocket->fd, parent->fd, parent->IPPort, siSocket->GenId, siSocket->StateFull);
		}
		else
		{
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp accepted new socket, configured to manage attachment by protocol-connector fd=%d pfd=%d port=%d genId=%d StateFull=%d", 
				siSocket->fd, parent->fd, parent->IPPort, siSocket->GenId, siSocket->StateFull);			
		}
	}
	else
	{
		siSocket->transportEng = NULL;
		close( siSocket->fd);
	}
	
	#endif
	return siSocket;
}

uint16_t __si_socket_sctp_next_streamid( uint8_t skipzero, SI_Socket * siSocket)
{
	uint16_t sid = (siSocket->last_o_streams + 1);
	
	if( sid >= siSocket->peer_max_o_streams)
	{
		sid = 0;
		if( skipzero == 1)
			sid = 1;
	}
	siSocket->last_o_streams = sid;
	
	return sid;
}

#if USR_SCTP_SUPPORT
int __si_socket_engine_usrsctp_receive_cb( struct socket * sock, union sctp_sockstore addr, void * data, size_t datalen, struct sctp_rcvinfo rcv, int flags, void * ulp_info)
{
	return 0;
}

void usrsctp_recv_handler( struct socket * socket, void * data, int flags)
{
    // int events;

    // while ((events = usrsctp_get_events(socket)) && (events & SCTP_EVENT_READ)) 
	// {
        // __si_socket_engine__usrsctp_recv_handler( socket);
    // }
}
#endif

void * __si_socket_engine_usrsctp_start_server_socket( void * args)
{
	SI_Socket * siSocket = (SI_Socket *) args;

	
	#if USR_SCTP_SUPPORT

	usrsctp_init( 9899, NULL, __si_socket_engine__sctp_debug_printf);

	#ifdef SCTP_DEBUG
		usrsctp_sysctl_set_sctp_debug_on( SCTP_DEBUG_ALL);
	#endif

	usrsctp_sysctl_set_sctp_blackhole(2);
	usrsctp_sysctl_set_sctp_enable_sack_immediately(1);

    const int on = 1;
    struct sctp_event event;
    uint16_t event_types[] = {
        SCTP_ASSOC_CHANGE,
        SCTP_PEER_ADDR_CHANGE,
        SCTP_REMOTE_ERROR,
        SCTP_SHUTDOWN_EVENT,
        SCTP_ADAPTATION_INDICATION,
        SCTP_PARTIAL_DELIVERY_EVENT
    };

	int i = 0;
	int family = AF_INET;
	if( siSocket->IPVersion == 6)
	{	
		family = AF_INET6;
	}

    if (!(siSocket->sock = usrsctp_socket( family, SOCK_SEQPACKET, IPPROTO_SCTP, NULL, NULL, 0, NULL))) 
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_socket Failed  %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);
		return NULL;
    }

    if (usrsctp_setsockopt( siSocket->sock, IPPROTO_SCTP, SCTP_RECVRCVINFO, &on, sizeof(int)) < 0) 
	{
       __si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_setsockopt SCTP_RECVRCVINFO Failed  %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);
		return NULL;
    }

    memset(&event, 0, sizeof(event));
    event.se_assoc_id = SCTP_FUTURE_ASSOC;
    event.se_on = 1;
    for (i = 0; i < (int)(sizeof(event_types)/sizeof(uint16_t)); i++) 
	{
        event.se_type = event_types[i];
        if (usrsctp_setsockopt( siSocket->sock, IPPROTO_SCTP, SCTP_EVENT, &event, sizeof(struct sctp_event)) < 0) 
		{
            __si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_setsockopt SCTP_EVENT Failed(%d:%s)   %s|%s|%d", errno, strerror( errno ), __FILE__, __FUNCTION__, __LINE__);
            return NULL;
        }
    }
	
	
	
	struct sctp_paddrparams paddrparams;
    socklen_t socklen;

    memset(&paddrparams, 0, sizeof(paddrparams));
    socklen = sizeof(paddrparams);
    if (usrsctp_getsockopt( siSocket->sock, IPPROTO_SCTP, SCTP_PEER_ADDR_PARAMS, &paddrparams, &socklen) != 0) 
	{
        __si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_getsockopt SCTP_PEER_ADDR_PARAMS Failed(%d:%s)  %s|%s|%d", errno, strerror( errno ), __FILE__, __FUNCTION__, __LINE__);
        return NULL;
    }
	
	paddrparams.spp_hbinterval = 5000;

    if (usrsctp_setsockopt( siSocket->sock, IPPROTO_SCTP, SCTP_PEER_ADDR_PARAMS, &paddrparams, sizeof(paddrparams)) != 0) 
	{
        __si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_setsockopt SCTP_PEER_ADDR_PARAMS Failed(%d:%s)  %s|%s|%d", errno, strerror( errno ), __FILE__, __FUNCTION__, __LINE__);
        return NULL;
    }
	
	
	
	struct sctp_rtoinfo rtoinfo;
	socklen = sizeof(rtoinfo);
    if (usrsctp_getsockopt( siSocket->sock, IPPROTO_SCTP, SCTP_RTOINFO, &rtoinfo, &socklen) != 0) 
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_getsockopt SCTP_RTOINFO Failed(%d:%s)  %s|%s|%d", errno, strerror( errno ), __FILE__, __FUNCTION__, __LINE__);
        return NULL;
    }
	
    rtoinfo.srto_initial = 3000;
    rtoinfo.srto_min = 1000;
    rtoinfo.srto_max = 5000;

    if (usrsctp_setsockopt( siSocket->sock, IPPROTO_SCTP, SCTP_RTOINFO, &rtoinfo, sizeof(rtoinfo)) != 0) 
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_setsockopt SCTP_RTOINFO Failed(%d:%s)  %s|%s|%d", errno, strerror( errno ), __FILE__, __FUNCTION__, __LINE__);
        return NULL;
    }
	
	
	
	struct sctp_initmsg initmsg;
	memset(&initmsg, 0, sizeof(struct sctp_initmsg));
    socklen = sizeof(struct sctp_initmsg);
    if (usrsctp_getsockopt( siSocket->sock, IPPROTO_SCTP, SCTP_INITMSG, &initmsg, &socklen) != 0) 
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_getsockopt SCTP_INITMSG Failed(%d:%s)  %s|%s|%d", errno, strerror( errno ), __FILE__, __FUNCTION__, __LINE__);
        return NULL;
    }
	
	initmsg.sinit_num_ostreams 	= 8;
	initmsg.sinit_max_instreams = 8;
	initmsg.sinit_max_attempts 	= 4;
	initmsg.sinit_max_init_timeo = 8000;

    if (usrsctp_setsockopt( siSocket->sock, IPPROTO_SCTP, SCTP_INITMSG, &initmsg, sizeof(initmsg)) != 0) 
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_setsockopt SCTP_INITMSG Failed(%d:%s)  %s|%s|%d", errno, strerror( errno ), __FILE__, __FUNCTION__, __LINE__);
        return NULL;
    }
	


	int optval = 1;
	usrsctp_setsockopt( siSocket->sock, IPPROTO_SCTP, SCTP_NODELAY, &optval, sizeof(int));
	__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_socket SCTP_NODELAY  %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);
	
	

	struct linger so_linger;
	so_linger.l_onoff = 1;
	so_linger.l_linger = 0;
	
	usrsctp_setsockopt( siSocket->sock, SOL_SOCKET, SO_LINGER, &so_linger, sizeof ( struct linger));
	__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_socket SO_LINGER  %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);

	
	if( siSocket->IPVersion == 4)
	{
		struct sockaddr_in addr;
		memset((void *)&addr, 0, sizeof(struct sockaddr_in));
		addr.sin_family = AF_INET;
		addr.sin_port = htons( siSocket->IPPort);
		addr.sin_addr.s_addr = inet_addr( siSocket->IPAddresses[0].IPAddress);

		if (usrsctp_bind( siSocket->sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) < 0) 
		{
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_bind failed   %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);
			return NULL;
		}
	}

	usrsctp_listen( siSocket->sock, 5);
	//usrsctp_set_non_blocking(siSocket->sock, 1);
    //usrsctp_set_upcall( siSocket->sock, usrsctp_recv_handler, NULL);

	socklen_t from_len;
	int flags;
	socklen_t infolen;
	struct sctp_rcvinfo rcv_info;
	unsigned int infotype;
	int n = 0;
	char name[INET6_ADDRSTRLEN];	
	
	SI_SocketSCTPBuffer * sctpBuffer = NULL;
	__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "usrsctp_socket entering loop usrsctp_recvv  %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);
	printf("started sctp port=%d\n", siSocket->IPPort);

	struct sockaddr_in6 addr6;

	while (1) 
	{
		memset( &addr6, 0, sizeof(struct sockaddr_in6));
		memset( name, 0, INET6_ADDRSTRLEN);

		sctpBuffer = __si_socket_engine_allocate_sctp_socket_buffer();
		sctpBuffer->pos = 0;
		
		from_len 	= (socklen_t)sizeof(struct sockaddr_in6);
		flags 		= 0;
		infolen 	= (socklen_t)sizeof(struct sctp_rcvinfo);
		
		n = usrsctp_recvv( siSocket->sock, (void*)sctpBuffer->buff, sizeof( sctpBuffer->buff), (struct sockaddr *) &addr6, &from_len, (void *)&rcv_info, &infolen, &infotype, &flags);
		sctpBuffer->pos = n;
		printf("n=%d\n", n);
		
		if (n <= 0) 
		{
			
		}
		else
		{
			if (flags & MSG_NOTIFICATION) 
			{
			}
			else
			{
				if (infotype == SCTP_RECVV_RCVINFO) 
				{
					printf("Msg of length %llu -X- %s received from %s:%u, complete %d.\n",
						        (unsigned long long)sctpBuffer->pos, sctpBuffer->buff,
						        inet_ntop(AF_INET6, &addr6.sin6_addr, name, INET6_ADDRSTRLEN), ntohs(addr6.sin6_port),
						        (flags & MSG_EOR) ? 1 : 0);					
				}
				else
				{
					printf("Msg of length %llu -X- %s received from %s:%u, complete %d.\n",
						        (unsigned long long)sctpBuffer->pos, sctpBuffer->buff,
						        inet_ntop(AF_INET6, &addr6.sin6_addr, name, INET6_ADDRSTRLEN), ntohs(addr6.sin6_port),
						        (flags & MSG_EOR) ? 1 : 0);
				}
			}
		}
	}
	
	#endif
}


int __si_socket_engine__get_client_ip_port( SI_Socket * socket, char * str, int * port)
{
	if( socket->ai_family == AF_INET)
	{
		inet_ntop( AF_INET, &socket->cli_addr.sin_addr, str, INET_ADDRSTRLEN);
		return 4;
	}
	else if( socket->ai_family == AF_INET6)
	{
		inet_ntop( AF_INET6, &socket->cli_addr6.sin6_addr, str, INET6_ADDRSTRLEN);
		return 6;
	}
	return 0;
}

void * __si_socket_engine_sctp_start_server_socket( void * args)
{
	#if SCTP_SUPPORT
	
	SI_Socket * siSocket = (SI_Socket *) args;
	
	int iPort = siSocket->IPPort;
	int serverSocket = 0;
	struct sockaddr_in cli_addr;
	struct sockaddr_in6 cli_addr6;
	
	printf("start sctp server for port %d ipversion=%d\n", siSocket->IPPort, siSocket->IPVersion);

	if( siSocket->TransportType == SIRIK_TRANSPORT_TYPE_SCTP)
	{
		if( siSocket->IPVersion == SIRIK_IP_VERSION_4) 
		{	
			serverSocket = socket( PF_INET, SOCK_STREAM, IPPROTO_SCTP);
		} 
		else 
		{
			serverSocket = socket( AF_INET6, SOCK_STREAM, IPPROTO_SCTP);
		}
	}
	
	if(serverSocket <= 0)
	{
		printf("TCP Host Server Socket Creation Failed (Host Process) for Port=%d\n", iPort);
		exit(1);
	}
	
	siSocket->fd = serverSocket;
	
	int on = 1, sdconn;
	
	struct sockaddr_in clientaddr;
	struct sctp_initmsg initmsg;
	struct sctp_event_subscribe events;
	memset( &events, 0, sizeof (events));
	events.sctp_data_io_event = 1;
	events.sctp_association_event = 1;
	events.sctp_send_failure_event = 1;
	events.sctp_address_event = 1;
	events.sctp_peer_error_event = 1;
	events.sctp_shutdown_event = 1;	
	
	if ( setsockopt( serverSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) < 0)
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "setsockopt(SO_REUSEADDR) failed for Host-Server Port : %d <%s|%s|%d>", siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
		exit(0);
	}
	

	
	int is = 0;
	struct sockaddr_in serveraddr1;
	struct sockaddr_in6 serveraddr6;
	
	for( is = 0; is < siSocket->IPAddressCount; is++)
	{
		memset( &serveraddr1, 0, sizeof(struct sockaddr_in));
		memset( &serveraddr6, 0, sizeof(struct sockaddr_in6));
		
		serveraddr1.sin_family = AF_INET;
		serveraddr1.sin_port = htons( siSocket->IPPort);

		serveraddr6.sin6_family = AF_INET6;
		serveraddr6.sin6_port = htons( siSocket->IPPort);

		//if( siSocket->IPAddresses[is].IPVersion == 4) 
		if( siSocket->IPVersion == 4)
		{	
			serveraddr1.sin_addr.s_addr = inet_addr( siSocket->IPAddresses[is].IPAddress);
		}
		else
		{
			//printf("//TODO: IPv6 Not Implemented\n");
			//serveraddr1.sin6_addr.s6_addr
			
			if( inet_pton( AF_INET6, siSocket->IPAddresses[is].IPAddress, &serveraddr6.sin6_addr.s6_addr) != 1)
			{
				printf("configured IPv6=%s Address Is Not Valid\n", siSocket->IPAddresses[is].IPAddress);
				exit(0);
			}
			
			serveraddr6.sin6_scope_id = __si_socket__get_sin6_scope_id( (uint8_t *)&serveraddr6.sin6_addr.s6_addr);
			//__si_print_buffer( (char *)&serveraddr6.sin6_addr.s6_addr, 16);
			printf("IPv6=%s if_index=%u\n", siSocket->IPAddresses[is].IPAddress, serveraddr6.sin6_scope_id);
		}
		
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp server socket binding [%d] %s ipv=%u <%s|%s|%d>", is, siSocket->IPAddresses[is].IPAddress, siSocket->IPVersion, __FILE__, __FUNCTION__, __LINE__);
		
		int ierror = 0;
		
		if( siSocket->IPVersion == 4) 
		{
			ierror = sctp_bindx( serverSocket, (struct sockaddr*)&serveraddr1, 1, SCTP_BINDX_ADD_ADDR);
		} 
		else 
		{
			ierror = sctp_bindx( serverSocket, (struct sockaddr*)&serveraddr6, 1, SCTP_BINDX_ADD_ADDR);
		}
		
		if( ierror < 0)
		{	
			if( siSocket->IPVersion == 4) 
			{
				printf("sctp socket sctp_bindx failed with ierror=%d errno=[%u|%s] IPv4=[%s]  %s|%s|%d\n", ierror, errno, strerror(errno), siSocket->IPAddresses[is].IPAddress, __FILE__, __FUNCTION__, __LINE__);
			}
			else
			{
					printf("sctp socket sctp_bindx failed with ierror=%d errno=[%u|%s] IPv6=[%s] sin6_scope_id=%u  %s|%s|%d\n", ierror, errno, strerror(errno), siSocket->IPAddresses[is].IPAddress, serveraddr6.sin6_scope_id, __FILE__, __FUNCTION__, __LINE__);
					__si_print_buffer( (char *)&serveraddr6.sin6_addr.s6_addr, 16);
			}
		}
	}
	
	/*
	siSocket->max_o_streams = 3;
	siSocket->max_i_streams = 3;	
	*/
	
	memset (&initmsg, 0, sizeof (initmsg));
	initmsg.sinit_num_ostreams = 3;
	initmsg.sinit_max_instreams = 3;
	
	if( siSocket->max_o_streams > 0) 
	{
		//get it from config
		initmsg.sinit_num_ostreams = siSocket->max_o_streams;
	}  else  {
		//or assign default value, so that child connections can set to same values (will be inherited from parent SI_Socket)
		siSocket->max_o_streams = initmsg.sinit_num_ostreams;
	}
	
	if( siSocket->max_i_streams > 0)
	{	
		initmsg.sinit_max_instreams = siSocket->max_i_streams;
	} else {
		siSocket->max_i_streams = initmsg.sinit_max_instreams;
	}
	
	//printf("host setsockopt sinit_max_instreams=%u sinit_num_ostreams=%u  %s|%d\n", initmsg.sinit_max_instreams, initmsg.sinit_num_ostreams, __FILE__, __LINE__);
	
	initmsg.sinit_max_attempts = 4;
	
	if( setsockopt ( serverSocket, IPPROTO_SCTP, SCTP_INITMSG, &initmsg, sizeof (initmsg)) < 0 )
	{
		perror("setsockopt( IPPROTO_SCTP, SCTP_INITMSG) failed");
		exit(0);				
	}

	if ( listen( serverSocket, 10) < 0)
	{
		perror("listen() failed");
		exit(0);
	}
	
	int bLaunchThread = 0;
	int addrlen = sizeof(clientaddr);
	char str[INET6_ADDRSTRLEN];
	
	
	int clilen;
	struct sockaddr_in ccli_addr;
	struct sockaddr_in6 ccli_addr6;
	
	while(1)
	{
		memset( &ccli_addr, 0, sizeof( struct sockaddr_in));
		memset( &ccli_addr6, 0, sizeof( struct sockaddr_in6));		
		
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "waiting for new socket for Host-Server Port : %d <%s|%s|%d>", siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
		
		if( siSocket->IPVersion == SIRIK_IP_VERSION_4) 
		{	
			clilen = sizeof( struct sockaddr_in);
			sdconn = accept( serverSocket, (struct sockaddr *) &ccli_addr, (socklen_t *) &clilen);
		}
		else
		{
			clilen = sizeof( struct sockaddr_in6);
			sdconn = accept( serverSocket, (struct sockaddr *) &ccli_addr6, (socklen_t *) &clilen);
		}
		
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "accept new socket with fd=%d for Host-Server Port : %d <%s|%s|%d>", sdconn, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
		
		if( sdconn > 0)
		{
			//getpeername( sdconn, (struct sockaddr *)&clientaddr, (socklen_t *)&addrlen);
			
			if ( setsockopt( sdconn, IPPROTO_SCTP, SCTP_EVENTS, &events, sizeof (events)) < 0) 
			{
				__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "unable to setsockopt for SCTP_EVENTS for new client socket with fd=%d <%s|%s|%d>", sdconn, __FILE__, __FUNCTION__, __LINE__);
			}
			
			int iNoDelay = 1;
			setsockopt( sdconn, IPPROTO_SCTP, SCTP_NODELAY, &iNoDelay, sizeof(int));
	
			if( siSocket->UseEPoll == 1)
			{
				fcntl( sdconn, F_SETFL, fcntl( sdconn, F_GETFL, 0) | O_NONBLOCK);
			}
			
			/*
			struct sctp_initmsg peerinitmsg;
			memset( &peerinitmsg, 0, sizeof( struct sctp_initmsg));
			socklen_t optlen = sizeof( peerinitmsg);
			
			if( getsockopt ( sdconn, IPPROTO_SCTP, SCTP_INITMSG, &peerinitmsg, &optlen) == 0)
			{
				printf( "sinit_num_ostreams=%u sinit_max_instreams=%u optlen=%u peer-ostreams=%u peer-istreams=%u  %s|%s|%d\n", 
					initmsg.sinit_num_ostreams, initmsg.sinit_max_instreams, optlen, 
					peerinitmsg.sinit_num_ostreams, peerinitmsg.sinit_max_instreams, __FILE__, __FUNCTION__, __LINE__);
			}
			*/
			
			if( siSocket->IPVersion == SIRIK_IP_VERSION_4)
			{
				char str[INET_ADDRSTRLEN];
				inet_ntop( AF_INET, &ccli_addr.sin_addr, str, INET_ADDRSTRLEN);

				
				
				/*
				//getting ip as 0.0.0.0
				
				if( __isTrail == 1)
				{
					if( strcmp( str, "127.0.0.1") != 0)
					{
						printf("this is trail version, not accepted connection other than 127.0.0.1, rejected ip address %s v4\n", str);
						close( sdconn);
						continue;
					}
				}
				*/
				
				if( m_is_ip_allowed > 0)
				{
					//int res = m_is_ip_allowed( str, INET_ADDRSTRLEN, 4, ntohs(ccli_addr.sin_port));
					int res = m_is_ip_allowed( str, strlen(str), 4, ntohs(ccli_addr.sin_port));
					
					if( res != 0)
					{
						__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "connection rejected from ipv4-client, fd=%d client-ip=%s port=%d result=%d <%s|%s|%d>", 
							sdconn, str, ntohs(ccli_addr.sin_port), res, __FILE__, __FUNCTION__, __LINE__);
					
						close( sdconn);
						continue;
					}
				}
				
				__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "accepted conn from ipv4-client, fd=%d client-ip=%s port=%d <%s|%s|%d>", 
					sdconn, str, ntohs(ccli_addr.sin_port),__FILE__, __FUNCTION__, __LINE__);
				
				
				__si_socket_engine_sctp_accept_client_socket( siSocket, sdconn, (void *) &ccli_addr, clilen);
			}
			else
			{
				char str[INET6_ADDRSTRLEN];
				inet_ntop( AF_INET6, &ccli_addr6.sin6_addr, str, INET6_ADDRSTRLEN);
				
				

				/*
				if( __isTrail == 1)
				{
					if( strcmp( str, "::1") != 0)
					{
						printf("this is trail version, not accepted connection other than ::1, rejected ip address %s v6\n", str);					
						close( sdconn);
						continue;
					}
				}
				*/

				if( m_is_ip_allowed > 0)
				{
					//int res = m_is_ip_allowed( str, INET6_ADDRSTRLEN, 6, ntohs(ccli_addr6.sin6_port));
					int res = m_is_ip_allowed( str, strlen(str), 6, ntohs(ccli_addr6.sin6_port));
					
					if( res != 0)
					{
						__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "connection rejected from ipv6-client, fd=%d client-ip=%s port=%d <%s|%s|%d>", 
							sdconn, str, ntohs(ccli_addr6.sin6_port),__FILE__, __FUNCTION__, __LINE__);
					
						close( sdconn);
						continue;
					}
				}
				
				__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "accepted conn from ipv6-client, fd=%d client-ip=%s port=%d <%s|%s|%d>", 
					sdconn, str, ntohs(ccli_addr6.sin6_port),__FILE__, __FUNCTION__, __LINE__);	

				__si_socket_engine_sctp_accept_client_socket( siSocket, sdconn, (void *) &ccli_addr6, clilen);
			}
			
		}
		else
		{
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp accept failed with fd=%d for port=%d<%s|%s|%d>", 
				siSocket->fd, iPort, __FILE__, __FUNCTION__, __LINE__);
		}
	}
	#else
		printf("SCTP: -------------- lksctp not enabled   ------------ \n");
	#endif
}

void * __si_socket_engine_tcp_start_server_socket( void * args)
{
	SI_Socket * siSocket = (SI_Socket *) args;
	
	int iPort = siSocket->IPPort;
	int serverSocket = 0;
	struct sockaddr_in cli_addr;
	struct sockaddr_in6 cli_addr6;
	
	printf("start tcp server for port %d ipversion=%d\n", siSocket->IPPort, siSocket->IPVersion);
	
	if( siSocket->TransportType == SIRIK_TRANSPORT_TYPE_TCP)
	{
		if( siSocket->IPVersion == SIRIK_IP_VERSION_4) 
		{	
			serverSocket = socket( PF_INET, SOCK_STREAM, 0);
		} 
		else 
		{
			serverSocket = socket( AF_INET6, SOCK_STREAM, 0);
		}
	}
	
	if(serverSocket <= 0)
	{
		printf("TCP Host Server Socket Creation Failed (Host Process) for Port=%d\n", iPort);
		exit(1);
	}

	int yes = 1;

	if( setsockopt( serverSocket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1)
	{
		printf("TCP setsockopt SO_REUSEADDR failed\n");
		exit(1);
	}

	if( siSocket->IPVersion == SIRIK_IP_VERSION_4)
	{	
		struct sockaddr_in serverAddr;
		memset( &serverAddr, 0, sizeof( struct sockaddr_in));
		serverAddr.sin_family = AF_INET;
		serverAddr.sin_port = htons(iPort);
		serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);

		if( bind( serverSocket, (struct sockaddr *) &serverAddr, sizeof(struct sockaddr)) != 0)
		{
			printf("Server Bind Failed for TCP-V4 Server Socket = %d Server/Port = %d\n", serverSocket, iPort);
			exit(1);
		}
	}
	else
	{
		struct sockaddr_in6 serverAddr6;
		memset( &serverAddr6, 0, sizeof( struct sockaddr_in6));
		serverAddr6.sin6_family = AF_INET6;
		serverAddr6.sin6_port = htons(iPort);
		serverAddr6.sin6_addr = in6addr_any;

		if( bind( serverSocket, (struct sockaddr *) &serverAddr6, sizeof(struct sockaddr_in6)) != 0)
		{
			perror("bind failed\n");
			printf("Server Bind Failed for TCP-V6 Server Socket = %d Server/Port = %d\n", serverSocket, iPort);
			exit(1);
		}		
	}
	
	listen( serverSocket, 5);
	siSocket->fd = serverSocket;

	//int rc = 0;
	//int sendbuf = -1;
	int clilen;
	int connSocketFD;
	struct sockaddr_in ccli_addr;
	struct sockaddr_in6 ccli_addr6;
	
	while(1)
	{
		clilen = 0;
		connSocketFD = 0;
		memset( &ccli_addr, 0, sizeof( struct sockaddr_in));
		memset( &ccli_addr6, 0, sizeof( struct sockaddr_in6));
		
		if( siSocket->IPVersion == SIRIK_IP_VERSION_4)
		{	
			clilen = sizeof( struct sockaddr_in);
		} 
		else 
		{
			clilen = sizeof( struct sockaddr_in6);
		}
		
		if( siSocket->IPVersion == SIRIK_IP_VERSION_4) 
		{
			connSocketFD = accept( siSocket->fd, (struct sockaddr *) &ccli_addr, (socklen_t *) &clilen);
		} 
		else 
		{
			connSocketFD = accept( siSocket->fd, (struct sockaddr *) &ccli_addr6, (socklen_t *) &clilen);
		}
		
		
		if( connSocketFD > 0)
		{	
			if( siSocket->IPVersion == SIRIK_IP_VERSION_4)
			{
				char str[INET_ADDRSTRLEN];
				inet_ntop( AF_INET, &ccli_addr.sin_addr, str, INET_ADDRSTRLEN);


				if( __isTrail == 1)
				{
					if( strcmp( str, "127.0.0.1") != 0)
					{
						printf("this is trail version, not accepted connection other than 127.0.0.1, rejected ip address %s v4\n", str);
						close( connSocketFD);
						continue;
					}
				}
				
				if( m_is_ip_allowed > 0)
				{
					//int res = m_is_ip_allowed( str, INET_ADDRSTRLEN, 4, ntohs(ccli_addr.sin_port));
					int res = m_is_ip_allowed( str, strlen(str), 4, ntohs(ccli_addr.sin_port));
					
					if( res != 0)
					{
						__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "connection rejected from ipv4-client, fd=%d client-ip=%s port=%d <%s|%s|%d>", 
							connSocketFD, str, ntohs(ccli_addr.sin_port),__FILE__, __FUNCTION__, __LINE__);
					
						close( connSocketFD);
						continue;
					}
				}
				
				
			}
			else
			{
				char str[INET6_ADDRSTRLEN];
				inet_ntop( AF_INET6, &ccli_addr6.sin6_addr, str, INET6_ADDRSTRLEN);
				
				if( __isTrail == 1)
				{
					if( strcmp( str, "::1") != 0)
					{
						printf("this is trail version, not accepted connection other than ::1, rejected ip address %s v6\n", str);					
						close( connSocketFD);
						continue;
					}
				}
				
				if( m_is_ip_allowed > 0)
				{
					//int res = m_is_ip_allowed( str, INET6_ADDRSTRLEN, 6, ntohs(ccli_addr6.sin6_port));
					int res = m_is_ip_allowed( str, strlen(str), 6, ntohs(ccli_addr6.sin6_port));
					
					if( res != 0)
					{
						__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "connection rejected from ipv6-client, fd=%d client-ip=%s port=%d <%s|%s|%d>", 
							connSocketFD, str, ntohs(ccli_addr6.sin6_port),__FILE__, __FUNCTION__, __LINE__);
					
						close( connSocketFD);
						continue;
					}
				}
				
				
				
			}
	
			/*
			struct linger so_linger;
			so_linger.l_onoff = 1;
			so_linger.l_linger = 0;
			
			setsockopt( connSocketFD, SOL_SOCKET, SO_LINGER, &so_linger, sizeof ( struct linger));	
			
			fcntl( connSocketFD, F_SETFL, fcntl( connSocketFD, F_GETFL, 0) | O_NONBLOCK);
			
			rc = setsockopt( connSocketFD, SOL_SOCKET, SO_SNDBUF,(char *)&sendbuf, sizeof(sendbuf));
			
			if(rc < 0) 
			{
				printf( "unable to set SO_SNDBUF to socket withc rc=%d, error=%s, errno=%d connSocketFD=%d\n", rc, strerror(errno), errno, connSocketFD);
			}
			*/
			
			//
			
			if( siSocket->IPVersion == SIRIK_IP_VERSION_4)
			{	
				char str[INET_ADDRSTRLEN];
				inet_ntop( AF_INET, &ccli_addr.sin_addr, str, INET_ADDRSTRLEN);
				
				__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "accepted conn from ipv4-client, fd=%d client-ip=%s port=%d <%s|%s|%d>", 
					connSocketFD, str, ntohs(ccli_addr.sin_port),__FILE__, __FUNCTION__, __LINE__);
				
				siSocket->Accept( siSocket, connSocketFD, (void *) &ccli_addr, clilen);
			}
			else
			{
				char str[INET6_ADDRSTRLEN];
				inet_ntop( AF_INET6, &ccli_addr6.sin6_addr, str, INET6_ADDRSTRLEN);
				
				__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "accepted conn from ipv6-client, fd=%d client-ip=%s port=%d <%s|%s|%d>", 
					connSocketFD, str, ntohs(ccli_addr6.sin6_port),__FILE__, __FUNCTION__, __LINE__);				
				
				siSocket->Accept( siSocket, connSocketFD, (void *) &ccli_addr6, clilen);
			}
		}
		else
		{
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "accept failed with fd=%d for port=%d<%s|%s|%d>", 
				siSocket->fd, iPort, __FILE__, __FUNCTION__, __LINE__);
		}
	}
	
	return NULL;
}

void __si_socket_engine_tcp_tls_print_ssl_error_codes()
{
	#if TLS_SOCKET_SUPPORT	
	
	//0
	printf("%d %s %s\n\n", SSL_ERROR_NONE, "SSL_ERROR_NONE", 
		"No error to report. This is set when the value of the ret parameter is greater than 0.");
	//1	
	printf("%d %s %s\n\n", SSL_ERROR_SSL, "SSL_ERROR_SSL", 
		"An error occurred in the SSL library");
	//2
	printf("%d %s %s\n\n", SSL_ERROR_WANT_READ, "SSL_ERROR_WANT_READ", 
		"Processing was not completed successfully because there was no data available for reading, and the socket available for the SSL session is in nonblocking mode. Try the function again at a later time.");
	//3
	printf("%d %s %s\n\n", SSL_ERROR_WANT_WRITE, "SSL_ERROR_WANT_WRITE", 
		"Processing was not completed successfully because the socket associated with the SSL session is blocked from sending data. Try the function again at a later time.");
	//5
	printf("%d %s %s\n\n", SSL_ERROR_SYSCALL, "SSL_ERROR_SYSCALL", 
		"An I/O error occurred. Issue the sock_errno function to determine the cause of the error.");
	//6
	printf("%d %s %s\n\n", SSL_ERROR_ZERO_RETURN, "SSL_ERROR_ZERO_RETURN", 
		"The remote application shut down the SSL connection normally. Issue the SSL_shutdown function to shut down data flow for an SSL session.");
	//7
	printf("%d %s %s\n\n", SSL_ERROR_WANT_CONNECT, "SSL_ERROR_WANT_CONNECT", 
		"Processing was not completed successfully because the SSL session was in the process of starting the session, but it has not completed yet. Try the function again at a later time.");

	#endif	
}

int __si_socket_engine_socket_error_code( SI_Socket * siSocket)
{
	int error_code = 0;
	int error_code_size = sizeof(error_code);
	getsockopt( siSocket->fd, SOL_SOCKET, SO_ERROR, &error_code, &error_code_size);
	return error_code;
}

SI_Queue * __si_allocate_queue();
void __si_release_queue( SI_Queue * _queue);

//__si_queue_thread
void * __si_socket_buffer_queue_thread( void * args)
{
	SI_Thread * threadInfo = NULL;
	__si_malloc2( sizeof( SI_Thread), (uint8_t **) &threadInfo);
	
	memset( threadInfo, 0, sizeof( SI_Thread));
	threadInfo->id = pthread_self();
	threadInfo->isActive = 1;
	threadInfo->LastTimerTick = __si_core_get_server_timer_tick();

	SI_SocketBuffer * socketBuffer = NULL;
	SI_ExecTime execTime;
	
	while(1)
	{
		sem_wait( &__si_socketEngine->buffer_queue_sem_lock);

		pthread_mutex_lock( &__si_socketEngine->BufferQueueLineLock);
		
			socketBuffer = __si_socketEngine->BufferQueueLineHead;
			
			if( socketBuffer) 
			{
				__si_socketEngine->BufferQueueLineHead = socketBuffer->Next;
				socketBuffer->Next = NULL;
				
				__si_socketEngine->BufferQueueLineCount--;
			}
			
		pthread_mutex_unlock( &__si_socketEngine->BufferQueueLineLock);		
		
		if( socketBuffer)
		{
			if( socketBuffer->siSocket)
			{
				socketBuffer->siSocket->AddBuffer( socketBuffer);
			}
		}
		
	}
	
}

void __si_socket_create_buffer_queue_processing_thread()
{
	if( __si_socketEngine->BufferQueueLineThreadCount == 0)
	{	
		__si_socketEngine->BufferQueueLineThreadCount = 1;
		__si_create_pthread2( __si_socket_buffer_queue_thread, NULL, "so_bq");
	}
}


void __si_socket_buffer_queue( SI_SocketBuffer * socketBuffer)
{
	pthread_mutex_lock( &__si_socketEngine->BufferQueueLineLock);
	
	if(!__si_socketEngine->BufferQueueLineHead)
	{
		__si_socketEngine->BufferQueueLineHead = __si_socketEngine->BufferQueueLineCurrent = socketBuffer;
	}
	else
	{
		__si_socketEngine->BufferQueueLineCurrent->Next = socketBuffer;
		__si_socketEngine->BufferQueueLineCurrent = socketBuffer;
	}
	
	__si_socketEngine->BufferQueueLineCount++;
	__si_socketEngine->BufferQueueLineTotalQueuedCount++;

	pthread_mutex_unlock( &__si_socketEngine->BufferQueueLineLock);
	
	sem_post( &__si_socketEngine->buffer_queue_sem_lock);
}

void __si_socket_engine_tcp_read_socket_data( SI_Socket * siSocket, SI_SocketThread * socketThread)
{
	//printf("[%s,%d]\n", __FUNCTION__, __LINE__);
	
	int icount = 0;
	int iReadTimes = 0;
	int tlsContinueCount = 0;
	int tlsCloseSocket = 0;
	
	SI_SocketBuffer * socketBuffer = __si_socket_engine_allocate_socket_buffer();
	int sslError = 0;
	int iSentBytes = 0;
	SI_ExecTime execTime;
	
	if( socketBuffer)
	{	
		//while(icount = read( siSocket->fd , socketBuffer->buff, SIRIK_SOCKET_BUFFER_SIZE))
		while(1)
		{	
			#if TLS_SOCKET_SUPPORT		
				if( siSocket->TlsEnabled == 1)
				{
					pthread_mutex_lock( &siSocket->ioLock);
					icount = SSL_read( siSocket->ssl, socketBuffer->buff, SIRIK_SOCKET_BUFFER_SIZE);
					pthread_mutex_unlock( &siSocket->ioLock);
					
					if( icount <= 0)
					{	
						sslError = SSL_get_error( siSocket->ssl, icount);
				
						if( SSL_ERROR_WANT_WRITE == sslError)
						{
							__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "not closing want SSL_write at SSL_read, icount=%d, sslError=%d <%s|%s|%d>", 
								icount, sslError, __FILE__, __FUNCTION__, __LINE__);
							
							pthread_mutex_lock( &siSocket->ioLock);
							iSentBytes = SSL_write( siSocket->ssl, 0x0, 0);
							pthread_mutex_unlock( &siSocket->ioLock);
							
							if( iSentBytes < 0)
							{	
								tlsCloseSocket = 1;
								__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "closing socket fd=%d iSentBytes=%d for tls write error while read <%s|%s|%d>", 
									siSocket->fd, iSentBytes, __FILE__, __FUNCTION__, __LINE__);
								break;	
							}
							continue;
						}
					}
					
					if( icount == 0)
					{
						__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "SSL required read for ssl fd=%d icount=%d sslError=%d <%s|%s|%d>", siSocket->fd, icount, sslError, __FILE__, __FUNCTION__, __LINE__);
						
						//START on July-09 2020
						//continue;
						tlsCloseSocket = 1;
						//END on July-09 2020
						
					}
					else if( icount < 0)
					{
						if ( SSL_ERROR_WANT_READ == sslError)
						{
							if( SSL_pending( siSocket->ssl) > 0)
							{
								//usleep(100);
								__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "SSL required read for ssl fd=%d icount=%d <%s|%s|%d>", siSocket->fd, icount, __FILE__, __FUNCTION__, __LINE__);
								continue;
							}
							
							tlsContinueCount++;
							__si_socketEngine->TlsTotalReadContinueCount++;
							
							if( tlsContinueCount > 5)
							{
								int isSocketErorCode = __si_socket_engine_socket_error_code( siSocket);

								if( isSocketErorCode != 0)
								{
									tlsCloseSocket = 1;
									__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "closing socket fd=%d for tls reads exceeded , isSocketErorCode=%d <%s|%s|%d>", 
										siSocket->fd, isSocketErorCode, __FILE__, __FUNCTION__, __LINE__);
								}
									
								break;
							}
							
							continue;
						}
						else
						{
							tlsCloseSocket = 1;
							__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "closing socket fd=%d as SSL read sslError=%d error=%d err=%s lerror=%s[%d] icount[%d] <%s|%s|%d>", 
								siSocket->fd, sslError, ERR_get_error(), ERR_error_string( ERR_get_error(), NULL), strerror( errno), errno, icount, 
								__FILE__, __FUNCTION__, __LINE__);
							break;
						}
					}
				}
				else
				{
					icount = read( siSocket->fd , socketBuffer->buff, SIRIK_SOCKET_BUFFER_SIZE);
					//printf("[%s,%d] icount=%d iReadTimes=%d\n", __FUNCTION__, __LINE__, icount, iReadTimes);
				}					
			#else
				icount = read( siSocket->fd , socketBuffer->buff, SIRIK_SOCKET_BUFFER_SIZE);
			#endif
	
			if( icount > 0)
			{
				socketBuffer->pos = 0;
				socketBuffer->len = icount;
				socketBuffer->siSocket = siSocket;
				
				//__si_core_queue( (uint8_t *) socketBuffer, (queue_handler) siSocket->AddBuffer);
				//async queue will miss buffer sequence  
				
				//__si_StartExecTime( &execTime);
				
				siSocket->AddBuffer( socketBuffer);
				//__si_socket_buffer_queue( socketBuffer);
				
				//__si_EndExecTime( &execTime);
				
				/*
				__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "received data from socket fd=%d len=%d dt: %ld-%ld <%s|%s|%d>", 
					siSocket->fd, icount, execTime.lapsed.tv_sec, execTime.lapsed.tv_usec, __FILE__, __FUNCTION__, __LINE__);
				*/
				
				socketThread->TotalReads++;
				socketBuffer = __si_socket_engine_allocate_socket_buffer();
				iReadTimes++;
			}
			else
			{
				__si_socket_engine_release_socket_buffer( socketBuffer);
				socketBuffer = NULL;
				break;
			}
		}
		
		//printf("[%s,%d] icount=%d iReadTimes=%d\n", __FUNCTION__, __LINE__, icount, iReadTimes);
		//&& siSocket->TlsEnabled == 0
		if( (icount <= 0 && socketBuffer) )
		{
			__si_socket_engine_release_socket_buffer( socketBuffer);
			socketBuffer = NULL;
		}
		
		//printf("[%s,%d] icount=%d iReadTimes=%d\n", __FUNCTION__, __LINE__, icount, iReadTimes);
		
		//The number of bytes available in the buffer, 0 if end of file; (TCP only) otherwise SOCKET_ERROR.
		
		//&& (errno == EPIPE || errno == 104)
		
		//if( (iReadTimes == 0) && siSocket->TlsEnabled == 0 && icount < 0)
		if( (iReadTimes == 0) && siSocket->TlsEnabled == 0 && (icount < 0))
		{
			int isSocketErorCode = __si_socket_engine_socket_error_code( siSocket);
			
			//if( isSocketErorCode != 0)
			//{	
				socketThread->count--;
				__si_socketEngine->TotalSocketsCount--;
			
				__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "closing socket fd=%d as ReadTimes=0 isSocketErorCode=%d icount=%d errno=%d err=%s EPIPE(%d) <%s|%s|%d>", 
					siSocket->fd, isSocketErorCode, icount, errno, strerror(errno), EPIPE, __FILE__, __FUNCTION__, __LINE__);
					
				siSocket->Close( siSocket);
			//}
			/*
			else
			{
				__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "attempt to close socket fd=%d as ReadTimes=0 isSocketErorCode=%d <%s|%s|%d>", 
					siSocket->fd, isSocketErorCode, __FILE__, __FUNCTION__, __LINE__);
			}
			*/
		}
		
		// printf("[%s,%d] icount=%d\n", __FUNCTION__, __LINE__, icount);
		if( tlsCloseSocket == 1)
		{
			if( socketBuffer )
			{	
				__si_socket_engine_release_socket_buffer( socketBuffer);
				socketBuffer = NULL;
			}

			socketThread->count--;
			__si_socketEngine->TotalSocketsCount--;
			
			siSocket->Close( siSocket);			
		}
	}
	else
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "socket buffer allocation failed <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
	}
	
}

void __si_socket_engine_tcp_release_socket_all_packets( SI_Socket * siSocket);


void __si_socket_engine_tcp_close_socket( SI_Socket * siSocket)
{
	//printf("[%s,%s,%d]calling close and shutdown socket functions\n", __FILE__, __FUNCTION__, __LINE__);
	
	pthread_mutex_lock( &siSocket->CloseLock );

	if( (siSocket->isActive == 0 && siSocket->isConnected == 0))
	{
		if( siSocket->BufferPacketCount > 0) {
			__si_socket_engine_tcp_release_socket_all_packets( siSocket);
		}
		
		pthread_mutex_unlock( &siSocket->CloseLock );
		return;
	}
	
	//__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "closing tcp socket connection fd=%d genId=%d BufferPacketCount=%d isActive=%d <%s|%d>", 
	//	siSocket->fd, siSocket->GenId, siSocket->BufferPacketCount, siSocket->isActive, __FILE__, __LINE__);
	
	if( siSocket->isConnected == 1)
	{
		siSocket->isConnected = 0;
		siSocket->isActive = 0;
		
		//printf("closing socket %p \n", siSocket);
		
		close( siSocket->fd);
		//shutdown( siSocket->fd, 2);			-- 2 causing application exit
		//shutdown( siSocket->fd, 0);
		
		/*
		if( siSocket->isHost == 1) {	
			shutdown( siSocket->fd, 2);
		} else {
			shutdown( siSocket->fd, 0);
		}
		*/
		
		__si_socketEngine->SocketClosedCount++;
	}
	
	//no lock inside lock
		
	//remove buffer list
	pthread_mutex_lock( &siSocket->BufferLock);
	siSocket->BufferLength = 0;
	
	SI_SocketBuffer * socketBuffer = siSocket->BufferHead;
	SI_SocketBuffer * socketBufferNext;
	
	while( socketBuffer)
	{
		socketBufferNext = socketBuffer->Next;
		__si_socket_engine_release_socket_buffer( socketBuffer);
		
		siSocket->BufferPacketCount--;
		socketBuffer = socketBufferNext;
	}
	
	siSocket->BufferHead = siSocket->BufferCurrent = NULL;
	
	pthread_mutex_unlock( &siSocket->BufferLock);

	//notify upper layer
	if( siSocket->OnClose > 0)
	{
		siSocket->OnClose( siSocket);
	}
	else
	{
		printf("[%s,%s,%d] parent not registered to onclose event of socket\n", __FILE__, __FUNCTION__, __LINE__);
	}

	siSocket->isFree = 1;
	pthread_mutex_unlock( &siSocket->CloseLock );
	
	__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "closed tcp socket connection fd=%d genId=%d BPC=%d isActive=%d ip=%s port=%d  <%s|%d>", 
		siSocket->fd, siSocket->GenId, siSocket->BufferPacketCount, siSocket->isActive, 
		siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __LINE__);
}

//int itotal_packets_received = 0;
//int itotal_packets_buffer_size = 0;

void __si_socket_engine_add_buffer_to_socket( SI_SocketBuffer * socketBuffer)
{
	SI_Socket * siSocket = socketBuffer->siSocket;
	
	pthread_mutex_lock( &siSocket->BufferLock);
	
	//itotal_packets_received++;
	//itotal_packets_buffer_size += socketBuffer->len;
	
	if( !siSocket->BufferHead)
	{
		siSocket->BufferHead = siSocket->BufferCurrent = socketBuffer;
	}
	else
	{
		siSocket->BufferCurrent->Next = socketBuffer;
		siSocket->BufferCurrent = socketBuffer;
	}
	
	siSocket->BufferPacketCount++;
	siSocket->BufferLength += socketBuffer->len;
	
	pthread_mutex_unlock( &siSocket->BufferLock);

	//printf("itotal_packets_received=%d itotal_packets_buffer_size=%d\n", itotal_packets_received, itotal_packets_buffer_size);
	
	/*
	printf("Recv BufferLength=%d BufferPacketCount=%d OnBufferReceive=%p itotal_packets_received=%d\n", 
		siSocket->BufferLength, siSocket->BufferPacketCount, siSocket->OnBufferReceive, itotal_packets_received);
	*/
	
	//siSocket->OnBufferReceive( siSocket);
	
	//__si_core_queue( (uint8_t *) siSocket, (queue_handler) siSocket->OnBufferReceive);
	
	
	if( siSocket->ReadInProgress == 0) {
		//__si_core_queue( (uint8_t *) siSocket, (queue_handler) siSocket->OnBufferReceive);
		__si_core_queue_item_force( __si_socketEngine->bufferQueue, siSocket, 1);			//05-JULY-2022
	} else {
		siSocket->ReadSignal++;
		
		if( siSocket->ReadSignal > 10000000) {
			siSocket->ReadSignal = 1;
		}
	}
	/**/
}

int __si_socket_engine_tcp_get_sample_buffer( SI_Socket * siSocket, char * data, int length)
{
	if( siSocket->isActive == 0) return 0;
	
	int readed_bytes = 0;
	int pos = 0;
	
	SI_SocketBuffer * socketBuffer = NULL;
	
	//pthread_mutex_lock( &siSocket->BufferLock);
	socketBuffer = siSocket->BufferHead;
	//pthread_mutex_unlock( &siSocket->BufferLock);	
	
	while( readed_bytes < length)
	{
		if( !socketBuffer)
		{
			break;
		}

		pos = socketBuffer->pos;
		while( pos < socketBuffer->len && readed_bytes < length)
		{
			data[readed_bytes] = socketBuffer->buff[ pos];
			
			readed_bytes++;
			pos++;
		}
		socketBuffer = socketBuffer->Next;
	}
	return readed_bytes;
}

int __si_socket_engine_tcp_get_buffer( SI_Socket * siSocket, char * data, int length)
{
	if( siSocket->isActive == 0) return 0;
	
	int readed_bytes = 0;
	
	/*
	__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "current-buffer len=%d req=%d packet-count=%d <%s|%s|%d>", 
		siSocket->BufferLength, length, siSocket->BufferPacketCount, __FILE__, __FUNCTION__, __LINE__);
	*/
	
	SI_SocketBuffer * socketBuffer = NULL;
	
	//pthread_mutex_lock( &siSocket->BufferLock);
		socketBuffer = siSocket->BufferHead;
	//pthread_mutex_unlock( &siSocket->BufferLock);
	
	while( readed_bytes < length)
	{
		if( !socketBuffer)
		{
			break;
		}

		while( socketBuffer->pos < socketBuffer->len && readed_bytes < length)
		{
			data[readed_bytes] = socketBuffer->buff[ socketBuffer->pos];
			
			readed_bytes++;
			socketBuffer->pos++;
		}
		
		socketBuffer = socketBuffer->Next;
	}
	
	pthread_mutex_lock( &siSocket->BufferLock);
	siSocket->BufferLength -= readed_bytes;
	pthread_mutex_unlock( &siSocket->BufferLock);
	
	return readed_bytes;
}

void __si_socket_engine_tcp_release_socket_all_packets( SI_Socket * siSocket)
{
	pthread_mutex_lock( &siSocket->BufferLock);
	
	SI_SocketBuffer * socketBuffer = siSocket->BufferHead;
	
	while( socketBuffer)
	{
		siSocket->BufferHead = socketBuffer->Next;
		socketBuffer->Next = NULL;
		
		__si_socket_engine_release_socket_buffer( socketBuffer);
		siSocket->BufferPacketCount--;
		
		socketBuffer = siSocket->BufferHead;
	}
	
	siSocket->BufferHead = NULL;
	
	pthread_mutex_unlock( &siSocket->BufferLock);	
}


void __si_socket_engine_tcp_release_socket_head_packet( SI_Socket * siSocket)
{
	pthread_mutex_lock( &siSocket->BufferLock);	
	
	SI_SocketBuffer * socketBuffer = siSocket->BufferHead;
	
	if( socketBuffer)
	{
		siSocket->BufferHead = socketBuffer->Next;
		socketBuffer->Next = NULL;
		
		__si_socket_engine_release_socket_buffer( socketBuffer);
		siSocket->BufferPacketCount--;
	}
	
	pthread_mutex_unlock( &siSocket->BufferLock);
}

void __si_socket_engine_tcp_release_used_buffer( SI_Socket * siSocket)
{
	pthread_mutex_lock( &siSocket->BufferLock);
	
	SI_SocketBuffer * socketBuffer = siSocket->BufferHead;
	SI_SocketBuffer * prevSocketBuffer = NULL;
	
	while( socketBuffer)
	{
		if( socketBuffer->pos == socketBuffer->len)
		{
			prevSocketBuffer = socketBuffer;
			socketBuffer = socketBuffer->Next;
			
			prevSocketBuffer->Next = NULL;
			siSocket->BufferPacketCount--;
			
			__si_socket_engine_release_socket_buffer( prevSocketBuffer);
			
			continue;
		}
		break;
	}
	
	siSocket->BufferHead = socketBuffer;
	
	pthread_mutex_unlock( &siSocket->BufferLock);
}

int __si_socket_engine_buffer_data_length( SI_Socket * siSocket)
{
	if( siSocket->isActive == 0) return 0;
	
	return siSocket->BufferLength;
}

void __si_socket_engine_start_server_socket( SI_Socket * siSocket)
{
	// printf( "isHost=%d  TransportType=%d   %s|%d\n", siSocket->isHost, siSocket->TransportType, __FILE__, __LINE__);


	if( siSocket->isHost == 1)
	{
		if( siSocket->isStarted == 0)
		{
			siSocket->isStarted = 1;
			
			if( siSocket->TransportType == SIRIK_TRANSPORT_TYPE_TCP)
			{
				__si_create_pthread2( __si_socket_engine_tcp_start_server_socket, siSocket, "si_s_socket");
			}
			else if( siSocket->TransportType == SIRIK_TRANSPORT_TYPE_UDP)
			{
				__si_create_pthread2( __si_socket_engine_udp_start_server_socket, siSocket, "si_s_socket");
			}
			else if( siSocket->TransportType == SIRIK_TRANSPORT_TYPE_SCTP)
			{
				// we are only with lksctp
				// if( siSocket->UseEPoll == 5) {
					// __si_create_pthread2( __si_socket_engine_usrsctp_start_server_socket, siSocket, "si_usr_sock");
				// } else {
					__si_create_pthread2( __si_socket_engine_sctp_start_server_socket, siSocket, "si_s_socket");
				//}	
			}
			else
			{
				printf("invalid transport type\n");
			}
		}
		
		usleep( 100000);	// give time to init socket server thread
		
	}
}

void __si_socket_engine_add_socket_to_engine_for_epoll_async( SI_Socket * siSocket)
{
	pthread_mutex_lock( &__si_socketEngine->SocketAyncWriteLock);
	
	if( !__si_socketEngine->SocketEPollAyncWriteHead)
	{
		__si_socketEngine->SocketEPollAyncWriteHead = __si_socketEngine->SocketEPollAyncWriteCurrent = siSocket;
	}
	else
	{
		__si_socketEngine->SocketEPollAyncWriteCurrent->SENext = siSocket;
		__si_socketEngine->SocketEPollAyncWriteCurrent = siSocket;
	}
	
	pthread_mutex_unlock( &__si_socketEngine->SocketAyncWriteLock);	
}

void __si_socket_engine_add_socket_to_engine( SI_Socket * siSocket)
{
	pthread_mutex_lock( &__si_socketEngine->SocketLock);
	
	int bFound = 0;
	
	SI_Socket * siSocketTemp = __si_socketEngine->SocketHead;
	
	while(siSocketTemp)
	{
		if( siSocketTemp == siSocket)
		{
			bFound = 1;
			break;
		}
		siSocketTemp = siSocketTemp->Next;
	}
	
	if( bFound == 0)
	{
		if( !__si_socketEngine->SocketHead)
		{
			__si_socketEngine->SocketHead = __si_socketEngine->SocketCurrent = siSocket;
			//printf("Socket=%p TransportType=%d  added to head %d|%s\n", siSocket, siSocket->TransportType, __LINE__, __FILE__);
		}
		else
		{
			__si_socketEngine->SocketCurrent->Next = siSocket;
			__si_socketEngine->SocketCurrent = siSocket;
			//printf("Socket=%p TransportType=%d  added to current %d|%s\n", siSocket, siSocket->TransportType, __LINE__, __FILE__);
		}
	}
	
	pthread_mutex_unlock( &__si_socketEngine->SocketLock);
}




void * __si_socket_engine_epoll_thread( void * args);


void __si_socket_engine_attach_to_epoll( SI_Socket * siSocket)
{
	/*
	int index = __si_socketEngine->TotalSocketsCount % __si_socketEngine->EPollThreadsCount;
	
	SI_SocketThread * socketThread = __si_socketEngine->ThreadHead;
	
	uint8_t bFound = 0;
	
	while( socketThread)
	{
		if( socketThread->is_epoll_thread == 1 && socketThread->index == index)
		{
			bFound = 1;
			break;
		}
		
		socketThread = socketThread->Next;
	}
	
	if( !bFound)
	{
		socketThread = __si_socketEngine->ThreadHead;
		
		while( socketThread)
		{
			if( socketThread->is_epoll_thread == 1)
			{
				bFound = 1;
				break;
			}
			
			socketThread = socketThread->Next;			
		}
	}
	*/
	
	
	/*
		while( socketThread)
		{
			if( socketThread->is_epoll_thread == 1 && socketThread->LastReads < 10000)
			{
				bFound = 1;
				break;
			}
			
			socketThread = socketThread->Next;
		}
	*/
	
	//printf( "EPollThreadsCount=%d\n", __si_socketEngine->EPollThreadsCount);
	
	
	pthread_mutex_lock( &__si_socketEngine->ThreadLock);
	
	int maxEpollThreads = 3;
	int bCreateThread = 0;
	
	SI_SocketThread * socketThread = NULL;
	
	if( __si_socketEngine->EPollThreadsCount >= 0 && __si_socketEngine->EPollThreadsCount < maxEpollThreads)
	{
		int TotalLastReads = 0;
		socketThread = __si_socketEngine->ThreadHead;

		while( socketThread)
		{
			TotalLastReads += socketThread->LastReads;
			socketThread = socketThread->Next;
		}
		
		if( TotalLastReads > 5000 && __si_socketEngine->EPollThreadsCount == 2)
		{
			bCreateThread = 1;
			//printf( "bCreateThread=%d %d\n", bCreateThread, __LINE__);
		}
		/*
		else if( TotalLastReads > 10000 && __si_socketEngine->EPollThreadsCount == 3)
		{
			bCreateThread = 1;
			//printf( "bCreateThread=%d %d\n", bCreateThread, __LINE__);
		}
		*/
	}
	
	uint8_t bFound = 0;
	
	if( __si_socketEngine->EPollThreadsCount == 0)
	{
		bCreateThread = 1;
		//printf( "bCreateThread=%d %d\n", bCreateThread, __LINE__);
	}
	
	if( bCreateThread == 0 && __si_socketEngine->ThreadHead)
	{	
		bFound = 1;
		
		socketThread = __si_socketEngine->ThreadHead;
		SI_SocketThread * socketThread2 = socketThread->Next;
		
		/*
		while( socketThread)
		{
			if( socketThread->is_epoll_thread == 1 && socketThread->LastReads < 10000)
			{
				bFound = 1;
				break;
			}
			
			socketThread = socketThread->Next;
		}
		*/
		
		SI_SocketThread * selectedThread = socketThread;
		
		while( socketThread)
		{
			if( socketThread != selectedThread && socketThread->count < selectedThread->count)
			{
				selectedThread = socketThread;
			}
			
			socketThread = socketThread->Next;
		}
		
		if(!selectedThread)
		{	
			selectedThread = __si_socketEngine->ThreadHead;
		}
		
		socketThread = selectedThread;
	}
	
	if( !bFound)
	{
		socketThread = NULL;
		
		__si_malloc2( sizeof(SI_SocketThread), (uint8_t **) &socketThread);
		memset( socketThread, 0, sizeof( SI_SocketThread));
		
		if(!__si_socketEngine->ThreadHead)
		{
			__si_socketEngine->ThreadHead = __si_socketEngine->ThreadCurrent = socketThread;
		}
		else
		{
			__si_socketEngine->ThreadCurrent->Next = socketThread;
			__si_socketEngine->ThreadCurrent = socketThread;
		}
		
		socketThread->epoll_fd = epoll_create1(0);
		socketThread->is_epoll_thread = 1;
		socketThread->index = __si_socketEngine->EPollThreadsCount;
		socketThread->count = 0;
		socketThread->LastReads = 0;
		socketThread->LastTotalReads = 0;
		socketThread->TotalReads = 0;
		__si_socketEngine->EPollThreadsCount++;
		pthread_mutex_init( &socketThread->epollSocketFdCountLock, NULL);
		
		pthread_mutex_init( &socketThread->CountLock, NULL);
		
		__si_create_pthread2( __si_socket_engine_epoll_thread, socketThread, "si_epoll");
		
		bFound = 1;
	}
	
	if( bFound)
	{
		struct epoll_event event;
		memset( &event, 0, sizeof(struct epoll_event));
		
		event.data.fd = siSocket->fd;
		event.data.ptr = siSocket;
		
		event.events = EPOLLIN | EPOLLET | EPOLLHUP | EPOLLERR;
		
		siSocket->epoll_fd = socketThread->epoll_fd;
		int s = epoll_ctl ( socketThread->epoll_fd, EPOLL_CTL_ADD, siSocket->fd, &event);
		
		socketThread->count++;
		__si_socketEngine->TotalSocketsCount++;
		
		/*
		printf( "attached to epoll_fd=%d total_epoll_fds=%d sock_fd=%d total_sockets=%d\n", 
			socketThread->epoll_fd, __si_socketEngine->EPollThreadsCount,
			siSocket->fd, __si_socketEngine->TotalScoketsCount);
		*/
		
		if (s == -1) 
		{
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "attach failed for new tcp scoket sfd=%d to epoll index=%d with efd=%d (%s|%s|%d)", 
				siSocket->fd, socketThread->index, socketThread->epoll_fd, __FILE__, __FUNCTION__, __LINE__);
		}
		else
		{
			__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "attached new tcp scoket sfd=%d to epoll index=%d with efd=%d (%s|%s|%d)", 
				siSocket->fd, socketThread->index, socketThread->epoll_fd, __FILE__, __FUNCTION__, __LINE__);
		}
	}
	
	pthread_mutex_unlock( &__si_socketEngine->ThreadLock);
}

void __si_socket_engine_tcp_send_socket_data_aync( SI_Socket * siSocket, char * buff, int len)
{
	SI_SocketAyncBuffer * bufferPoolItem = (SI_SocketAyncBuffer *) __si_allocM7( sizeof(SI_SocketAyncBuffer), __FILE__, __LINE__, 0);
	
	if( bufferPoolItem)
	{	
		memset( bufferPoolItem, 0, sizeof(SI_SocketAyncBuffer));
		bufferPoolItem->buff = ( char *) __si_allocM7( len + 1, __FILE__, __LINE__, 0);
		
		if( bufferPoolItem->buff)
		{	
			memcpy( bufferPoolItem->buff, buff, len);
			bufferPoolItem->buff[len] = '\0';
			bufferPoolItem->len = len;
			bufferPoolItem->Next = NULL;
			
			pthread_mutex_lock( &siSocket->AsyncWriteLock);
			
			if(!siSocket->AyncWriteBufferHead)
			{
				siSocket->AyncWriteBufferHead = siSocket->AyncWriteBufferCurrent = bufferPoolItem;
			}
			else
			{
				siSocket->AyncWriteBufferCurrent->Next = bufferPoolItem;
				siSocket->AyncWriteBufferCurrent = bufferPoolItem;
			}
			
			pthread_mutex_unlock( &siSocket->AsyncWriteLock);
		}
		else
		{
			__si_freeMV( bufferPoolItem);
		}
	}
}

void __si_socket_engine_udp_close_socket( SI_Socket * siSocket)
{
	
}
void __si_socket_engine_udp_read_socket_data( SI_Socket * siSocket, SI_SocketThread * socketThread)
{
	
}

int __si_socket_engine_udp_connect_socket( SI_Socket * siSocket)
{
	struct addrinfo hints;
	struct addrinfo * result, * rp;
	int sfd = 0, s = 0, j = 0;
	
	memset( &hints, 0, sizeof( struct addrinfo));
	
	if( siSocket->TransportType == 4) 
	{	
		hints.ai_family = AF_INET;
	} 
	else if( siSocket->TransportType == 6) 
	{
		hints.ai_family = AF_INET6;
	} 
	else 
	{
		hints.ai_family = AF_UNSPEC;
	}
	
	hints.ai_socktype = SOCK_DGRAM;
	hints.ai_flags = 0;
	hints.ai_protocol = 0;
	
	char sPort[10];
	memset( sPort, 0, sizeof(sPort));
	sprintf( sPort, "%d", siSocket->IPPort);
	
	s = getaddrinfo( siSocket->IPAddresses[0].IPAddress, sPort, &hints, &result);
	
	uint32_t clientIp = 0;
	struct sockaddr_in cli_addr;
	int bindlocalIp = 0;
	
	if( strlen( siSocket->ClientIP.IPAddress) > 0)
	{
		if( strcmp( "127.0.0.1", siSocket->ClientIP.IPAddress) != 0)
		{
			clientIp = __si_core_convert_ipv4toint( siSocket->ClientIP.IPAddress);
			bindlocalIp = 1;
		}
	}
	
	if (s == 0) 
	{
		// for ( rp = result; rp != NULL; rp = rp->ai_next) 
		// {
			// if( rp->ai_socktype == SOCK_DGRAM && rp->ai_protocol == 17)
			// {
				// if( rp->ai_family == AF_INET)
				// {
					// memset( &cli_addr, 0, sizeof(struct sockaddr_in));
					// memcpy( &cli_addr, rp->ai_addr, rp->ai_addrlen);
				
					// printf("Client-IP=%s Port=%u  SystemIP=%u|%s\n", 
						// siSocket->ClientIP.IPAddress, siSocket->CIPPort, 
						// cli_addr.sin_addr.s_addr,
						// __si_core_convert_inttoipv4( cli_addr.sin_addr.s_addr)
						// );
				// }
			// }
		// }
		
		for ( rp = result; rp != NULL; rp = rp->ai_next) 
		{
			// if(rp->ai_protocol != 17)
				// continue
			
			sfd = socket( rp->ai_family, rp->ai_socktype, rp->ai_protocol);

			//if (sfd == -1)
			if (sfd <= 0)	
				continue;
			
			//printf( "sfd=%d ai_family=%d ai_socktype=%d ai_protocol=%d \n", sfd, rp->ai_family, rp->ai_socktype, rp->ai_protocol);
			
			/*
				ai_family 
					AF_INET = 2, 
					AF_INET6 = 10
					AF_UNSPEC = 0
				ai_socktype  SOCK_STREAM, SOCK_DGRAM.
				ai_protocol 17 - UDP
			
				if (connect(sfd, rp->ai_addr, rp->ai_addrlen) != -1)	//success
                   break;

				socklen_t        ai_addrlen;
				struct sockaddr *ai_addr;
				
				close(sfd);			
			*/
			
			/*
			if( rp->ai_socktype == SOCK_DGRAM && rp->ai_protocol == 17)
			{
				if( rp->ai_family == AF_INET)
				{
					struct sockaddr_in cli_addr;
					memset( &cli_addr, 0, sizeof(struct sockaddr_in));
					memcpy( &cli_addr, rp->ai_addr, rp->ai_addrlen);
					
					printf("Client-IP=%s %u  addr=%u|%s|%u\n", 
						siSocket->ClientIP.IPAddress, siSocket->CIPPort, 
						cli_addr.sin_addr.s_addr,
						__si_core_convert_inttoipv4( cli_addr.sin_addr.s_addr),
						__si_core_convert_ipv4toint( "192.160.1.5")
						);
					//__si_core_convert_inttoipv4(siSocket->cli_addr.sin_addr.s_addr)
				}
				continue;
			}
			*/
			
			// if( clientIp > 0 && rp->ai_socktype == SOCK_DGRAM && rp->ai_protocol == 17 )
			// {
				// memset( &cli_addr, 0, sizeof(struct sockaddr_in));
				// memcpy( &cli_addr, rp->ai_addr, rp->ai_addrlen);
			// }
			
			//if( rp->ai_socktype == SOCK_DGRAM && rp->ai_protocol == 17 && (clientIp == 0 || cli_addr.sin_addr.s_addr == clientIp))
			if( rp->ai_socktype == SOCK_DGRAM && rp->ai_protocol == 17)
			{
				//printf( "%d %d %d udp socket! %d\n", AF_INET, AF_INET6, AF_UNSPEC, rp->ai_addrlen);

				
				if( rp->ai_family == AF_INET)
				{
					siSocket->ai_family = rp->ai_family;
					siSocket->cli_len = rp->ai_addrlen;
					memcpy( &siSocket->cli_addr, rp->ai_addr, rp->ai_addrlen);
					
					// int x = 100/siSocket->isConnected;
					
					// printf("addr=%u|%s isConnected=%d   %s|%d\n", siSocket->cli_addr.sin_addr.s_addr, 
						// __si_core_convert_inttoipv4(siSocket->cli_addr.sin_addr.s_addr), 
						// siSocket->isConnected, __FILE__, __LINE__);
					
					if( bindlocalIp == 1)
					{
						cli_addr.sin_family 		= AF_INET;
						cli_addr.sin_addr.s_addr 	= inet_addr( siSocket->ClientIP.IPAddress); // this is address of host which I want to send the socket

						if( siSocket->CIPPort > 0)
						{
							cli_addr.sin_port 		= htons(siSocket->CIPPort);
						}

						if (bind( sfd, (const struct sockaddr*) &cli_addr, sizeof(struct sockaddr_in)) < 0)
						{
							//printf("failed to bind socket (%s)\n", strerror(errno)); // Cannot assign requested address
							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "binding udp to localip=%s port=%d failed <%s|%s|%d>", 
								siSocket->ClientIP.IPAddress, siSocket->CIPPort, __FILE__, __FUNCTION__, __LINE__);
						}
					}
					
					
					siSocket->isConnected = 1;
				}
				else if( rp->ai_family == AF_INET6)
				{
					siSocket->ai_family = rp->ai_family;
					siSocket->cli_len = rp->ai_addrlen;
					memcpy( &siSocket->cli_addr6, rp->ai_addr, rp->ai_addrlen);
					
					siSocket->isConnected = 1;
				}
				
				if( siSocket->isConnected == 1)
				{	
					siSocket->fd = sfd;
					break;
				}	
			}
		}
		
		//free memccpy
		 freeaddrinfo( result);
	}
	else
	{
		printf( "getaddrinfo failed for UDP connection IP=%s Port=%d error=%d\n", 
			siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, s);
		
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "getaddrinfo failed for UDP connection IP=%s Port=%d error=%d <%s|%s|%d>", 
							siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, s, __FILE__, __FUNCTION__, __LINE__);
	}
	
	return 0;
}


int __si_socket_engine_udp_send( SI_Socket * siSocket, char * ip, int port, int ipv, char * buff, int len)
{
	struct sockaddr_in servaddr;
	memset( &servaddr, 0, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(port);
	
	if( inet_pton( AF_INET, ip, &servaddr.sin_addr) <= 0) 
	{
		return -1000;
    }
	
	return sendto( siSocket->fd, buff, len, MSG_DONTWAIT, (struct sockaddr *)&servaddr, sizeof(servaddr));
}


int __si_socket_engine_udp_send2( SI_Socket * siSocket, struct sockaddr_in * servaddr, int slen, char * buff, int len)
{
	return sendto( siSocket->fd, buff, len, MSG_DONTWAIT, servaddr, slen);
}

int __si_socket_engine_udp_send_response( int fd, struct sockaddr * saddr, int slen, char * buff, int len)
{
	int sentBytes = sendto( fd, buff, len, 0, saddr, slen);
	//int sentBytes = sendto( fd, buff, len, MSG_DONTWAIT, saddr, slen);

	/*
	printf( "sending response on fd=%d saddr=%p len=%d buff=%s len=%d sentBytes=%d errno=%d %s\n", 
		fd, saddr, slen, buff, len, sentBytes, errno, strerror(errno));
	*/
	
	return sentBytes;
}

int __si_socket_engine_udp_send_socket_data( SI_Socket * siSocket, char * buff, int len, int tryCount)
{
	char sChar[1];
	int iSentBytes = 0;
	
	//printf( "isHost=%d fd=%d\n", siSocket->isHost, siSocket->fd);
	
	if( siSocket->isHost == 0 && siSocket->fd > 0)
	{
		//its a client, send message to server
		int n = 0;
		
		if( siSocket->ai_family == AF_INET) 
		{
			n = sendto( siSocket->fd, buff, len, MSG_DONTWAIT, (struct sockaddr *)&siSocket->cli_addr, siSocket->cli_len);
		}
		else if( siSocket->ai_family == AF_INET6)
		{
			n = sendto( siSocket->fd, buff, len, MSG_DONTWAIT, (struct sockaddr *)&siSocket->cli_addr6, siSocket->cli_len);
		}
		
		//printf( "fd=%d ai_family=%d (2-IPv4,10-IPv6)  len=(%d)  data=%s  n=%d  cli_len=%d  %s|%d\n", siSocket->fd, siSocket->ai_family, len, buff, n, siSocket->cli_len, __FILE__, __LINE__);
		
		return n;
		
		//int n = sendto( siSocket->fd, buff, len, 0, (struct sockaddr *)&oMessage->SockInfo.clientaddr, oMessage->SockInfo.clientlen);
		//int n = sendto( siSocket->fd, buff, len, 0, (struct sockaddr *)NULL, 0);
		//return n;
		
		//printf( "(%d) %s \n", len, buff);
	}
	
	return -1;
}

int __si_socket_engine_tcp_send_socket_data( SI_Socket * siSocket, char * buff, int len, int tryCount)
{
	char sChar[1];
	int iSentBytes = 0;
	
	if( siSocket->isConnected == 1)
	{
		#if TLS_SOCKET_SUPPORT		
			if( siSocket->TlsEnabled == 1)		
			{
				if( siSocket->TlsAyncWrite == 1)
				{
					__si_socket_engine_tcp_send_socket_data_aync( siSocket, buff, len);
					return 1;
				}
				
				pthread_mutex_lock( &siSocket->ioLock);
				iSentBytes = SSL_write( siSocket->ssl, buff, len);
				pthread_mutex_unlock( &siSocket->ioLock);
				
				//if( iSentBytes != len)
				if( iSentBytes <= 0)
				{
					int isSocketErorCode = __si_socket_engine_socket_error_code( siSocket);
					int sslError = SSL_get_error( siSocket->ssl, iSentBytes);
					
					if( isSocketErorCode != 0)
					{	
						__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "closing ssl-socket fd=%d as isSocketErorCode=%d iSentBytes=%d datalen=%d <%s|%s|%d>", 
							siSocket->fd, isSocketErorCode, iSentBytes, len, __FILE__, __FUNCTION__, __LINE__);
							
						siSocket->Close( siSocket);
						return -1;
					}
					
					if( sslError == SSL_ERROR_WANT_READ)
					{
						__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "not closing, want SSL_read at SSL_write function  iSentBytes=%d datalen=%d <%s|%s|%d>", iSentBytes, len, __FILE__, __FUNCTION__, __LINE__);
						
						pthread_mutex_lock( &siSocket->ioLock);
						SSL_read( siSocket->ssl, sChar, 0);
						pthread_mutex_unlock( &siSocket->ioLock);
						
						return __si_socket_engine_tcp_send_socket_data( siSocket, buff, len, (tryCount + 1));							
					}					
					
					if( sslError == SSL_ERROR_WANT_WRITE)
					{
						__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "not closing, want SSL_write at SSL_write function  iSentBytes=%d datalen=%d <%s|%s|%d>", iSentBytes, len, __FILE__, __FUNCTION__, __LINE__);
						
						__si_socketEngine->TlsTotalWriteContinueCount++;						
						return __si_socket_engine_tcp_send_socket_data( siSocket, buff, len, (tryCount + 1));
					}
					else
					{
						__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "closing ssl-socket fd=%d as ssl-errorcode=%d lerror=%s[%d] iSentBytes=%d len=%d tls=%d asynW=%d <%s|%s|%d>", 
							siSocket->fd, sslError, strerror(errno), errno, iSentBytes, len, 
							siSocket->TlsEnabled, siSocket->TlsAyncWrite, __FILE__, __FUNCTION__, __LINE__);						
						
						siSocket->Close( siSocket);
						return -1;
					}
				}
				/*
				else if( iSentBytes > 0)
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "has pending-read=%d >>>> <%s|%s|%d>", SSL_pending( siSocket->ssl) , __FILE__, __FUNCTION__, __LINE__);
				}
				*/
				
				return iSentBytes;
			}
			else
			{
				//define MSG_OOB           0x1     /* process out-of-band data */
				//define MSG_DONTROUTE     0x4     /* bypass routing, use direct interface */
				//define MSG_DONTWAIT      0x40    /* don't block */
				//define MSG_NOSIGNAL      0x2000  /* don't raise SIGPIPE */
				
				//int iSentBytes = send( siSocket->fd, buff, len, 0);
				int iSentBytes = send( siSocket->fd, buff, len, MSG_NOSIGNAL);
				
				if( iSentBytes <= 0 && EPIPE == errno)
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "error while sending data, closing tcp socket fd=%d as iSentBytes=%d is <= 0 errorno=%d strerror=%s EPIPE(%d) ip=%s port=%d  <%s|%s|%d>", 
									siSocket->fd, iSentBytes, errno, strerror(errno), EPIPE, siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
									
					siSocket->Close( siSocket);
				}
				
				return iSentBytes;			
			}
		#else
			//int iSentBytes = send( siSocket->fd, buff, len, 0);
			int iSentBytes = send( siSocket->fd, buff, len, MSG_NOSIGNAL);
			
			if( iSentBytes <= 0 && (EPIPE == errno))
			{
				__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "error while sending data, closing tcp socket fd=%d as iSentBytes=%d is <= 0 errorno=%d strerror=%s EPIPE(%d) ip=%s port=%d  <%s|%s|%d>", 
								siSocket->fd, iSentBytes, errno, strerror(errno), EPIPE, siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
								
				siSocket->Close( siSocket);
			}
			
			return iSentBytes;			
		#endif
	}
	return -1;
}

static int __si_socket_variable_negotiate_tls_h2_alpn = 1;

void __si_socket_engine_enable_negotiate_tls_h2_alpn()
{
	__si_socket_variable_negotiate_tls_h2_alpn = 1;
}

void __si_socket_engine_disable_negotiate_tls_h2_alpn()
{
	__si_socket_variable_negotiate_tls_h2_alpn = 0;
}

int __si_socket_engine_is_alpn_negotiated( SI_Socket * siSocket)
{
	#if TLS_SOCKET_SUPPORT

		if( __si_socket_variable_negotiate_tls_h2_alpn == 1)
		{	
			if( siSocket->TlsEnabled == 1)
			{
				if( siSocket->ssl)
				{
					const unsigned char * alpn = NULL;
					unsigned int alpnlen = 0;
					
					SSL_get0_alpn_selected( siSocket->ssl, &alpn, &alpnlen);
					
					if( alpn && alpnlen == 2) 
					{	
						if( memcmp( "h2", alpn, 2 ) == 0)
						{
							return 1;
						}
						else
						{
							return -1;
						}
					} 
				}
			}
			else
			{
				return 1;
			}
			
			return -1;
		}
		else
		{
			return 1;
		}
		
	#else
		
		return 1;
	
	#endif
}


SI_Socket * __si_socket_engine_tcp_accept_client_socket( SI_Socket * parent, int fd, void * cli_addr, int cli_len)
{
	SI_Socket * siSocket = NULL;
	
	int bFound = 0;
	
	pthread_mutex_lock( &parent->ChildLock);
	
	siSocket = parent->ChildHead;
	
	while( siSocket)
	{
		//printf("siSocket=%p isActive=%d\n", siSocket, siSocket->isActive);
		
		if( siSocket->isActive == 0 && siSocket->isFree == 1)
		{
			bFound = 1;
			break;
		}
		
		siSocket = siSocket->Next;
	}
	
	//pthread_mutex_unlock( &parent->ChildLock);
	
	
	if( bFound == 0)
	{	
		//siSocket = ( SI_Socket *) __si_malloc( sizeof(SI_Socket));
		__si_malloc2( sizeof( SI_Socket), (uint8_t **) &siSocket);
		memset( siSocket, 0, sizeof( SI_Socket));

		__si_socket_engine_add_socket_to_engine_for_epoll_async( siSocket);
		
		siSocket->GenId = 0;
		siSocket->id = parent->ChildSocketCount;
		siSocket->Parent = parent;
		siSocket->TransportType = parent->TransportType;
		siSocket->transportEng = NULL;
		
		pthread_mutex_init( &siSocket->BufferLock, NULL);	
		pthread_mutex_init( &siSocket->BufferReadLock, NULL);
		pthread_mutex_init( &siSocket->CloseLock, NULL);
		
		
		#if TLS_SOCKET_SUPPORT
			if( parent->TlsEnabled == 1)
			{
				siSocket->TlsEnabled = parent->TlsEnabled;
				siSocket->TlsAyncWrite = parent->TlsAyncWrite;
				siSocket->ssl = SSL_new( parent->ctx);
			}	
		#endif
	}

	siSocket->isHost = 1;
	siSocket->isStarted = 0;
	siSocket->fd = fd;
	int closeFd = 0;
	
	#if TLS_SOCKET_SUPPORT
	
		if( siSocket->TlsEnabled == 1)
		{	
			SSL_set_fd( siSocket->ssl, siSocket->fd);
			
			int ssl_accept_rv = SSL_accept( siSocket->ssl);
			
			if ( ssl_accept_rv != 1 )
			//if ( ssl_accept_rv == -1 )
			{
				int i_error = ERR_get_error();
				__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "Socket: SSL_accept failed with ssl_error=%d err=%d err_str=%s", ssl_accept_rv, i_error, ERR_error_string( i_error, NULL));
				
				printf("SSL_accept ERROR\n");
				ERR_print_errors_fp( stderr);
				closeFd = 1;
			}
			/*	
			else
			{
				SSL_set_accept_state( siSocket->ssl);
			}
			*/	
		}
		
	#endif
	
	if( __si_socket_engine_is_alpn_negotiated( siSocket) != 1)
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "Socket: APNP negotiation failed, closing socket connection");	
		closeFd = 1;	
	}
	
	int rc = 0;
	int sendbuf = -1;	
	struct linger so_linger;
	so_linger.l_onoff = 1;
	so_linger.l_linger = 0;
	
	setsockopt( siSocket->fd, SOL_SOCKET, SO_LINGER, &so_linger, sizeof ( struct linger));	
	
	if( siSocket->TlsEnabled == 1)
	{	
		//int nodelay_val = 1;
		//setsockopt( siSocket->fd, IPPROTO_TCP, TCP_NODELAY, (char *)&nodelay_val, sizeof(nodelay_val));
		
		//int setNoSigpipe = 1;
		//setsockopt( siSocket->fd, SOL_SOCKET, SO_NOSIGPIPE, (void *)&setNoSigpipe, sizeof(int));
	}
	else
	{
		//added 09-JULY-2020
		int nodelay_val = 1;
		setsockopt( siSocket->fd, IPPROTO_TCP, TCP_NODELAY, (char *)&nodelay_val, sizeof(nodelay_val));		
	}
	
	fcntl( siSocket->fd, F_SETFL, fcntl( siSocket->fd, F_GETFL, 0) | O_NONBLOCK);
	
	rc = setsockopt( siSocket->fd, SOL_SOCKET, SO_SNDBUF,(char *)&sendbuf, sizeof(sendbuf));
	
	if(rc < 0) 
	{
		printf( "unable to set SO_SNDBUF to socket withc rc=%d, error=%s, errno=%d connSocketFD=%d\n", rc, strerror(errno), errno, siSocket->fd);
	}
	
	if( siSocket->TransportType == SIRIK_TRANSPORT_TYPE_TCP)
	{	
		siSocket->Send = __si_socket_engine_tcp_send_socket_data;
		siSocket->Read = __si_socket_engine_tcp_read_socket_data;
		siSocket->Close = __si_socket_engine_tcp_close_socket;	
	}
	
	siSocket->AddBuffer = __si_socket_engine_add_buffer_to_socket;
	
	if( parent->OnAccept > 0)
	{
		parent->OnAccept( siSocket, parent);
	}

	if( parent->OnBufferReceive > 0)
	{
		siSocket->OnBufferReceive = parent->OnBufferReceive;
	}
	
	siSocket->OnCloseFired = 0;
	pthread_mutex_init( &siSocket->OnCloseLock, NULL);
	
	if( parent->OnClose > 0)
	{
		siSocket->OnClose = parent->OnClose;
	}

	//pthread_mutex_lock( &parent->ChildLock);
	
	if( bFound == 0)
	{	
		parent->ChildSocketCount++;
		
		if( !parent->ChildHead)
		{
			parent->ChildHead = parent->ChildCurrent = siSocket;
		}
		else
		{
			parent->ChildCurrent->Next = siSocket;
			parent->ChildCurrent = siSocket;
		}
	}
	
	//pthread_mutex_unlock( &parent->ChildLock);

	if( closeFd == 0)
	{	
		siSocket->GenId++;
		siSocket->isFree = 0;			//Not Free (busy)
		siSocket->isActive = 1;
		siSocket->isConnected = 1;
	}
	
	pthread_mutex_unlock( &parent->ChildLock);
	
	if( closeFd == 0)
	{	
		if( siSocket->StateFull == 0)
		{	
			__si_socket_engine_attach_to_epoll( siSocket);
		}
		
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "accepted new connection fd=%d pfd=%d tls=%d asyncW=%d port=%d genId=%d", 
			siSocket->fd, parent->fd, siSocket->TlsEnabled, siSocket->TlsAyncWrite, parent->IPPort, siSocket->GenId);
	}
	else
	{
		close( siSocket->fd);
	}
	
	return siSocket;
}

#if TLS_SOCKET_SUPPORT

static int __si_socket_alpn_select_proto_cb( SSL * ssl, const unsigned char ** out, unsigned char * outlen, const unsigned char * in, unsigned int inlen, void * arg)
{
	if( inlen >= 3)
	{
		if( in[1] == 'h' && in[2] == '2')
		{
			*out = &in[1];
			*outlen = in[0];
			return SSL_TLSEXT_ERR_OK;
		}			
	}
	
	return SSL_TLSEXT_ERR_NOACK;
}

#endif

SI_Socket * __si_socket_engine_create_sctp_client_socket( SI_SctpSocketInfo * sctpSocketInfo)
{
	SI_Socket * siSocket = NULL;
	__si_malloc2( sizeof(SI_Socket), (uint8_t **) &siSocket);
	memset( siSocket, 0, sizeof( SI_Socket));
	
	//for local system socket binding ...
	int maxIpCount = (sctpSocketInfo->ipCount > 4) ? 4 : sctpSocketInfo->ipCount;
	
	int i = 0;
	for( i = 0; i < maxIpCount; i++)
	{
		strcpy( siSocket->IPAddresses[siSocket->IPAddressCount].IPAddress, sctpSocketInfo->IP[i]);
		//if contains . then its IPv4
		siSocket->IPAddresses[siSocket->IPAddressCount].IPVersion = 4;
		
		siSocket->IPAddressCount++;
	}
	
	//for remote system socket binding ...
	siSocket->IPPort = sctpSocketInfo->Port;
	maxIpCount = (sctpSocketInfo->RemoteIpCount > 4) ? 4 : sctpSocketInfo->RemoteIpCount;
	
	i = 0;
	for( i = 0; i < maxIpCount; i++)
	{
		strcpy( siSocket->RemoteIPAddresses[siSocket->RemoteIPAddressCount].IPAddress, sctpSocketInfo->RemoteIP[i]);
		siSocket->RemoteIPAddresses[siSocket->RemoteIPAddressCount].IPVersion = 4;
		siSocket->RemoteIPAddressCount++;
	}
	
	//siSocket->IPVersion = siSocket->IPAddresses[0].IPVersion;
	siSocket->IPVersion = sctpSocketInfo->ipVersion;
	siSocket->TransportType = SIRIK_TRANSPORT_TYPE_SCTP;
	siSocket->RemoteIPPort = sctpSocketInfo->RemotePort;
	siSocket->IPPort = sctpSocketInfo->Port;
	siSocket->PPID = sctpSocketInfo->PPID;
	siSocket->UseEPoll = sctpSocketInfo->UseEPoll;
	siSocket->isListner = 0;
	
	siSocket->ReadInProgress = 0;
	siSocket->ReadSignal = 0;
	siSocket->isActive = 0;
	siSocket->isStarted = 0;
	siSocket->isHost = 0;
	siSocket->TlsEnabled = 0;
	siSocket->TlsAyncWrite = 0;
	siSocket->ChildSocketCount = 0;
	siSocket->isFree = 0;
	siSocket->GenId = 0;	
	
	siSocket->clientReadThread = NULL;
	siSocket->BufferHead = NULL;
	siSocket->BufferCurrent = NULL;
	siSocket->SctpBufferHead = NULL;
	siSocket->SctpBufferCurrent = NULL;	
	siSocket->BufferLength = 0;
	siSocket->BeforeMessageSend = 0;
	siSocket->AfterMessageSent = 0;
	siSocket->ReceivedMessages = 0;
	siSocket->LastMessageSent = 0;
	siSocket->LastReceivedMessages = 0;
	siSocket->UseSendLock = 0;

	pthread_mutex_init( &siSocket->SendLock, NULL);	
	pthread_mutex_init( &siSocket->BufferLock, NULL);
	pthread_mutex_init( &siSocket->BufferReadLock, NULL);
	pthread_mutex_init( &siSocket->ChildLock, NULL);
	pthread_mutex_init( &siSocket->CloseLock, NULL);
	pthread_mutex_init( &siSocket->ConnectLock, NULL);	
	
	pthread_mutex_init( &siSocket->AsyncWriteLock, NULL);
	
	// siSocket->AddBuffer = __si_socket_engine_add_buffer_to_socket;
	
	siSocket->Next = NULL;
	__si_socket_engine_add_socket_to_engine( siSocket);
	
	return siSocket;	
}

SI_Socket * __si_socket_engine_create_sctp_server_socket( SI_SctpSocketInfo * sctpSocketInfo)
{
	SI_Socket * siSocket = NULL;
	__si_malloc2( sizeof(SI_Socket), (uint8_t **) &siSocket);
	memset( siSocket, 0, sizeof( SI_Socket));
	
	int maxIpCount = (sctpSocketInfo->ipCount > 4) ? 4 : sctpSocketInfo->ipCount;
	
	int i = 0;
	for( i = 0; i < maxIpCount; i++)
	{
		strcpy( siSocket->IPAddresses[siSocket->IPAddressCount].IPAddress, sctpSocketInfo->IP[i]);
		//if contains . then its IPv4
		siSocket->IPAddresses[siSocket->IPAddressCount].IPVersion = 4;
		
		siSocket->IPAddressCount++;
	}
	
	//siSocket->IPVersion = siSocket->IPAddresses[0].IPVersion;
	siSocket->IPVersion = sctpSocketInfo->ipVersion;					//IPv6Change
	siSocket->TransportType = SIRIK_TRANSPORT_TYPE_SCTP;
	siSocket->IPPort = sctpSocketInfo->Port;
	
	siSocket->ReadInProgress 	= 0;
	siSocket->ReadSignal 		= 0;
	siSocket->isActive 			= 1;
	siSocket->isStarted 		= 0;
	siSocket->isHost 			= 1;
	siSocket->TlsEnabled 		= 0;
	siSocket->TlsAyncWrite 		= 0;
	siSocket->ChildSocketCount 	= 0;
	siSocket->isFree 			= 0;
	siSocket->GenId 			= 0;
	siSocket->max_i_streams 	= sctpSocketInfo->MaxIStreams;
	siSocket->max_o_streams 	= sctpSocketInfo->MaxOStreams;
	siSocket->UseEPoll 			= sctpSocketInfo->UseEPoll;
	siSocket->isListner			= 1;
	
	siSocket->BeforeMessageSend = 0;
	siSocket->AfterMessageSent = 0;
	siSocket->ReceivedMessages = 0;
	
	siSocket->LastMessageSent = 0;
	siSocket->LastReceivedMessages = 0;
	
	siSocket->BufferHead = NULL;
	siSocket->BufferCurrent = NULL;
	siSocket->BufferLength = 0;
	pthread_mutex_init( &siSocket->BufferLock, NULL);
	pthread_mutex_init( &siSocket->BufferReadLock, NULL);
	pthread_mutex_init( &siSocket->ChildLock, NULL);
	pthread_mutex_init( &siSocket->CloseLock, NULL);
	pthread_mutex_init( &siSocket->ConnectLock, NULL);	
	
	pthread_mutex_init( &siSocket->AsyncWriteLock, NULL);
	
	// siSocket->AddBuffer = __si_socket_engine_add_buffer_to_socket;
	
	
	__si_socket_engine_add_socket_to_engine( siSocket);
	
	return siSocket;
}



SI_Socket * __si_socket_engine_create_server_socket( char * ip, int ipversion, int transportType, int port, int tls, char * serverCert, char * pKey)
{
	__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "ip=%s ipversion=%d transportType=%d  | %s|%d", ip, ipversion, transportType, __FILE__, __LINE__);


	//SI_Socket * siSocket = ( SI_Socket *) __si_malloc( sizeof(SI_Socket));
	SI_Socket * siSocket = NULL;
	__si_malloc2( sizeof(SI_Socket), (uint8_t **) &siSocket);
	memset( siSocket, 0, sizeof( SI_Socket));
	
	if(ip) {	
		strcpy( siSocket->IPAddresses[siSocket->IPAddressCount].IPAddress, ip);
	} else {
		if( ipversion == 6) 
			strcpy( siSocket->IPAddresses[siSocket->IPAddressCount].IPAddress, "127.0.0.1");
		else
			strcpy( siSocket->IPAddresses[siSocket->IPAddressCount].IPAddress, "::1");
	}
	
	memset( siSocket->host, 0, sizeof(siSocket->host));
	strcpy( siSocket->host, siSocket->IPAddresses[siSocket->IPAddressCount].IPAddress); 
	
	siSocket->IPAddresses[siSocket->IPAddressCount].IPVersion = ipversion;
	siSocket->IPAddressCount++;
	
	siSocket->IPVersion = ipversion;
	siSocket->TransportType = transportType;
	siSocket->IPPort = port;
	
	siSocket->ReadInProgress = 0;
	siSocket->ReadSignal = 0;
	siSocket->isActive = 1;
	siSocket->isStarted = 0;
	siSocket->isHost = 1;
	siSocket->TlsEnabled = tls;
	siSocket->TlsAyncWrite = (tls == 1) ? 1 : 0;
	siSocket->ChildSocketCount = 0;
	siSocket->isFree = 0;
	siSocket->GenId = 0;
	
	siSocket->BufferHead = NULL;
	siSocket->BufferCurrent = NULL;
	siSocket->BufferLength = 0;
	pthread_mutex_init( &siSocket->BufferLock, NULL);
	pthread_mutex_init( &siSocket->BufferReadLock, NULL);
	pthread_mutex_init( &siSocket->ChildLock, NULL);
	pthread_mutex_init( &siSocket->CloseLock, NULL);
	pthread_mutex_init( &siSocket->ConnectLock, NULL);
	
	#if TLS_SOCKET_SUPPORT
	pthread_mutex_init( &siSocket->ioLock, NULL);
	#endif
	
	pthread_mutex_init( &siSocket->AsyncWriteLock, NULL);
	
	#if TLS_SOCKET_SUPPORT
		
		if( tls == 1)
		{	
			//siSocket->ctx = SSL_CTX_new( TLSv1_2_server_method());
			siSocket->ctx = SSL_CTX_new( SSLv23_server_method());
			
			if ( siSocket->ctx == NULL )
			{
				ERR_print_errors_fp( stderr);
				abort();
			}
			
			//if ( SSL_CTX_use_certificate_file( siSocket->ctx, __si_socketEngine->CertPath, SSL_FILETYPE_PEM) <= 0 )
			if ( SSL_CTX_use_certificate_file( siSocket->ctx, serverCert, SSL_FILETYPE_PEM) <= 0 )	
			{
				ERR_print_errors_fp( stderr);
				abort();
			}
			
			/* set the private key from KeyFile (may be the same as CertFile) */
			//if ( SSL_CTX_use_PrivateKey_file( siSocket->ctx, __si_socketEngine->CertKeyPath, SSL_FILETYPE_PEM) <= 0 )
			if ( SSL_CTX_use_PrivateKey_file( siSocket->ctx, pKey, SSL_FILETYPE_PEM) <= 0 )
			{
				ERR_print_errors_fp( stderr);
				abort();
			}
			
			if ( !SSL_CTX_check_private_key( siSocket->ctx) )
			{
				fprintf( stderr, "Private key does not match the public certificate\n");
				abort();
			}
			
			/*
			SSL_CTX_set_options( siSocket->ctx,
                      SSL_OP_ALL | SSL_OP_NO_SSLv2 | SSL_OP_NO_SSLv3 |
                          SSL_OP_NO_COMPRESSION |
                          SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION);
			*/
			
			//SSL_CTX_set_options( siSocket->ctx, SSL_OP_NO_SSLv2);
			
			if( __si_socket_variable_negotiate_tls_h2_alpn == 1)
			{	
				SSL_CTX_set_alpn_select_cb( siSocket->ctx, __si_socket_alpn_select_proto_cb, NULL);
			}
			
			printf( "TLS Context initialized for server port %d.\n", port);
			
			//siSocket->TlsEnabled = tls;
			//siSocket->TlsAyncWrite = (tls == 1) ? 1 : 0;
			
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "tls=%d asyncW=%d port=%d", siSocket->TlsEnabled, siSocket->TlsAyncWrite, port);
		}
		
	#endif
	
	if( SIRIK_TRANSPORT_TYPE_TCP == transportType)
	{	
		siSocket->Send = __si_socket_engine_tcp_send_socket_data;
		siSocket->Accept = __si_socket_engine_tcp_accept_client_socket;
		siSocket->Read = __si_socket_engine_tcp_read_socket_data;
		siSocket->Close = __si_socket_engine_tcp_close_socket;
		
		siSocket->AddBuffer = __si_socket_engine_add_buffer_to_socket;
	}
	else if ( SIRIK_TRANSPORT_TYPE_UDP == transportType)
	{
		//TODO:UDP
	}

	__si_socket_engine_add_socket_to_engine( siSocket);
	
	return siSocket;
}

SI_Socket * __si_socket_engine__udp4_start_socket( char * ip, int port, si_fp_add_socket_udp_packet OnUdpPacketReceive)
{
	SI_Socket * socket = __si_socket_engine_create_server_socket( ip, 4, SIRIK_TRANSPORT_TYPE_UDP, port, 0, NULL, NULL);
	socket->OnUdpPacketReceive = OnUdpPacketReceive;
	__si_socket_engine_start_server_socket( socket);
	return socket;
}

int __si_socket_engine_sctp_send_ngap( SI_Socket * siSocket, char * buffer, int len)
{
	#if SCTP_SUPPORT	

	struct sctp_sndrcvinfo sinfo;
	memset( &sinfo, 0, sizeof( struct sctp_sndrcvinfo));
	
	sinfo.sinfo_stream = __si_socket_sctp_next_streamid( 0, siSocket);
	sinfo.sinfo_flags = 0;
	sinfo.sinfo_assoc_id = 0;
	sinfo.sinfo_ppid = htonl(siSocket->PPID);
	
	if( siSocket->isConnected == 1) {
		int fd = siSocket->fd;
		
		if( fd > 0) 
		{
			int sentBytes = 0;
			int sendctr = 0;
			
			do 
			{
				if( sendctr > 0)
				{
					//__si_nanosleep( 999999999/10000 );	//10000 times in second
					__si_nanosleep( 999999999/7000 );	//7000 times in second
				}
				
				siSocket->BeforeMessageSend++;
				
				if( siSocket->UseSendLock == 1) {
					pthread_mutex_lock( &siSocket->SendLock);
				}
				
				sentBytes = sctp_send( fd, buffer, len, &sinfo, MSG_NOSIGNAL);	//MSG_DONTWAIT | 

				if( siSocket->UseSendLock == 1) {
					pthread_mutex_unlock( &siSocket->SendLock);
				}
				
				siSocket->AfterMessageSent++;
				sendctr++;
			}
			while( sentBytes <= 0 && errno == 11 && sendctr < 1);
		
			//errno == 11  EAGAIN
		
			if( sentBytes <= 0)
			{
				if( EPIPE == errno)
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP: socket error while sending data, closing sctp socket fd=%d as sentBytes=%d is < 0 errorno=%d strerror=%s EPIPE(%d) ip=%s port=%d  <%s|%s|%d>", 
						siSocket->fd, sentBytes, errno, strerror(errno), EPIPE, siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);				

					siSocket->isConnected = 0;
					siSocket->isActive = 0;
					close( fd);
					shutdown( fd, 2);
				}
				else
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP: socket error while sending data fd=%d as sentBytes=%d is < 0 errorno=%d strerror=%s ip=%s port=%d  <%s|%s|%d>", 
						siSocket->fd, sentBytes, errno, strerror(errno), siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
				}
			}
			
			return sentBytes;
		} else {
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sending data failed fd=%d already closed sctp socket %s|%s|%d", fd, __FILE__, __FUNCTION__, __LINE__);
			return -1;
		}
	} else {
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sending data on not-connected sctp socket %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);
		return -1;
	}

	#endif
	return -1;
}

int __si_socket_engine_sctp_send( SI_Socket * siSocket, char * buffer, int len)
{
	#if SCTP_SUPPORT
	
	struct sctp_sndrcvinfo sinfo;
	memset( &sinfo, 0, sizeof( struct sctp_sndrcvinfo));
	
	sinfo.sinfo_stream = 0;
	sinfo.sinfo_flags = 0;
	sinfo.sinfo_assoc_id = 0;
	sinfo.sinfo_ppid = htonl(siSocket->PPID);
	

	if( siSocket->isConnected == 1) {
		int fd = siSocket->fd;
		
		if( fd > 0) 
		{
			siSocket->BeforeMessageSend++;
			int sentBytes = sctp_send( fd, buffer, len, &sinfo, MSG_NOSIGNAL);
			siSocket->AfterMessageSent++;
		
			if( sentBytes <= 0)
			{
				if( EPIPE == errno)
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP: error while sending data, closing sctp socket fd=%d as sentBytes=%d is < 0 errorno=%d strerror=%s EPIPE(%d) ip=%s port=%d  <%s|%s|%d>", 
						siSocket->fd, sentBytes, errno, strerror(errno), EPIPE, siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);				

					siSocket->isConnected = 0;
					siSocket->isActive = 0;			
					close( fd);
					shutdown( fd, 2);
				}
				else
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP: socket error while sending data fd=%d as sentBytes=%d is < 0 errorno=%d strerror=%s ip=%s port=%d  <%s|%s|%d>", 
						siSocket->fd, sentBytes, errno, strerror(errno), siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
				}
			}
			
			return sentBytes;
		
		} else {
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sending data failed fd=%d already closed sctp socket %s|%s|%d", fd, __FILE__, __FUNCTION__, __LINE__);
			return -1;
		}
	} else {
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sending data on not-connected sctp socket %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);
		return -1;
	}
	
	#endif
	return 0;
}

int __si_socket_engine_get_fd( SI_Socket * siSocket)
{
	return siSocket->fd;
}

int __si_socket_engine_is_connected( SI_Socket * siSocket)
{
	return siSocket->isConnected;
}

int __si_socket_engine_is_active( SI_Socket * siSocket)
{
	return siSocket->isActive;
}

int __si_socket_engine_sctp_send2( SI_Socket * siSocket, char * buffer, int len, uint16_t streamInfo, uint32_t ppid)
{
	#if SCTP_SUPPORT
	
	struct sctp_sndrcvinfo sinfo;
	memset( &sinfo, 0, sizeof( struct sctp_sndrcvinfo));
	
	sinfo.sinfo_stream = streamInfo;
	sinfo.sinfo_flags = 0;
	//sinfo.sinfo_ppid = htonl(ppid);
	sinfo.sinfo_ppid = htonl(siSocket->PPID);
	
	//sinfo.sinfo_assoc_id = 0;
	
	/*
	__u16 sinfo_stream;
    __u16 sinfo_ssn;
    __u16 sinfo_flags;
    __u32 sinfo_ppid;
    __u32 sinfo_context;
    __u32 sinfo_timetolive;
    __u32 sinfo_tsn;
    __u32 sinfo_cumtsn;
    sctp_assoc_t sinfo_assoc_id;
	*/
	
	if( siSocket->isConnected == 1) 
	{
		int fd = siSocket->fd;
		
		if( fd > 0) 
		{
			siSocket->BeforeMessageSend++;
			int sentBytes = sctp_send( fd, buffer, len, &sinfo, MSG_NOSIGNAL);
			siSocket->AfterMessageSent++;
			
			if( sentBytes <= 0)
			{
				if( EPIPE == errno)
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "error while sending data, closing sctp socket fd=%d as sentBytes=%d is < 0 errorno=%d strerror=%s EPIPE(%d) ip=%s port=%d  <%s|%s|%d>", 
						siSocket->fd, sentBytes, errno, strerror(errno), EPIPE, siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);				

					siSocket->isConnected = 0;
					siSocket->isActive = 0;			
					close( fd);
					shutdown( fd, 2);
				}
				else
				{
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP: socket error while sending data fd=%d as sentBytes=%d is < 0 errorno=%d strerror=%s ip=%s port=%d  <%s|%s|%d>", 
						siSocket->fd, sentBytes, errno, strerror(errno), siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
				}
			}
			
			return sentBytes;
		} else {
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sending data failed fd=%d already closed sctp socket %s|%s|%d", fd, __FILE__, __FUNCTION__, __LINE__);
			return -1;
		}
	} 
	else 
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sending data on not-connected sctp socket %s|%s|%d", __FILE__, __FUNCTION__, __LINE__);
		return -1;
	}
	
	#endif
	
	return 0;
}

SI_Socket * __si_socket_engine__get_next_socket_for_poll_signal()
{
	pthread_mutex_lock( &__si_socketEngine->SocketLock);
	
	SI_Socket * socketPtr = NULL;
	
	if(__si_socketEngine->lkPollLastPolledSignalSocket) {
		socketPtr = __si_socketEngine->lkPollLastPolledSignalSocket->Next;
	}
	
	if(!socketPtr) {
		socketPtr = __si_socketEngine->SocketHead;
	}
	
	while(socketPtr)
	{
		if( socketPtr->TransportType == SIRIK_TRANSPORT_TYPE_SCTP && socketPtr->UseEPoll == 2 && socketPtr->isActive == 1)
		{
			__si_socketEngine->lkPollLastPolledSignalSocket = socketPtr;
			pthread_mutex_unlock( &__si_socketEngine->SocketLock);
			return socketPtr;
		}
		socketPtr = socketPtr->Next;
	}
	
	pthread_mutex_unlock( &__si_socketEngine->SocketLock);
	return NULL;
}


SI_Socket * __si_socket_engine__get_next_socket_for_poll()
{
	pthread_mutex_lock( &__si_socketEngine->SocketLock);
	
	SI_Socket * socketPtr = NULL;
	
	if(__si_socketEngine->lkPollLastPolledSocket) 
	{
		socketPtr = __si_socketEngine->lkPollLastPolledSocket->Next;
		
		// if( socketPtr)
		// {
			// printf( "1 socketPtr=%p TransportType=%d %d\n", socketPtr, socketPtr->TransportType, __LINE__);
		// }
	}
	
	if( socketPtr)
	{
		while(socketPtr)
		{
			if( socketPtr->TransportType == SIRIK_TRANSPORT_TYPE_SCTP)
			{
				break;
			}
			socketPtr = socketPtr->Next;
		}
	}
	
	if(!socketPtr) 
	{
		socketPtr = __si_socketEngine->SocketHead;
		//printf( "2 socketPtr=%p %d\n", socketPtr, __LINE__);
	}
	
	while(socketPtr)
	{
		// printf( "xxxxxxxxxxx searching TransportType=%d UseEPoll=%d isActive=%d isListner=%d\n", 
					// socketPtr->TransportType, socketPtr->UseEPoll, socketPtr->isActive, socketPtr->isListner);
					
		// sleep(1);
		
		if( socketPtr->TransportType == SIRIK_TRANSPORT_TYPE_SCTP && socketPtr->UseEPoll == 2 && socketPtr->isActive == 1 && socketPtr->isListner == 0)
		{
			__si_socketEngine->lkPollLastPolledSocket = socketPtr;
			pthread_mutex_unlock( &__si_socketEngine->SocketLock);
			
			//printf( "---------- sending 3 socketPtr=%p %d\n", socketPtr, __LINE__);
			return socketPtr;
		}
		socketPtr = socketPtr->Next;
	}
	
	pthread_mutex_unlock( &__si_socketEngine->SocketLock);
	return NULL;
}


void * __si_socket_engine_sctp_start_poll_signal_thread( void * args)
{
	SI_Socket * socket = NULL;
	
	// while(1)
	// {
		
		
		// __si_nanosleep( 999999999/500 );	//60 times in second
	// }
	return NULL;
}

void * __si_socket_engine_sctp_start_poll_read_thread( void * args)
{
	SI_SocketThread * socketThread = (SI_SocketThread *)args;
	SI_Socket * socket = NULL;

	//printf("created __si_socket_engine_sctp_start_poll_read_thread = %d\n", socketThread->index);

	#if SCTP_SUPPORT

	struct pollfd fds;	
	int ret, flags, n;
	struct sctp_sndrcvinfo sinfo = {0};
	SI_SocketSCTPBuffer * sctpBuffer = NULL;

	int scokswitch = 1;
	
	while(1)
	{
		//usleep(999999);
		if( scokswitch == 1)
		{
			// printf("TT=%d  l=%d %s\n", 3, __LINE__, __FILE__);
			// sleep(1);
			
			socket = __si_socket_engine__get_next_socket_for_poll();
			memset( &fds, 0, sizeof(struct pollfd));
		}
		
		// if(!socket)
		// {
			// SI_Socket * dSocketPtr = __si_socketEngine->SocketHead;
			
			// while(dSocketPtr)
			// {
				// //if( socketPtr->TransportType == SIRIK_TRANSPORT_TYPE_SCTP && socketPtr->UseEPoll == 2 && socketPtr->isActive == 1 && socketPtr->isListner == 0)
				
				// printf( "TransportType=%d UseEPoll=%d isActive=%d isListner=%d\n", 
					// dSocketPtr->TransportType, dSocketPtr->UseEPoll, dSocketPtr->isActive, dSocketPtr->isListner);
				
				// dSocketPtr = dSocketPtr->Next;
			// }
			
			// sleep(1);
		// }
		
		//printf("%d  socket=%p\n", socketThread->index, socket);
		
		// printf("TT=%d socket=%p id=%lu  l=%d %s\n", 3, socket,  socketThread->id, __LINE__, __FILE__);
		// sleep(1);
		if( socket)
		{
			//printf("started sctp recv thread 2 TT=%d\n", socket->TransportType);
			//printf("ENT TT=%d socket=%p id=%lu  l=%d %s\n", 3, socket,  socketThread->id, __LINE__, __FILE__);
			
			memset( &sinfo, 0, sizeof(struct sctp_sndrcvinfo));
			
			fds.fd     = socket->fd;
			fds.events = POLLIN;
		
			ret = poll( &fds, 1, 1000);
			
			if( ret == 0)
			{
				// printf("TT=%d  l=%d %s\n", socket->TransportType, __LINE__, __FILE__);
				// sleep(1);
				scokswitch = 1;
				continue;
			}
		
			if( ret < 0)
			{
				// printf("TT=%d  l=%d %s\n", socket->TransportType, __LINE__, __FILE__);
				// sleep(1);
				
				close( socket->fd);
				shutdown( socket->fd, 2);
				socket->isConnected = 0;
				socket->isActive = 0;

				if( socket->OnClose > 0)
				{
					// printf("TT=%d  l=%d %s\n", socket->TransportType, __LINE__, __FILE__);
					// sleep(1);
					
					__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp closed socket fd=%d ret=%d calling OnClose %s|%s|%d", socket->fd, ret, __FILE__, __FUNCTION__, __LINE__);
					socket->OnClose( socket);
				}

				scokswitch = 1;
				continue;
			}
			
			if( ret > 0)
			{
				// printf("TT=%d  l=%d %s\n", socket->TransportType, __LINE__, __FILE__);
				// sleep(1);
				
				sctpBuffer = __si_socket_engine_allocate_sctp_socket_buffer();
				sctpBuffer->pos = 0;
				
				n = sctp_recvmsg( socket->fd, sctpBuffer->buff, sizeof( sctpBuffer->buff), (struct sockaddr *)NULL, 0, &sinfo, &flags);
				sctpBuffer->len = n;
				
				// printf("TT=%d  l=%d %s\n", socket->TransportType, __LINE__, __FILE__);
				// sleep(1);
				
				if( flags & MSG_NOTIFICATION )
				{
					union sctp_notification  *snp = (union sctp_notification *)sctpBuffer->buff;
					
					if(snp)
					{
						if( SCTP_ASSOC_CHANGE == snp->sn_header.sn_type)
						{
							struct sctp_assoc_change * sac = &snp->sn_assoc_change;

							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_ASSOC_CHANGE Event Received sac_assoc_id=%d  sac_outbound_streams=%d  sac_inbound_streams=%d <%s|%s|%d>", 
								sac->sac_assoc_id, sac->sac_outbound_streams, sac->sac_inbound_streams, __FILE__, __FUNCTION__, __LINE__);
						
							socket->peer_max_o_streams = sac->sac_outbound_streams;
							socket->peer_max_i_streams = sac->sac_inbound_streams;
						}
						else if( SCTP_PEER_ADDR_CHANGE == snp->sn_header.sn_type)
						{
							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_PEER_ADDR_CHANGE Notified <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
						}
						else if( SCTP_SHUTDOWN_EVENT == snp->sn_header.sn_type )
						{
							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_SHUTDOWN_EVENT Notified, closing connection <%s|%s|%d>", __FILE__, __FUNCTION__, __LINE__);
							
							__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
							close( socket->fd);
							shutdown( socket->fd, 2);
							socket->isConnected = 0;
							socket->isActive = 0;
							socket->UnknownSCTPEventCount = 0;
							
							scokswitch = 1;
							continue;
						}
						else if( SCTP_SEND_FAILED == snp->sn_header.sn_type)	
						{
							struct sctp_send_failed * fev = &snp->sn_send_failed;
							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_SEND_FAILED_EVENT Event Received ssf_assoc_id=%d closing connection  <%s|%s|%d>", 
								fev->ssf_assoc_id, __FILE__, __FUNCTION__, __LINE__);

							__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
							close( socket->fd);
							shutdown( socket->fd, 2);
							socket->isConnected = 0;
							socket->isActive = 0;
							socket->UnknownSCTPEventCount = 0;
							
							scokswitch = 1;
							continue;
						}
						else if( SCTP_REMOTE_ERROR == snp->sn_header.sn_type)
						{
							struct sctp_remote_error * ree = &snp->sn_remote_error;
							
							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP_REMOTE_ERROR Event Received sre_assoc_id=%d closing=%d  <%s|%s|%d>", 
								ree->sre_assoc_id,  socket->fd, __FILE__, __FUNCTION__, __LINE__);
							
							__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
							close( socket->fd);
							shutdown( socket->fd, 2);
							socket->isConnected = 0;
							socket->isActive = 0;
							socket->UnknownSCTPEventCount = 0;
							
							scokswitch = 1;
							continue;
						}
						else
						{
							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP MSG_NOTIFICATION - Event Received with event=%d, Closing Socket  <%s|%s|%d>", 
								snp->sn_header.sn_type, __FILE__, __FUNCTION__, __LINE__);

							socket->UnknownSCTPEventCount++;
						}
						
						if( socket->UnknownSCTPEventCount > 10)
						{
							__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
							close( socket->fd);
							shutdown( socket->fd, 2);
							socket->isConnected = 0;
							socket->isActive = 0;
							socket->UnknownSCTPEventCount = 0;
							
							scokswitch = 1;
							continue;
						}
					}
					
					__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
				}
				else
				{
					// printf("TT=%d  l=%d %s\n", socket->TransportType, __LINE__, __FILE__);
					// sleep(1);
					
					if( (ret == 1 && n == 0) || n < 0)
					{
						__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "SCTP error ret=%d n=%d, closing connection <%s|%s|%d>", ret, n, __FILE__, __FUNCTION__, __LINE__);
						
						__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
						close( socket->fd);
						shutdown( socket->fd, 2);
						socket->isConnected = 0;
						socket->isActive = 0;

						pthread_mutex_lock( &socket->OnCloseLock);
						
						if( socket->OnClose > 0 && socket->OnCloseFired == 0)
						{
							__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp closed socket fd=%d ret=%d calling OnClose %s|%s|%d", socket->fd, ret, __FILE__, __FUNCTION__, __LINE__);
							socket->OnClose( socket);
							socket->OnCloseFired = 1;
						}
						
						pthread_mutex_unlock( &socket->OnCloseLock);

						
						scokswitch = 1;
						continue;
					}
					
					socket->UnknownSCTPEventCount = 0;
					
					if( n > 0)
					{
						// printf("TT=%d  l=%d %s\n", socket->TransportType, __LINE__, __FILE__);
						// sleep(1);
						
						sctpBuffer->ppid = ntohl( sinfo.sinfo_ppid);
						sctpBuffer->streamId = sinfo.sinfo_stream;
						sctpBuffer->siThread = socketThread;
						sctpBuffer->siSocket = socket; 
						socketThread->TotalReads++;
						socket->ReceivedMessages++;
						
						scokswitch = 0;
						__si_core_queue_item_force( __si_socketEngine->queueSctpSocketBufferPoolObject, sctpBuffer, 1);
					}
					else
					{
						// printf("TT=%d  l=%d %s\n", socket->TransportType, __LINE__, __FILE__);
						// sleep(1);
						
						scokswitch = 1;
						__si_socket_engine_release_sctp_socket_buffer( sctpBuffer);
					}
				}
			}
		
		}
		else 
		{
			__si_nanosleep( 999999999/60 );	//60 times in second
		}
	}
	
	#endif
	
	return NULL;
}

void __si_socket_engine___sctp_client_attach_to_poll( SI_Socket * siSocket)
{
	pthread_mutex_lock( &__si_socketEngine->lkPollSctpThreadLock);
	
	if(!__si_socketEngine->lkPollSctpThreadHead)
	{
		int i = 0;
		for( i = 0;i < __si_socketEngine->InitialPollThreads; i++)
		{
			SI_SocketThread * socketThread = (SI_SocketThread *)malloc( sizeof(SI_SocketThread));
			memset( socketThread, 0, sizeof( SI_SocketThread));
			
			if(!__si_socketEngine->lkPollSctpThreadHead)
			{
				__si_socketEngine->lkPollSctpThreadHead = __si_socketEngine->lkPollSctpThreadCurrent = socketThread;
			}
			else
			{
				__si_socketEngine->lkPollSctpThreadCurrent->Next = socketThread;
				__si_socketEngine->lkPollSctpThreadCurrent = socketThread;
			}
			
			socketThread->id = i;
			socketThread->isHost = 0;
			socketThread->isActive = 1;
			socketThread->index = __si_socketEngine->PollThreadsCount;
			socketThread->is_poll_thread = 1;
			socketThread->count = 0;
			socketThread->LastReads = 0;
			socketThread->LastTotalReads = 0;
			socketThread->TotalReads = 0;
			pthread_mutex_init( &socketThread->CountLock, NULL);			
			sem_init( &socketThread->sem_lock, 0, 0);
			__si_socketEngine->PollThreadsCount++;
			
			//printf("created sctp poll thread %d\n", __si_socketEngine->PollThreadsCount);
			__si_create_pthread2( __si_socket_engine_sctp_start_poll_read_thread, socketThread, "si_r_socket");
		}
		
		// int i = 0;
		// for( i = 0;i < 5; i++)
		// {
			// __si_create_pthread2( __si_socket_engine_sctp_start_poll_signal_thread, socketThread, "si_ps_socket");
		// }
	}
	
	pthread_mutex_unlock( &__si_socketEngine->lkPollSctpThreadLock);
}

void __si_socket_engine___sctp_client_attach_to_epoll( SI_Socket * siSocket)
{
	if( siSocket->isConnected == 1)
	{
		SI_SocketThread * oThreadHead = NULL;

		__si_socket_get_lksctp_epoll_read_thread( &oThreadHead);
		
		pthread_mutex_lock( &oThreadHead->epollSocketFdCountLock);
		oThreadHead->epollSocketFdCount++;
		pthread_mutex_unlock( &oThreadHead->epollSocketFdCountLock);
		
		
		siSocket->epollThread = oThreadHead;
		
		struct epoll_event event;
		memset( &event, 0, sizeof(struct epoll_event));
		
		event.data.fd = siSocket->fd;
		event.data.ptr = siSocket;
		
		event.events = EPOLLIN | EPOLLET | EPOLLHUP | EPOLLERR;

		siSocket->epoll_fd = oThreadHead->epoll_fd;
		int s = epoll_ctl ( oThreadHead->epoll_fd, EPOLL_CTL_ADD, siSocket->fd, &event);
		
		//printf("attached client is epoll=%p fd=%d siSocket=%p fd=%d  %s|%d\n", oThreadHead, oThreadHead->epoll_fd, siSocket, siSocket->fd, __FILE__, __LINE__);

		if (s == -1) 
		{
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "attach failed for new tcp scoket sfd=%d to epoll index=%d with efd=%d (%s|%s|%d)", 
				siSocket->fd, oThreadHead->index, oThreadHead->epoll_fd, __FILE__, __FUNCTION__, __LINE__);
		}
		else
		{
			__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "attached new tcp scoket sfd=%d to epoll index=%d with efd=%d (%s|%s|%d)", 
				siSocket->fd, oThreadHead->index, oThreadHead->epoll_fd, __FILE__, __FUNCTION__, __LINE__);
		}		
	}
}

void * __si_socket_engine___client_connection( void * args)
{
	int i = 0;
	SI_Socket * siSocket = NULL;
	
	while(1) 
	{
		siSocket = __si_socketEngine->SocketHead;
		
		while( siSocket)
		{
			if( siSocket->isActive == 0 && siSocket->isHost == 0 && siSocket->isConnected == 0 && siSocket->disableClientAutoReConnect == 0 && (siSocket->UseEPoll == 1 || siSocket->UseEPoll == 2))
			{
				__si_socket_engine_sctp_connect_socket( siSocket);
				
				//printf("UseEPoll=%d  %s|%s|%d\n", siSocket->UseEPoll, __FILE__, __FUNCTION__, __LINE__);
				
				if( siSocket->UseEPoll == 1) {
					__si_socket_engine___sctp_client_attach_to_epoll( siSocket);
				} else if( siSocket->UseEPoll == 2) {
					__si_socket_engine___sctp_client_attach_to_poll( siSocket);
				}
			}
			
			siSocket = siSocket->Next;
		}
		
		
		for( i = 0; i < 3; i++)
		{
			usleep(999999);
		}	
	}
}



void __si_socket_engine_sctp_client_socket_start_read_thread( SI_Socket * siSocket)
{
	if( siSocket->UseEPoll == 0)
	{
		SI_SocketThread * oThreadHead = NULL;
		__si_malloc2( sizeof(SI_SocketThread), (uint8_t **) &oThreadHead);
		memset( oThreadHead, 0, sizeof( SI_SocketThread));
		
		pthread_mutex_init( &oThreadHead->epollSocketFdCountLock, NULL);

		oThreadHead->usiSocket = ( uint8_t *) siSocket;
		oThreadHead->isActive = 0;
		oThreadHead->isHost = 0;
		siSocket->isConnected = 0;
		
		siSocket->clientReadThread = oThreadHead;
		__si_create_pthread2( __si_socket_engine_sctp_start_read_thread, oThreadHead, "si_r_socket");
	}
	else
	{
		/*
			see: __si_socket_engine___client_connection
			
			__si_socket_engine___sctp_client_attach_to_epoll
		*/
	}
}


int __si_socket_engine_sctp_connect_socket( SI_Socket * siSocket)
{
	__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "connect to socket RemoteIPPort:%d <%s|%s|%d>", siSocket->RemoteIPPort, __FILE__, __FUNCTION__, __LINE__);
	
	#if SCTP_SUPPORT
	
	siSocket->isHost = 0;
	
	/*
	
	pthread_mutex_lock( &siSocket->ConnectLock);
	
	if(!siSocket->clientReadThread)
	{
		// printf("client read thread is empty, creating new\n");

		__si_socket_get_lksctp_read_thread( &siSocket->clientReadThread);
		siSocket->clientReadThread->usiSocket = ( uint8_t *) siSocket;
		
		siSocket->clientReadThread->isActive = 0;
		siSocket->clientReadThread->fd = 0;
		siSocket->clientReadThread->isHost = 0;
		
		//sem_post( &siSocket->clientReadThread->sem_lock);
		// printf("client read thread is empty, created new\n");
	}
	
	pthread_mutex_unlock( &siSocket->ConnectLock);
	*/
	
	
	int fd = 0, ret = 0;
	struct sctp_initmsg   initmsg;
    struct sctp_event_subscribe events;	

	//printf( "IPVersion=%u %s|%d\n", siSocket->IPVersion, __FILE__, __LINE__);

	if( siSocket->IPVersion == SIRIK_IP_VERSION_4) {
		fd = socket( AF_INET, SOCK_STREAM, IPPROTO_SCTP);
	} else {
		fd = socket( AF_INET6, SOCK_STREAM, IPPROTO_SCTP);
	}
	
	if (fd == -1) 
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "ipv4 socket creation failed for sctp peer-connection for IP=%s Port[%d] <%s|%s|%d>", 
			siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);	
			
		return -1;
	}
	
	/*
	__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "ipv4 socket creation success for sctp peer-connection for IP=%s Port[%d] <%s|%s|%d>", 
		siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
	*/
	
	events.sctp_data_io_event = 1;
	events.sctp_association_event = 1;
	events.sctp_send_failure_event = 1;
	events.sctp_address_event = 1;
	events.sctp_peer_error_event = 1;
	events.sctp_shutdown_event = 1;	
	ret = setsockopt( fd, IPPROTO_SCTP, SCTP_EVENTS, &events, sizeof (events));
	
	if (ret < 0) 
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "set socket options SCTP_EVENTS failed for sctp peer-connection for IP=%s Port[%d] <%s|%s|%d>", 
			siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
		
		return -1;
	}

	//default, if user set then user values will be neagotatited
	initmsg.sinit_num_ostreams = 3;
	initmsg.sinit_max_instreams = 3;
	
	if( siSocket->max_o_streams > 0) 
	{
		//get it from config
		initmsg.sinit_num_ostreams = siSocket->max_o_streams;
	}  else  {
		//or assign default value, so that child connections can set to same values (will be inherited from parent SI_Socket)
		siSocket->max_o_streams = initmsg.sinit_num_ostreams;
	}
	
	if( siSocket->max_i_streams > 0)
	{	
		initmsg.sinit_max_instreams = siSocket->max_i_streams;
	} else {
		siSocket->max_i_streams = initmsg.sinit_max_instreams;
	}
	
	

	memset(&initmsg, 0, sizeof(struct sctp_initmsg));
	initmsg.sinit_num_ostreams = siSocket->max_o_streams;
	initmsg.sinit_max_instreams = siSocket->max_i_streams;
	initmsg.sinit_max_attempts = 4;
	siSocket->peer_max_i_streams = 1;
	siSocket->peer_max_o_streams = 1;
	siSocket->BeforeMessageSend = 0;
	siSocket->AfterMessageSent = 0;
	siSocket->ReceivedMessages = 0;
	siSocket->LastMessageSent = 0;
	siSocket->LastReceivedMessages = 0;
	
	//printf("connect setsockopt sinit_max_instreams=%u sinit_num_ostreams=%u  %s|%d\n", initmsg.sinit_max_instreams, initmsg.sinit_num_ostreams, __FILE__, __LINE__);	
	
	ret = setsockopt( fd, IPPROTO_SCTP, SCTP_INITMSG, &initmsg, sizeof(struct sctp_initmsg));

	if (ret < 0) 
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "set socket options SCTP_INITMSG failed for sctp peer-connection for IP=%s Port[%d] <%s|%s|%d>", 
			siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
			
		return -1;
	}

	int is = 0;
	struct sockaddr_in serveraddr1;
	struct sockaddr_in6 serveraddr6;
	
	//memset( &serveraddr1, 0, sizeof(struct sockaddr_in));
	//memset( &serveraddr6, 0, sizeof(struct sockaddr_in6));
	
	int ierror;
	
	if( siSocket->IPAddressCount == 0)
	{
		printf("please set IPAddresses:%d %s|%s|%d\n", siSocket->IPAddressCount, __FILE__, __FUNCTION__, __LINE__);
		return -1;
	}	
	
	for( is = 0; is < siSocket->IPAddressCount; is++)
	{
		memset( &serveraddr1, 0, sizeof(struct sockaddr_in));
		memset( &serveraddr6, 0, sizeof(struct sockaddr_in6));
		
		serveraddr1.sin_family = AF_INET;
		serveraddr1.sin_addr.s_addr = inet_addr( siSocket->IPAddresses[ is].IPAddress);
		
		serveraddr6.sin6_family = AF_INET6;
		
		if( siSocket->IPVersion == SIRIK_IP_VERSION_6) 
		{
			//serveraddr6.sin_addr.s_addr = inet_addr( siSocket->IPAddresses[ is].IPAddress);
			if( inet_pton( AF_INET6, siSocket->IPAddresses[ is].IPAddress, &serveraddr6.sin6_addr.s6_addr) != 1)
			{
				printf("configured IPv6=%s Address Is Not Valid %s|%d\n", siSocket->IPAddresses[ is].IPAddress, __FILE__, __LINE__);
				exit(0);
			}
		}
		
		if( siSocket->IPPort > 0) 
		{	
			serveraddr1.sin_port = htons( siSocket->IPPort);
			serveraddr6.sin6_port = htons( siSocket->IPPort);
		}
		
		if( siSocket->IPVersion == SIRIK_IP_VERSION_6) 
		{
			serveraddr6.sin6_scope_id = __si_socket__get_sin6_scope_id( (uint8_t *)&serveraddr6.sin6_addr.s6_addr);
			//printf("local-addr IPv6=%s interface-id=%u port=%u\n", siSocket->IPAddresses[ is].IPAddress, serveraddr6.sin6_scope_id, serveraddr6.sin6_port);
			ierror = sctp_bindx( fd, (struct sockaddr*)&serveraddr6, 1, SCTP_BINDX_ADD_ADDR);
		} 
		else 
		{
			ierror = sctp_bindx( fd, (struct sockaddr*)&serveraddr1, 1, SCTP_BINDX_ADD_ADDR);
		}
		
		__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp socket binding local[%d] IP-Address=%s Client-Port=%d sin6_scope_id=%u  <%s|%s|%d>", is, siSocket->IPAddresses[is].IPAddress, siSocket->IPPort, serveraddr6.sin6_scope_id, __FILE__, __FUNCTION__, __LINE__);
		
		if ( ierror < 0) 
		{
			printf("[ error with sctp_bindx errno:%d (%s) ] IP-Address:%s port[%d] %s|%d\n", errno, strerror( errno), siSocket->IPAddresses[ is].IPAddress, siSocket->IPPort, __FUNCTION__, __LINE__);
			printf("sin6_scope_id=%u ", serveraddr6.sin6_scope_id);
			__si_print_buffer( (char *)&serveraddr6.sin6_addr.s6_addr, 16);
		}
	}
	
	if( siSocket->IPAddressCount > 0) 
	{
		/*
		struct sctp_prim sprimaddr;
		memset( &sprimaddr, 0, sizeof(struct sctp_prim));
		int len = sizeof( struct sctp_prim);
		
		struct sockaddr_in * gaddr = (struct sockaddr_in *) &sprimaddr.ssp_addr;
		gaddr->sin_family = AF_INET;
		gaddr->sin_addr.s_addr = inet_addr( siSocket->IPAddresses[0].IPAddress);
		
		//memcpy(&(sprimaddr.ssp_addr), &(local_addr[0]), sizeof (local_addr[0]));
		
		//ierror = setsockopt( fd, IPPROTO_SCTP, SCTP_PRIMARY_ADDR, &sprimaddr, len);
		*/
		
		/*
		struct sockaddr_in addr_in;
		memset( &addr_in, 0, sizeof(struct sockaddr_in));
		addr_in.sin_family = AF_INET;
		addr_in.sin_addr.s_addr = inet_addr( siSocket->IPAddresses[0].IPAddress);
		
		ierror = setsockopt( fd, SOL_SCTP, SCTP_SOCKOPT_BINDX_ADD, addr_buf, sizeof(struct sockaddr_in));
		
		printf("primary address setup done ierror=%d error=%s Address=%s\n", ierror, strerror( errno), siSocket->IPAddresses[0].IPAddress);
		*/
		
	}
	
	/*
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = inet_addr( siSocket->IPAddresses[ 0].IPAddress);
	addr.sin_port = htons( siSocket->IPPort);
	
	sctp_assoc_t sctp_assId = 0;

	// this will never free because its client
	siSocket->isFree = 0;	
	siSocket->clientReadThread->fd = 0;
	siSocket->clientReadThread->isActive = 0;	
	
	if ( sctp_connectx( fd, (struct sockaddr *)&addr, 1, &sctp_assId) == -1)
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "connection to sctp peer-server failed for IP=%s Port[%d] <%s|%s|%d>", 
			siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
		
		siSocket->fd = 0;
		siSocket->isConnected = 0;
		siSocket->isActive = 0;
		
		printf("sctp connection failure, unable to connected to server at port :%d  %s|%s|%d\n", 
			siSocket->IPPort, __FILE__, __FUNCTION__, __LINE__);
		
		return -1;
	}
	*/
	
	if( siSocket->RemoteIPAddressCount == 0)
	{
		printf("please set RemoteIPAddressses:%d %s|%s|%d\n", siSocket->RemoteIPAddressCount, __FILE__, __FUNCTION__, __LINE__);
		return -1;
	}

	struct sockaddr_in addrs[siSocket->RemoteIPAddressCount];
	struct sockaddr_in6 addrs6[siSocket->RemoteIPAddressCount];
	
	if( siSocket->IPVersion == SIRIK_IP_VERSION_4) 
	{
		memset( &addrs, 0, sizeof(addrs));
		
		for( is = 0; is < siSocket->RemoteIPAddressCount; is++)
		{
			addrs[is].sin_family = AF_INET;
			addrs[is].sin_addr.s_addr = inet_addr( siSocket->RemoteIPAddresses[is].IPAddress);
			addrs[is].sin_port = htons( siSocket->RemoteIPPort);
			
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp socket binding remote [%d] %s:%d <%s|%s|%d>", is, 
				siSocket->RemoteIPAddresses[is].IPAddress, siSocket->RemoteIPPort, __FILE__, __FUNCTION__, __LINE__);
		}
	}
	else
	{
		memset( &addrs6, 0, sizeof(addrs6));

		for( is = 0; is < siSocket->RemoteIPAddressCount; is++)
		{
			addrs6[is].sin6_family = AF_INET6;
			//addrs6[is].sin6_addr.s_addr = inet_addr( siSocket->RemoteIPAddresses[is].IPAddress);
			
			if( inet_pton( AF_INET6, siSocket->RemoteIPAddresses[is].IPAddress, &addrs6[is].sin6_addr.s6_addr) != 1)
			{
				printf("configured IPv6=%s Address Is Not Valid  %s|%d\n", siSocket->RemoteIPAddresses[is].IPAddress, __FILE__, __LINE__);
				//exit(0);
			}
			
			addrs6[is].sin6_port = htons( siSocket->RemoteIPPort);
			
			//if its local-ip?
			//set interface-id of local machine
			addrs6[is].sin6_scope_id = serveraddr6.sin6_scope_id;	//__si_socket__get_sin6_scope_id( (uint8_t *)&addrs6[is].sin6_addr.s6_addr);
		
			// printf("remoteip=%s sin6_port=%u|%u \n", siSocket->RemoteIPAddresses[is].IPAddress, siSocket->RemoteIPPort, addrs6[is].sin6_port);
			// __si_print_buffer( (char *)&addrs6[is].sin6_addr.s6_addr, 16);
			// exit(0);

			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "sctp socket binding remote [%d] %s:%d if_index=%u <%s|%s|%d>", is, 
				siSocket->RemoteIPAddresses[is].IPAddress, siSocket->RemoteIPPort, addrs6[is].sin6_scope_id, __FILE__, __FUNCTION__, __LINE__);
		}
	}
	
	
	sctp_assoc_t sctp_assId = 0;

	// this will never free because its client
	siSocket->isFree = 0;	
	
	if( siSocket->clientReadThread)
	{	
		siSocket->clientReadThread->fd = 0;
		siSocket->clientReadThread->isActive = 0;	
	}
	
	__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "calling sctp sctp_connectx %s:%d RemoteIPAddressCount=%d <%s|%s|%d>", 
		siSocket->RemoteIPAddresses[0].IPAddress, siSocket->RemoteIPPort, siSocket->RemoteIPAddressCount, __FILE__, __FUNCTION__, __LINE__);
	
	int connect_sts = 0;
	
	if( siSocket->IPVersion == SIRIK_IP_VERSION_4) 
	{
		connect_sts = sctp_connectx( fd, (struct sockaddr *)&addrs, siSocket->RemoteIPAddressCount, &sctp_assId);
	}
	else
	{
		//printf("remote ip-address  port=%u RemoteIPAddressCount=%u  ", siSocket->RemoteIPPort, siSocket->RemoteIPAddressCount);
		//__si_print_buffer( (char *)&addrs6[0].sin6_addr.s6_addr, 16);
		
		//if remote address is local ip, bind to if_index
		//addrs6[0].sin6_scope_id = 2;
		//uint32_t sin6_scope_id = __si_socket__get_sin6_scope_id( (uint8_t *)&serveraddr6.sin6_addr.s6_addr);
		
		connect_sts = sctp_connectx( fd, (struct sockaddr *)&addrs6, siSocket->RemoteIPAddressCount, &sctp_assId);
	}
	
	//printf("fd=%d ip=%s connect_sts=%d  IPVersion=%d\n", fd, siSocket->RemoteIPAddresses[0].IPAddress, connect_sts, siSocket->IPVersion);
	//__si_print_buffer( addrs6[0].sin6_addr.s6_addr, 16);
	
	if ( connect_sts == -1)
	{
		__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "connection to sctp peer-server failed for IP=%s Port[%d] errno=[%d|%s] <%s|%s|%d>", 
			siSocket->RemoteIPAddresses[0].IPAddress, siSocket->RemoteIPPort, errno, strerror(errno), __FILE__, __FUNCTION__, __LINE__);
		
		//connect failed, unbind it
		if( siSocket->IPPort > 0) 
		{
			for( is = 0; is < siSocket->IPAddressCount; is++)
			{
				memset( &serveraddr1, 0, sizeof(struct sockaddr_in));
				serveraddr1.sin_family = AF_INET;
				serveraddr1.sin_addr.s_addr = inet_addr( siSocket->IPAddresses[ is].IPAddress);
				
				if( siSocket->IPPort > 0) {
					serveraddr1.sin_port = htons( siSocket->IPPort);
				}
				
				ierror = sctp_bindx( fd, (struct sockaddr*)&serveraddr1, 1, SCTP_BINDX_REM_ADDR);
			}
		}
		
		close( fd);
		
		siSocket->fd = 0;
		siSocket->isConnected = 0;
		siSocket->isActive = 0;
		
		//log statement present above
		//printf("sctp connection failure, unable to connected to server at port :%d  %s|%s|%d\n", 
		//	siSocket->RemoteIPPort, __FILE__, __FUNCTION__, __LINE__);
		
		return -1;
	}
	
	
	/*
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = inet_addr( siSocket->IPAddresses[ 0].IPAddress);
	addr.sin_port = htons( siSocket->IPPort);	
	*/
	
	
	siSocket->fd = fd;
	siSocket->isConnected = 1;
	siSocket->isActive = 1;
	
	if( siSocket->clientReadThread)
	{	
		siSocket->clientReadThread->fd = fd;
		siSocket->clientReadThread->isActive = 1;
	}
	
	int iNoDelay = 1;
	setsockopt( fd, IPPROTO_SCTP, SCTP_NODELAY, &iNoDelay, sizeof(int));
	
	if( siSocket->UseEPoll == 1)
	{
		fcntl( siSocket->fd, F_SETFL, fcntl( siSocket->fd, F_GETFL, 0) | O_NONBLOCK);
	}
	
	if( siSocket->OnConnected > 0)
	{
		siSocket->OnConnected( siSocket);
	}
	
	struct sctp_status ss2;
	memset( &ss2, 0, sizeof(struct sctp_status));
	socklen_t sz = sizeof(struct sctp_status);
	ierror = getsockopt( fd, IPPROTO_SCTP, SCTP_STATUS, &ss2, &sz);
	
	if( ierror != 0)
	{
		printf( "ierror=%d %d %d \n", ierror, ss2.sstat_outstrms, ss2.sstat_instrms);	
	} 
	else 
	{
		siSocket->peer_max_o_streams = ss2.sstat_outstrms;
	}
	

	struct sctp_paddrparams parms;
	memset( &parms, 0, sizeof(parms));
	
	if( siSocket->IPVersion == SIRIK_IP_VERSION_4) {
		parms.spp_address.ss_family = AF_INET;
	} else {
		parms.spp_address.ss_family = AF_INET6;
	}
	
	sz = sizeof( struct sctp_paddrparams);
	sctp_opt_info( fd, 0, SCTP_PEER_ADDR_PARAMS, &parms, &sz);
	//setsockopt( fd, IPPROTO_SCTP, SCTP_PEER_ADDR_PARAMS, &parms, sizeof(parms))
	
	parms.spp_flags = SPP_HB_ENABLE;
	parms.spp_hbinterval = 6000;
	
	setsockopt( fd, IPPROTO_SCTP, SCTP_PEER_ADDR_PARAMS, &parms, sizeof(parms));
	sctp_opt_info( fd, 0, SCTP_PEER_ADDR_PARAMS, &parms, &sz);

	printf("sctp connection success, connected to server at port :%d  connect_sts=%d peer_max_o_streams=%u hbinterval=%u  %s|%d\n", 
		siSocket->RemoteIPPort, connect_sts, siSocket->peer_max_o_streams, parms.spp_hbinterval, __FILE__, __LINE__);
	
	return 1;
	
	#endif
	return 0;
}

int __si_socket_engine_tcp_connect_socket( SI_Socket * siSocket)
{
	pthread_mutex_lock( &siSocket->ConnectLock);
	
	if( siSocket->isConnected == 1)
	{
		pthread_mutex_unlock( &siSocket->ConnectLock);
		return siSocket->isConnected;
	}
	
	siSocket->fd = 0;
	siSocket->isConnected = 0;
	siSocket->isActive = 0;			
	siSocket->noDelay = 1;
	
	int iPort = siSocket->IPPort;
	int serverSocket;
	struct sockaddr_in cli_addr;
	struct sockaddr_in6 cli_addr6;	

	__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "connecting to ip=%s port=%d ver=%d <%s|%s|%d>", 
			siSocket->IPAddresses[0].IPAddress, iPort, siSocket->IPVersion, __FILE__, __FUNCTION__, __LINE__);
	
	memset( siSocket->host, 0, sizeof(siSocket->host));
	memcpy( siSocket->host, siSocket->IPAddresses[0].IPAddress, strlen(siSocket->IPAddresses[0].IPAddress));
	
	if( siSocket->IPVersion == SIRIK_IP_VERSION_4)
	{	
		serverSocket = socket( PF_INET, SOCK_STREAM, 0);
		
		if( serverSocket < 0)
		{	
			printf("client socket creation failed\n");
			
			pthread_mutex_unlock( &siSocket->ConnectLock);
			return -1;
		}		
		
		cli_addr.sin_family = PF_INET;
		cli_addr.sin_addr.s_addr = inet_addr( siSocket->IPAddresses[0].IPAddress );
		cli_addr.sin_port = htons( iPort);

		memset(&(cli_addr.sin_zero), '\0', 8);		
		
		if( siSocket->RemoteIPPort > 0)
		{
			struct sockaddr_in sa_loc;
			memset(&sa_loc, 0, sizeof(struct sockaddr_in));
			sa_loc.sin_family = AF_INET;
			sa_loc.sin_port = htons( siSocket->RemoteIPPort);
			sa_loc.sin_addr.s_addr = inet_addr( siSocket->RemoteIPAddresses[0].IPAddress);
			
			int bindsts = bind( serverSocket, (struct sockaddr *)&sa_loc, sizeof( struct sockaddr));
			//printf( "Client Port Bind Status=%d %s|%d\n", bindsts, __FILE__, __LINE__);
		}
		
		if ( connect( serverSocket, (struct sockaddr *)&cli_addr, sizeof(struct sockaddr_in)) == -1)
		{
			//printf("error=%d msg=%s\n", errno, strerror(errno));
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "connection failed with fd=%d for ip=%s port=%d<%s|%s|%d>", 
				serverSocket, siSocket->IPAddresses[0].IPAddress, iPort, __FILE__, __FUNCTION__, __LINE__);
			
			close( serverSocket);
			//shutdown( serverSocket, 2);
			
			pthread_mutex_unlock( &siSocket->ConnectLock);
			return -1;
		}	
	}
	else
	{
		serverSocket = socket( AF_INET6, SOCK_STREAM, 0);
		
		if( serverSocket < 0)
		{	
			printf("client socket creation failed\n");
			
			pthread_mutex_unlock( &siSocket->ConnectLock);
			return -1;
		}
	
		//printf( "connecting ipv6 with ip=%s with port=%d ver=%d\n", siSocket->IPAddresses[0].IPAddress, siSocket->IPPort, siSocket->IPVersion);
		
		memset( &cli_addr6, 0, sizeof( struct sockaddr_in6));
		cli_addr6.sin6_family = AF_INET6;
		cli_addr6.sin6_port = htons(iPort);	
		inet_pton( AF_INET6, siSocket->IPAddresses[0].IPAddress, &cli_addr6.sin6_addr);
		
		if ( connect( serverSocket, (struct sockaddr *)&cli_addr6, sizeof(struct sockaddr_in6)) == -1)
		{
			//printf("error=%d msg=%s\n", errno, strerror(errno));
			
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "connection failed with fd=%d for ip=%s port=%d<%s|%s|%d>", 
				serverSocket, siSocket->IPAddresses[0].IPAddress, iPort, __FILE__, __FUNCTION__, __LINE__);
				
			close( serverSocket);
			//shutdown( serverSocket, 2);
			
			pthread_mutex_unlock( &siSocket->ConnectLock);
			
			return -1;
		}	
	}
	
	#if TLS_SOCKET_SUPPORT

	if( siSocket->TlsEnabled == 1)
	{	
		printf( "tls enabled and doing connect now;\n");
		
		SSL_set_fd( siSocket->ssl, serverSocket);
		
		int ssl_connect_rv = SSL_connect( siSocket->ssl);
		
		if ( ssl_connect_rv != 1 )
		//if ( ssl_connect_rv == -1 )	
		{
			int i_error = ERR_get_error();
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "Socket: SSL_connect failed with ssl_error=%d err=%d err_str=%s", ssl_connect_rv, i_error, ERR_error_string( i_error, NULL));

			printf("SSL_connect error:\n");
			ERR_print_errors_fp(stderr);
			
			close( serverSocket);
			return -1;			
		}
		else
		{
			__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "SSL_connect success with result code=%d for fd=%d<%s|%s|%d>", ssl_connect_rv, serverSocket,
				__FILE__, __FUNCTION__, __LINE__);
		}
		/*
		else
		{
			printf("tls connect success getting peer cetr now;\n");
			
			X509 * cert;
			char * line;
			
			cert = SSL_get_peer_certificate( siSocket->ssl);
			
			if( cert)
			{
				line = X509_NAME_oneline( X509_get_subject_name( cert), 0, 0);
				printf("Subject: %s\n", line);
				free(line);
				line = X509_NAME_oneline( X509_get_issuer_name(cert), 0, 0);
				printf("Issuer: %s\n", line);
				free(line);
				X509_free( cert); 
			}
		}
		*/
		
		//alpn check
		if( __si_socket_engine_is_alpn_negotiated( siSocket) != 1)
		{
			__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "Socket: APNP negotiation failed, closing socket connection");	
		
			close( serverSocket);
			return -1;
		}
		else
		{
			__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "alpn_negotiated successfully for fd=%d<%s|%s|%d>", serverSocket,
				__FILE__, __FUNCTION__, __LINE__);
		}
		
		//SSL_set_connect_state( siSocket->ssl);
	}
	
	#endif
	
	struct linger so_linger;
	
	so_linger.l_onoff = 1;
	so_linger.l_linger = 0;
	
	setsockopt( serverSocket, SOL_SOCKET, SO_LINGER, &so_linger, sizeof ( struct linger));	
	
	if( siSocket->TlsEnabled == 1)
	{	
		//int nodelay_val = 1;
		//setsockopt( serverSocket, IPPROTO_TCP, TCP_NODELAY, (char *)&nodelay_val, sizeof(nodelay_val));	
		
		//int setNoSigpipe = 1;
		//setsockopt( serverSocket, SOL_SOCKET, SO_NOSIGPIPE, (void *)&setNoSigpipe, sizeof(int));		
	}
	
	if( siSocket->noDelay == 1)
	{
		int nodelay_val = 1;
		setsockopt( serverSocket, IPPROTO_TCP, TCP_NODELAY, (char *)&nodelay_val, sizeof(nodelay_val));
		//printf("enabled no-delay \n");
	}
	
	int sendbuf = -1;	
	fcntl( serverSocket, F_SETFL, fcntl( serverSocket, F_GETFL, 0) | O_NONBLOCK);	
	int rc = setsockopt( serverSocket, SOL_SOCKET, SO_SNDBUF,(char *)&sendbuf, sizeof(sendbuf));
	
	
	siSocket->fd = serverSocket;
	siSocket->isConnected = 1;
	siSocket->isActive = 1;
	
	siSocket->AddBuffer = __si_socket_engine_add_buffer_to_socket;
	
	pthread_mutex_unlock( &siSocket->ConnectLock);
	
	if( siSocket->StateFull == 0)
	{	
		__si_socket_engine_attach_to_epoll( siSocket);
	}
	
	return 1;
}

void * __si_socket_engine_udp_client_socket_read( void * args)
{
	SI_Socket * siSocket = (SI_Socket *) args;
	
	while(1)
	{
		if( siSocket->isConnected == 0)
		{
			__si_socket_engine_udp_connect_socket( siSocket);
		}
		
		printf("udp client connection status=%d fd=%d\n", siSocket->isConnected, siSocket->fd);
		
		if( siSocket->isConnected == 1)
		{	
			while( siSocket->isConnected == 1)
			{
				struct pollfd fds;	
				fds.fd     = siSocket->fd;
				fds.events = POLLIN;

				long int iRequestNo = 0;
				int n = 0, flags = 0, ret;
				
				SI_SocketUdpBuffer * udpBuffer = NULL;

				while(1)
				{
					ret = poll( &fds, 1, 1000);
					
					//printf("polling client udp fd=%d ret=%d\n", siSocket->fd, ret);
					
					if( ret <= 0)
					{
						continue;
					}
					
					if( ret > 0)
					{
						udpBuffer = __si_socket_engine_allocate_socket_udp_buffer();
						udpBuffer->pos = 0;
						
						if( siSocket->IPVersion == SIRIK_IP_VERSION_4)
						{
							// memset( &udpBuffer->clientaddr, 0, sizeof(struct sockaddr_in));
							udpBuffer->clientlen = sizeof(struct sockaddr_in);
							udpBuffer->len = recvfrom( siSocket->fd, udpBuffer->buff, 65535, 0, (struct sockaddr *) &udpBuffer->clientaddr, &udpBuffer->clientlen);
						}
						else
						{
							// memset( &udpBuffer->clientaddr6, 0, sizeof(struct sockaddr_in6));
							udpBuffer->clientlen = sizeof(struct sockaddr_in6);
							udpBuffer->len = recvfrom( siSocket->fd, udpBuffer->buff, 65535, 0, (struct sockaddr *) &udpBuffer->clientaddr6, &udpBuffer->clientlen);
						}
						
						
						//printf("polling client udp fd=%d  clientlen=%d  len=%d\n", siSocket->fd, udpBuffer->clientlen, udpBuffer->len);
						
						if( udpBuffer->len > 0) 
						{
							__si_log( SI_STK_LOG, 0, SI_LOG_DEBUG, "recv udp-data on port=%d with len=%d cbf=%p   %s|%s|%d", 
								siSocket->IPPort, udpBuffer->len, siSocket->OnUdpPacketReceive, __FILE__, __FUNCTION__, __LINE__);
							
				
							if( siSocket->OnUdpPacketReceive > 0)
							{
								udpBuffer->siSocket = siSocket;
								__si_core_queue( (uint8_t *) udpBuffer, (queue_handler) siSocket->OnUdpPacketReceive);
							}
							else
							{
								__si_socket_engine_release_socket_udp_buffer( udpBuffer);
							}
						} 
						else 
						{
							
							__si_socket_engine_release_socket_udp_buffer( udpBuffer);
						}
					}
				}
				
				
			}
		}
		
		usleep( 999999);
	}
}

void __si_socket_engine_add_socket_to_engine_for_udp_client_poll( SI_Socket * cSocket)
{
	//ucsr = udp client socket read
	__si_create_pthread2( __si_socket_engine_udp_client_socket_read, cSocket, "ucsr");
}
	
void __si_socket_engine_create_client_socket( char * ip, int ipversion, int transportType, int port, int tls, SI_Socket ** cSocket )
{
	//SI_Socket * siSocket = ( SI_Socket *) __si_malloc( sizeof(SI_Socket));
	SI_Socket * siSocket = NULL;
	__si_malloc2( sizeof(SI_Socket), (uint8_t **) &siSocket);	
	memset( siSocket, 0, sizeof( SI_Socket));
	
	strcpy( siSocket->IPAddresses[siSocket->IPAddressCount].IPAddress, ip);
	siSocket->IPAddresses[siSocket->IPAddressCount].IPVersion = ipversion;
	siSocket->IPAddressCount++;
	
	siSocket->IPVersion = ipversion;
	siSocket->TransportType = transportType;
	siSocket->IPPort = port;
	
	pthread_mutex_init( &siSocket->BufferLock, NULL);
	pthread_mutex_init( &siSocket->BufferReadLock, NULL);
	//pthread_mutex_init( &siSocket->ChildLock, NULL);	
	pthread_mutex_init( &siSocket->CloseLock, NULL);
	pthread_mutex_init( &siSocket->ConnectLock, NULL);
	
	#if TLS_SOCKET_SUPPORT
	pthread_mutex_init( &siSocket->ioLock, NULL);
	#endif
	
	pthread_mutex_init( &siSocket->AsyncWriteLock, NULL);
	
	siSocket->TlsEnabled = tls;
	siSocket->TlsAyncWrite = ( tls == 1) ? 1 : 0;
	
	#if TLS_SOCKET_SUPPORT
		
		if( tls == 1)
		{
			//siSocket->ctx = SSL_CTX_new( TLSv1_2_client_method());
			siSocket->ctx = SSL_CTX_new( SSLv23_client_method());
			
			if ( siSocket->ctx == NULL )
			{
				ERR_print_errors_fp( stderr);
				abort();
				//TODO:note ssl error and fail connection
			}
			
			//Disabling SSLv2 will leave v3 and TSLv1 for negotiation 
			SSL_CTX_set_options( siSocket->ctx, SSL_OP_NO_SSLv2);
			
			if( __si_socket_variable_negotiate_tls_h2_alpn == 1)
			{
				SSL_CTX_set_alpn_protos( siSocket->ctx, (const unsigned char *)"\x02h2", 3);
			}
			
			siSocket->ssl = SSL_new( siSocket->ctx);
		}
		
	#endif	
	
	
	//printf("ip=%s IPVersion=%d tt=%d port=%d\n", ip, ipversion, transportType, port);
	
	siSocket->noDelay = 1;
	siSocket->ReadInProgress = 0;
	siSocket->ReadSignal = 0;
	siSocket->isActive = 1;
	siSocket->isFree = 0;
	siSocket->GenId = 0;
	siSocket->isStarted = 0;
	siSocket->isHost = 0;
	siSocket->isConnected = 0;
	
	if( siSocket->TransportType == SIRIK_TRANSPORT_TYPE_TCP)
	{
		__si_socket_engine_add_socket_to_engine_for_epoll_async( siSocket);
		
		siSocket->Send = __si_socket_engine_tcp_send_socket_data;
		siSocket->Connect = __si_socket_engine_tcp_connect_socket;
		siSocket->Read = __si_socket_engine_tcp_read_socket_data;
		siSocket->Close = __si_socket_engine_tcp_close_socket;
		
		/*
		if(!__si_socketEngine->ThreadHead)
		{
			__si_socketEngine->StartEngine();
		}
		*/
	}
	else if( siSocket->TransportType == SIRIK_TRANSPORT_TYPE_UDP)
	{
		__si_socket_engine_add_socket_to_engine_for_udp_client_poll( siSocket);
		
		siSocket->Send = __si_socket_engine_udp_send_socket_data;
		siSocket->Connect = __si_socket_engine_udp_connect_socket;
		siSocket->Read = __si_socket_engine_udp_read_socket_data;
		siSocket->Close = __si_socket_engine_udp_close_socket;
	}
	
	*cSocket = siSocket;
}

void __si_socket_engine_create_client_socket2( char * ip, int ipversion, int transportType, int port, int tls, SI_Socket ** cSocket, char * cip, uint16_t cport)
{
	//SI_Socket * siSocket = ( SI_Socket *) __si_malloc( sizeof(SI_Socket));
	SI_Socket * siSocket = NULL;
	__si_malloc2( sizeof(SI_Socket), (uint8_t **) &siSocket);	
	memset( siSocket, 0, sizeof( SI_Socket));
	
	strcpy( siSocket->IPAddresses[siSocket->IPAddressCount].IPAddress, ip);
	siSocket->IPAddresses[siSocket->IPAddressCount].IPVersion = ipversion;
	siSocket->IPAddressCount++;
	
	siSocket->IPVersion = ipversion;
	siSocket->TransportType = transportType;
	siSocket->IPPort = port;
	
	if( cip)
	{
		strcpy( siSocket->ClientIP.IPAddress, cip);
	}
	
	if( cport > 0)
	{
		siSocket->CIPPort = cport;
	}
	
	pthread_mutex_init( &siSocket->BufferLock, NULL);
	pthread_mutex_init( &siSocket->BufferReadLock, NULL);
	//pthread_mutex_init( &siSocket->ChildLock, NULL);	
	pthread_mutex_init( &siSocket->CloseLock, NULL);
	pthread_mutex_init( &siSocket->ConnectLock, NULL);
	
	#if TLS_SOCKET_SUPPORT
	pthread_mutex_init( &siSocket->ioLock, NULL);
	#endif
	
	pthread_mutex_init( &siSocket->AsyncWriteLock, NULL);
	
	siSocket->TlsEnabled = tls;
	siSocket->TlsAyncWrite = ( tls == 1) ? 1 : 0;
	
	#if TLS_SOCKET_SUPPORT
		
		if( tls == 1)
		{
			//siSocket->ctx = SSL_CTX_new( TLSv1_2_client_method());
			siSocket->ctx = SSL_CTX_new( SSLv23_client_method());
			
			if ( siSocket->ctx == NULL )
			{
				ERR_print_errors_fp( stderr);
				abort();
				//TODO:note ssl error and fail connection
			}
			
			//Disabling SSLv2 will leave v3 and TSLv1 for negotiation 
			SSL_CTX_set_options( siSocket->ctx, SSL_OP_NO_SSLv2);
			
			if( __si_socket_variable_negotiate_tls_h2_alpn == 1)
			{
				SSL_CTX_set_alpn_protos( siSocket->ctx, (const unsigned char *)"\x02h2", 3);
			}
			
			siSocket->ssl = SSL_new( siSocket->ctx);
		}
		
	#endif	
	
	
	//printf("ip=%s IPVersion=%d tt=%d port=%d\n", ip, ipversion, transportType, port);
	
	siSocket->noDelay = 1;
	siSocket->ReadInProgress = 0;
	siSocket->ReadSignal = 0;
	siSocket->isActive = 1;
	siSocket->isFree = 0;
	siSocket->GenId = 0;
	siSocket->isStarted = 0;
	siSocket->isHost = 0;
	siSocket->isConnected = 0;
	
	if( siSocket->TransportType == SIRIK_TRANSPORT_TYPE_TCP)
	{
		__si_socket_engine_add_socket_to_engine_for_epoll_async( siSocket);
		
		siSocket->Send = __si_socket_engine_tcp_send_socket_data;
		siSocket->Connect = __si_socket_engine_tcp_connect_socket;
		siSocket->Read = __si_socket_engine_tcp_read_socket_data;
		siSocket->Close = __si_socket_engine_tcp_close_socket;
		
		/*
		if(!__si_socketEngine->ThreadHead)
		{
			__si_socketEngine->StartEngine();
		}
		*/
	}
	else if( siSocket->TransportType == SIRIK_TRANSPORT_TYPE_UDP)
	{
		__si_socket_engine_add_socket_to_engine_for_udp_client_poll( siSocket);
		
		siSocket->Send = __si_socket_engine_udp_send_socket_data;
		siSocket->Connect = __si_socket_engine_udp_connect_socket;
		siSocket->Read = __si_socket_engine_udp_read_socket_data;
		siSocket->Close = __si_socket_engine_udp_close_socket;
	}
	
	*cSocket = siSocket;
}

void __si_socket_create_client_object( char * ip, int ipversion, int transportType, int port, int tls, SI_Socket ** cSocket)
{
	SI_Socket * siSocket = NULL;
	__si_malloc2( sizeof(SI_Socket), (uint8_t **) &siSocket);	
	memset( siSocket, 0, sizeof( SI_Socket));
	
	siSocket->IPAddressCount = 0;
	
	strcpy( siSocket->IPAddresses[siSocket->IPAddressCount].IPAddress, ip);
	//printf("IP=%s|%s    port=%d   %s|%d\n", siSocket->IPAddresses[siSocket->IPAddressCount].IPAddress, ip, port, __FILE__, __LINE__);
	siSocket->IPAddresses[siSocket->IPAddressCount].IPVersion = ipversion;
	siSocket->IPAddressCount++;
	
	siSocket->IPVersion = ipversion;
	siSocket->TransportType = transportType;
	siSocket->IPPort = port;
	
	pthread_mutex_init( &siSocket->BufferLock, NULL);
	pthread_mutex_init( &siSocket->BufferReadLock, NULL);
	//pthread_mutex_init( &siSocket->ChildLock, NULL);	
	pthread_mutex_init( &siSocket->CloseLock, NULL);
	pthread_mutex_init( &siSocket->ConnectLock, NULL);
	
	#if TLS_SOCKET_SUPPORT
	pthread_mutex_init( &siSocket->ioLock, NULL);
	#endif
	
	pthread_mutex_init( &siSocket->AsyncWriteLock, NULL);
	
	siSocket->TlsEnabled = tls;
	siSocket->TlsAyncWrite = ( tls == 1) ? 1 : 0;
	
	#if TLS_SOCKET_SUPPORT
		
		if( tls == 1)
		{
			//siSocket->ctx = SSL_CTX_new( TLSv1_2_client_method());
			siSocket->ctx = SSL_CTX_new( SSLv23_client_method());
			
			if ( siSocket->ctx == NULL )
			{
				ERR_print_errors_fp( stderr);
				abort();
				//TODO:note ssl error and fail connection
			}
			
			//Disabling SSLv2 will leave v3 and TSLv1 for negotiation 
			SSL_CTX_set_options( siSocket->ctx, SSL_OP_NO_SSLv2);
			
			if( __si_socket_variable_negotiate_tls_h2_alpn == 1)
			{
				SSL_CTX_set_alpn_protos( siSocket->ctx, (const unsigned char *)"\x02h2", 3);
			}
			
			siSocket->ssl = SSL_new( siSocket->ctx);
		}
		
	#endif	
	
	//printf("ip=%s IPVersion=%d tt=%d port=%d\n", ip, ipversion, transportType, port);
	
	siSocket->ReadInProgress = 0;
	siSocket->ReadSignal = 0;
	siSocket->isActive = 1;
	siSocket->isFree = 0;
	siSocket->GenId = 0;
	siSocket->isStarted = 0;
	siSocket->isHost = 0;
	siSocket->isConnected = 0;
	
	siSocket->Send = __si_socket_engine_tcp_send_socket_data;
	siSocket->Connect = __si_socket_engine_tcp_connect_socket;
	siSocket->Close = __si_socket_engine_tcp_close_socket;
	
	*cSocket = siSocket;
}

void __si_socket_engine_run_statefull_client_socket( SI_Socket * siSocket)
{
	// NOT Implemented, check lib_diam.c, needs to implement in specific protocol
}

int __si_socket_engine_write_async_tls_data( SI_Socket * siSocket, SI_SocketAyncBuffer * bufferItem)
{
	int w = 0;
	int iSentBytes = 0;
	
	if( siSocket->isActive == 1)
	{
		#if TLS_SOCKET_SUPPORT		
		pthread_mutex_lock( &siSocket->ioLock);
		iSentBytes = SSL_write( siSocket->ssl, bufferItem->buff, bufferItem->len);
		pthread_mutex_unlock( &siSocket->ioLock); 
		
		if( iSentBytes <= 0)
		{
			printf("closing in async op \n");
			siSocket->Close( siSocket);
		}
		
		#endif
		
		w = 1;
	}
	
	__si_freeMV( bufferItem->buff);
	bufferItem->buff = NULL;
	
	__si_freeMV( bufferItem);
	
	return w;
}


int __si_socket_engine_write_async_data( SI_Socket * siSocket)
{
	int w = 0;
	
	pthread_mutex_lock( &siSocket->AsyncWriteLock);
	
	SI_SocketAyncBuffer * bufferItem = siSocket->AyncWriteBufferHead;
	
	while( bufferItem)
	{
		siSocket->AyncWriteBufferHead = bufferItem->Next;
		
		w += __si_socket_engine_write_async_tls_data( siSocket, bufferItem);
		
		bufferItem = siSocket->AyncWriteBufferHead;
	}
	
	pthread_mutex_unlock( &siSocket->AsyncWriteLock);
	
	return w;
}

int __si_socket_engine_write_async_data_for_epoll( int epoll_fd)
{
	SI_Socket * siSocket = __si_socketEngine->SocketEPollAyncWriteHead;
	int w  = 0;
	
	while( siSocket)
	{
		if( siSocket->epoll_fd == epoll_fd)
		{
			w += __si_socket_engine_write_async_data( siSocket);
		}
		
		siSocket = siSocket->SENext;
	}
	
	return w;
}


void * __si_socket_engine_epoll_thread( void * args)
{
	SI_SocketThread * socketThread = (SI_SocketThread *) args;
	
	int n, i;
	struct epoll_event events[ SIRIK_SOCKET_ENGINE_MAX_EPOLL_EVENTS ];
	
	SI_Socket * siSocket;
	
	int w = 0;
	
	while(1)
	{
		//n = epoll_wait ( socketThread->epoll_fd, events, SIRIK_SOCKET_ENGINE_MAX_EPOLL_EVENTS, -1);
		n = epoll_wait( socketThread->epoll_fd, events, SIRIK_SOCKET_ENGINE_MAX_EPOLL_EVENTS, 0);
		
		//if( n == -1)
		if( n <= 0)	
		{	
			w = __si_socket_engine_write_async_data_for_epoll( socketThread->epoll_fd);
			
			if( w == 0) 
			{
				usleep( 11111);
			}
			continue;
		}
		
		for (i = 0; i < n; i++)
		{
			siSocket = ( SI_Socket *) events[i].data.ptr;
			
			if ( events[i].events & EPOLLIN )
			{
				if( siSocket->Read > 0)
				{
					siSocket->Read( siSocket, socketThread);
				}	
			}
		}
		
		//done with reads, write now
		w = __si_socket_engine_write_async_data_for_epoll( socketThread->epoll_fd);
	}
	return NULL;
}

void __si_socket_engine_start_epoll_threads( int i)
{
	pthread_mutex_lock( &__si_socketEngine->ThreadLock);
	
	//SI_SocketThread * socketThread = (SI_SocketThread *) __si_malloc( sizeof(SI_SocketThread));
	SI_SocketThread * socketThread = NULL;
	__si_malloc2( sizeof(SI_SocketThread), (uint8_t **) &socketThread);
	memset( socketThread, 0, sizeof( SI_SocketThread));
	
	if(!__si_socketEngine->ThreadHead)
	{
		__si_socketEngine->ThreadHead = __si_socketEngine->ThreadCurrent = socketThread;
	}
	else
	{
		__si_socketEngine->ThreadCurrent->Next = socketThread;
		__si_socketEngine->ThreadCurrent = socketThread;
	}

	socketThread->epoll_fd = epoll_create1(0);
	socketThread->is_epoll_thread = 1;
	socketThread->index = i;
	socketThread->count = 0;
	socketThread->LastReads = 0;
	socketThread->LastTotalReads = 0;
	socketThread->TotalReads = 0;
	__si_socketEngine->EPollThreadsCount++;	
	pthread_mutex_init( &socketThread->CountLock, NULL);
	
	pthread_mutex_unlock( &__si_socketEngine->ThreadLock);
	
	__si_create_pthread2( __si_socket_engine_epoll_thread, socketThread, "si_epoll");
}

void __si_socket_engine_start()
{
	int i = 0;
	for( i = 0; i < __si_socketEngine->InitialEPollThreads; i++)
	{
		__si_socket_engine_start_epoll_threads( i);
	}
}


void __si_socket_engine_socket_read_lock( SI_Socket * siSocket)
{
	pthread_mutex_lock( &siSocket->BufferReadLock);
}

void __si_socket_engine_socket_read_unlock( SI_Socket * siSocket)
{
	pthread_mutex_unlock( &siSocket->BufferReadLock);
}



void __si_socket_engine_print_stats()
{
	/*
	printf( "socket AvailableBufferPoolCount=%d TotalBufferPoolCount=%d\n", 
		__si_socketEngine->AvailableBufferPoolCount, __si_socketEngine->TotalBufferPoolCount);
	*/
	__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "Socket: AvailableBufferPoolCount=%d TotalBufferPoolCount=%d Used=%d Pending=%d %s|%d", 
			__si_socketEngine->AvailableBufferPoolCount, 
			__si_socketEngine->TotalBufferPoolCount, 
			__si_socketEngine->UsedBufferPoolCount,
			( __si_socketEngine->TotalBufferPoolCount - __si_socketEngine->AvailableBufferPoolCount),
			__FILE__, __LINE__
		);	
		
	SI_SocketThread * socketThread = __si_socketEngine->ThreadHead;
	int tt = 0;
	
	while( socketThread)
	{
		socketThread->LastReads = socketThread->TotalReads - socketThread->LastTotalReads;
		
		if( socketThread->usiSocket) 
		{
			tt = ((SI_Socket *)socketThread->usiSocket)->TransportType;
		}
		
		__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "Socket: SocketThread index=%d fd-count=%d total-reads=%010ld last-reads=%06d TT=%d", 
			socketThread->index, socketThread->count, socketThread->TotalReads, socketThread->LastReads, tt);
		
		socketThread->LastTotalReads = socketThread->TotalReads;
		
		socketThread = socketThread->Next;
	}
	
	__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "Socket: TotalSocketsCount=%d SocketClosedCount=%d", 
		__si_socketEngine->TotalSocketsCount, __si_socketEngine->SocketClosedCount);
	
	__si__per_log_pending_queuecount( "SCTP ", __si_socketEngine->queueSctpSocketBufferPoolObject);
	
	SI_Socket * siServerSocket = __si_socketEngine->SocketHead;
	uint64_t lastSent = 0;
	uint64_t lastRecv = 0;
	
	SI_Socket * siServerSocketChild = NULL;
	
	while( siServerSocket)
	{
		lastSent = siServerSocket->AfterMessageSent - siServerSocket->LastMessageSent;
		lastRecv = siServerSocket->ReceivedMessages - siServerSocket->LastReceivedMessages;
		
		__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "Socket: Server ChildSocketCount=%d Port=%d v=%d Sent=%lu|%lu Received=%lu Delta=%ld Last[Sent=%lu Recv=%lu Delta=%ld]", 
			siServerSocket->ChildSocketCount, siServerSocket->IPPort, siServerSocket->IPVersion, 
			siServerSocket->BeforeMessageSend, siServerSocket->AfterMessageSent, 
			siServerSocket->ReceivedMessages, 
			siServerSocket->ReceivedMessages - siServerSocket->AfterMessageSent, 
			lastSent, lastRecv, lastRecv - lastSent);

		siServerSocket->LastMessageSent 		= siServerSocket->AfterMessageSent;
		siServerSocket->LastReceivedMessages 	= siServerSocket->ReceivedMessages;
		
		siServerSocketChild = siServerSocket->ChildHead;
		
		while( siServerSocketChild)
		{
			lastSent = siServerSocketChild->AfterMessageSent - siServerSocketChild->LastMessageSent;
			lastRecv = siServerSocketChild->ReceivedMessages - siServerSocketChild->LastReceivedMessages;
			
			__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "Socket: SerChi ChildSocketCount=%d Port=%d v=%d Sent=%lu|%lu Received=%lu Delta=%ld Last[Sent=%lu Recv=%lu Delta=%ld]", 
				siServerSocketChild->ChildSocketCount, siServerSocketChild->IPPort, siServerSocketChild->IPVersion, 
				siServerSocketChild->BeforeMessageSend, siServerSocketChild->AfterMessageSent, 
				siServerSocketChild->ReceivedMessages, siServerSocketChild->ReceivedMessages - siServerSocketChild->AfterMessageSent, 
				lastSent, lastRecv, lastRecv - lastSent);

			siServerSocketChild->LastMessageSent 		= siServerSocketChild->AfterMessageSent;
			siServerSocketChild->LastReceivedMessages 	= siServerSocketChild->ReceivedMessages;	
			
			siServerSocketChild = siServerSocketChild->Next;
		}
		
		siServerSocket = siServerSocket->Next;
	}
	
	__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "SSL-Socket: TlsTotalReadContinueCount=%ld TlsTotalWriteContinueCount=%ld", 
		__si_socketEngine->TlsTotalReadContinueCount, __si_socketEngine->TlsTotalWriteContinueCount);	
		
	__si_log( SI_PER_LOG, LOG_CAT_CORE, SI_LOG_CRITICAL, "--------------------------------------------------------------------------------------------------------");
}

void __si_socket_engine_init_tls()
{
	#if TLS_SOCKET_SUPPORT

		OpenSSL_add_all_algorithms();
		ERR_load_crypto_strings();
		SSL_load_error_strings();
		
		if( SSL_library_init() < 0)
		{
			printf("Could not initialize the OpenSSL library !\n");
		}
		
		//printf("tls library initalized:\n");
	#endif
}

void __si_socket_BufferCallBackHandler( void * sb, int index)
{
	SI_Socket * socket = (SI_Socket *) sb;
	socket->OnBufferReceive( (SI_Socket *)socket);
}

void __si_socket_sctpBufferCallBackHandler( void * sb, int index)
{
	SI_SocketSCTPBuffer * sctpBuffer = (SI_SocketSCTPBuffer *) sb;
	sctpBuffer->siSocket->OnBufferReceive( (SI_Socket *)sctpBuffer);
}

static int __si_socket_engine_init_t = 0;


void __si_socket_engine_sigpipe( int signum)
{
	__si_log( SI_STK_LOG, 0, SI_LOG_CRITICAL, "Socket: Received SIGPIPE=%d No Action Taken %s|%s|%d", signum, __FILE__, __FUNCTION__, __LINE__);	
}

void __si_socket_engine___set_sctp_epoll_thread_count( int num)
{
	__si_socketEngine->InitialSCTPEPollThreads = num;
}

int __si_socket_engine___get_sctp_epoll_thread_count()
{
	return __si_socketEngine->InitialSCTPEPollThreads;
}

void __si_socket_engine_init()
{
	if( __si_socket_engine_init_t == 0)
	{
		__si_socket_engine_init_t = 1;
		
		signal( SIGPIPE, __si_socket_engine_sigpipe);
		//printf( "signal : SIG_IGN for SIGPIPE in socket engine\n");
		__init_sirik_core();
		
		//__si_socketEngine = (SI_SocketEngine *) __si_malloc( sizeof(SI_SocketEngine) );
		__si_malloc2( sizeof(SI_SocketEngine), (uint8_t **) &__si_socketEngine);
		
		memset( __si_socketEngine, 0, sizeof( SI_SocketEngine));
		
		pthread_mutex_init( &__si_socketEngine->SocketConnectLock, NULL);
		pthread_mutex_init( &__si_socketEngine->SocketLock, NULL);
		pthread_mutex_init( &__si_socketEngine->SocketPoolLock, NULL);
		pthread_mutex_init( &__si_socketEngine->ThreadLock, NULL);
		pthread_mutex_init( &__si_socketEngine->BufferPoolLock, NULL);
		pthread_mutex_init( &__si_socketEngine->UdpBufferPoolLock, NULL);
		pthread_mutex_init( &__si_socketEngine->SctpBufferPoolLock, NULL);
		pthread_mutex_init( &__si_socketEngine->lkSctpThreadLock, NULL);
		
		__si_core_create_queue( &__si_socketEngine->bufferQueue, __si_socket_BufferCallBackHandler, 1, 1000);
		__si_core_create_queue( &__si_socketEngine->queueSctpSocketBufferPoolObject, __si_socket_sctpBufferCallBackHandler, 1, 1000);
		
		__si_socketEngine->CreateServerSocket = __si_socket_engine_create_server_socket;
		__si_socketEngine->CreateClientSocket = __si_socket_engine_create_client_socket;

		__si_socketEngine->Start 		= __si_socket_engine_start_server_socket;		
		__si_socketEngine->StartEngine 	= __si_socket_engine_start;

		__si_socketEngine->GetBufferLength = __si_socket_engine_buffer_data_length;
		__si_socketEngine->ReadLock = __si_socket_engine_socket_read_lock;
		__si_socketEngine->ReadUnLock = __si_socket_engine_socket_read_unlock;
		__si_socketEngine->GetBuffer = __si_socket_engine_tcp_get_buffer;
		__si_socketEngine->GetInspectionBuffer = __si_socket_engine_tcp_get_sample_buffer;
		__si_socketEngine->ReleaseUsedBuffer = __si_socket_engine_tcp_release_used_buffer;
		
		__si_socketEngine->TotalBufferPoolCount = 0;
		__si_socketEngine->AvailableBufferPoolCount = 0;
		__si_socketEngine->UsedBufferPoolCount = 0;
		
		__si_socketEngine->TotalSocketsCount = 0;
		__si_socketEngine->EPollThreadsCount = 0;
		//__si_socketEngine->InitialEPollThreads = 2;
		__si_socketEngine->InitialEPollThreads = 3;
		__si_socketEngine->MaxSocketsPerEPoll = 10;
		__si_socketEngine->SocketClosedCount = 0;
		
		__si_socketEngine->InitialSCTPEPollThreads = 10;
		__si_socketEngine->lkEpollSctpThreadHead = NULL;
		__si_socketEngine->lkEpollSctpThreadCurrent = NULL;
		pthread_mutex_init( &__si_socketEngine->lkEpollSctpThreadLock, NULL);


		__si_socketEngine->InitialPollThreads = 25;
		__si_socketEngine->lkPollSctpThreadHead = NULL;
		__si_socketEngine->lkPollSctpThreadCurrent = NULL;
		__si_socketEngine->lkPollLastPolledSocket = NULL;
		__si_socketEngine->lkPollLastPolledSignalSocket = NULL;
		pthread_mutex_init( &__si_socketEngine->lkPollSctpThreadLock, NULL);
		__si_socketEngine->PollThreadsCount = 0;
		
		//strcpy( __si_socketEngine->CertPath, "./sirikfg.pem");
		//strcpy( __si_socketEngine->CertKeyPath, "./sirikfg.pem");
		
		__si_socketEngine->BufferQueueLineCount = 0;
		__si_socketEngine->BufferQueueLineHead = __si_socketEngine->BufferQueueLineCurrent = NULL;
		__si_socketEngine->BufferQueueLineTotalQueuedCount = 0;
		pthread_mutex_init( &__si_socketEngine->BufferQueueLineLock, NULL);		
		sem_init( &__si_socketEngine->buffer_queue_sem_lock, 0, 0);
		
		if( __si_socketEngine->BufferQueueLineThreadCount == 0) 
		{
			__si_socket_create_buffer_queue_processing_thread();
		}
		
		//this thread will try to connect to server, if client is epoll
		__si_create_pthread2( __si_socket_engine___client_connection, NULL, "si_sok_cc");
		
		//__si_socket_engine_create_socket_buffer( 1500, 1);
		//__si_socket_engine_create_socket_buffer( 100000, 1);
		__si_socket_engine_create_socket_buffer( 10000, 1);
		//printf("init socket server completed <%s|%s|%d> \n", __FILE__, __FUNCTION__, __LINE__);
	}
}






